import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { authRouter } from './server/routes/auth';
import { voicesRouter } from './server/routes/voices';
import { generationsRouter } from './server/routes/generations';
import { creditsRouter } from './server/routes/credits';
import { usageRouter } from './server/routes/usage';
import { billingRouter } from './server/routes/billing';
import { adminRouter } from './server/routes/admin';
import { assistantRouter } from './server/routes/assistant';
import { narratorsRouter } from './server/routes/narrators';
import { db } from './server/db/store';
import { QeemaAcousticProvider } from './server/providers/QeemaAcousticProvider';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Security & Body parsing
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // CORS and Security headers (No API keys or secrets exposed)
  app.use((req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-company-id, x-user-id');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'Qeema AI — Arabic Voice Platform for Business',
      version: '1.0.0-b2b-mvp',
      timestamp: new Date().toISOString()
    });
  });

  // Cloud / Secure Audio File Serving Endpoint (Signed/Safe Retrieval)
  app.get('/api/v1/storage/audio/:id', async (req: Request, res: Response) => {
    const fileId = req.params.id;
    let stored = db.audioFiles.get(fileId);

    // If not found in dynamic memory, check if it's a seeded generation
    if (!stored) {
      const gen = db.generations.get(fileId);
      if (gen) {
        // Generate on-the-fly acoustic buffer for sample
        const acousticProvider = new QeemaAcousticProvider();
        const synth = await acousticProvider.synthesize({
          text: gen.text,
          voice: db.voices.get(gen.voiceId) || Array.from(db.voices.values())[0],
          settings: gen.settings,
          companyId: gen.companyId,
          userId: gen.userId
        });
        stored = {
          buffer: synth.audioBuffer,
          mimeType: synth.mimeType,
          filename: `${fileId}.wav`
        };
        db.audioFiles.set(fileId, stored);
      }
    }

    if (!stored) {
      return res.status(404).json({ error: 'الملف الصوتي غير موجود أو انتهت صلاحية الرابط' });
    }

    const isDownload = req.query.download === 'true';

    res.setHeader('Content-Type', stored.mimeType || 'audio/wav');
    res.setHeader('Content-Length', stored.buffer.length);
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    if (isDownload) {
      res.setHeader('Content-Disposition', `attachment; filename="${stored.filename || 'qeema-voice.wav'}"`);
    } else {
      res.setHeader('Content-Disposition', 'inline');
    }

    res.send(stored.buffer);
  });

  // API v1 Routes
  app.get('/api/download-report', (req: Request, res: Response) => {
    const filePath = path.join(process.cwd(), 'public', 'QeemaVoice_Developments_Report.docx');
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', 'attachment; filename="QeemaVoice_Developments_Report.docx"');
    res.sendFile(filePath);
  });

  app.use('/api/v1/auth', authRouter);
  app.use('/api/v1/voices', voicesRouter);
  app.use('/api/v1/generations', generationsRouter);
  app.use('/api/v1/credits', creditsRouter);
  app.use('/api/v1/usage', usageRouter);
  app.use('/api/v1/billing', billingRouter);
  app.use('/api/v1/admin', adminRouter);
  app.use('/api/v1/assistant', assistantRouter);
  app.use('/api/v1/narrators', narratorsRouter);

  // Global Error Handler for API
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('[Server Error]:', err);
    res.status(500).json({
      error: 'حدث خطأ غير متوقع في الخادم',
      message: process.env.NODE_ENV === 'development' ? err?.message : undefined
    });
  });

  // Integrate Vite Middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Qeema AI] B2B Voice Platform running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
