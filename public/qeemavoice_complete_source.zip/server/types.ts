export type VoiceType = 'human' | 'ai';
export type DialectCode = 'gulf' | 'egyptian' | 'levantine' | 'maghrebi' | 'fusha';
export type VoiceGender = 'male' | 'female';
export type VoiceStyle = 'commercial' | 'documentary' | 'corporate' | 'storytelling' | 'conversational' | 'energetic' | 'calm';
export type VoiceUseCase = 'ads' | 'elearning' | 'ivr' | 'social_media' | 'presentations' | 'podcasts' | 'dubbing' | 'documentary' | 'corporate';

export interface Company {
  id: string;
  name: string;
  industry: string;
  country: string;
  createdAt: string;
  planId: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  companyId: string;
  role: 'admin' | 'member' | 'viewer';
  createdAt: string;
  avatar?: string;
}

export interface Voice {
  id: string;
  type: VoiceType;
  name: string;
  nameEn?: string;
  gender: VoiceGender;
  language: string; // 'ar'
  dialect: DialectCode;
  dialectLabel: string; // e.g. 'سعودي نجدي' or 'مصري قاهري'
  style: VoiceStyle;
  styleLabel: string; // e.g. 'إعلاني ورنان'
  useCases: VoiceUseCase[];
  provider: 'elevenlabs' | 'vertex_ai' | 'qeema_acoustic' | 'human_marketplace';
  providerVoiceId?: string;
  previewUrl: string;
  isActive: boolean;
  isFeatured?: boolean;
  avatar: string;
  humanTalentId?: string;
  bookingsCount?: number;
  metadata?: Record<string, unknown>;
  createdAt: string;
}

export interface GenerationSettings {
  speed: number;       // 0.5 - 2.0
  stability?: number;  // 0.0 - 1.0
  style?: number;      // 0.0 - 1.0
  pitch?: number;      // -10 to +10
  format?: 'mp3' | 'wav';
}

export interface Generation {
  id: string;
  companyId: string;
  userId: string;
  voiceId: string;
  voiceName: string;
  voiceType: VoiceType;
  dialect: DialectCode;
  text: string;
  textChars: number;
  settings: GenerationSettings;
  provider: string;
  model: string;
  audioUrl: string;
  storagePath: string;
  durationSeconds: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  errorMessage?: string;
  creditsConsumed: number;
  createdAt: string;
}

export interface UsageRecord {
  id: string;
  companyId: string;
  userId: string;
  generationId: string;
  feature: 'tts' | 'dubbing' | 'cloning';
  provider: string;
  model: string;
  inputUnits: number; // characters
  outputUnits: number; // audio seconds
  creditsConsumed: number;
  costUsd: number;
  createdAt: string;
}

export interface CreditTransaction {
  id: string;
  companyId: string;
  userId: string;
  delta: number; // positive or negative
  balanceAfter: number;
  reason: 'signup_bonus' | 'generation' | 'admin_grant' | 'refund' | 'purchase';
  referenceId?: string;
  description: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  companyId: string;
  actor: string;
  action: string;
  metadata?: Record<string, unknown>;
  createdAt: string;
}

export interface Plan {
  id: string;
  name: string;
  nameAr: string;
  monthlyCredits: number;
  priceUsd: number;
  features: string[];
}

export interface HumanBooking {
  id: string;
  companyId: string;
  companyName: string;
  talentId: string;
  talentName: string;
  scriptText: string;
  deadlineDays: number;
  usageLicense: 'commercial_ads' | 'internal_corporate' | 'broadcast_tv' | 'elearning';
  notes?: string;
  priceUsd: number;
  talentPayoutUsd: number;
  paymentModel: 'direct_escrow_100';
  status: 'pending' | 'in_studio' | 'delivered' | 'approved';
  deliverableAudioUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TalentPayout {
  talentId: string;
  talentName: string;
  avatar: string;
  dialect: string;
  completedBookingsCount: number;
  totalEarningsUsd: number;
  paidOutUsd: number;
  pendingBalanceUsd: number;
  iban: string;
  bankName: string;
  status: 'active' | 'payout_scheduled' | 'settled';
  lastPayoutDate?: string;
}

export interface SystemSettings {
  platformCommissionPercent: number; // e.g. 25%
  elevenLabsStatus: 'operational' | 'degraded' | 'offline';
  geminiAiStatus: 'operational' | 'degraded' | 'offline';
  cdnStorageStatus: 'operational' | 'degraded' | 'offline';
  maintenanceMode: boolean;
  creditRatePer10kCharsUsd: number; // e.g. $4.00 per 10k chars
  paymentEscrowModel: 'direct_100_percent';
}
