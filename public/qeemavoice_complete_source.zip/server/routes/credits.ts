import { Router, Request, Response } from 'express';
import { db } from '../db/store';
import { getAuthenticatedContext } from './auth';

export const creditsRouter = Router();

// GET credit balance and ledger transactions
creditsRouter.get('/', (req: Request, res: Response) => {
  const { company, user, balance } = getAuthenticatedContext(req);

  const transactions = db.creditTransactions
    .filter(tx => tx.companyId === company.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  res.json({
    balanceCredits: balance,
    unitRule: '1 Credit = 1 Arabic/English Character',
    company: {
      id: company.id,
      name: company.name,
      planId: company.planId
    },
    transactions
  });
});

// POST top-up credit pack
creditsRouter.post('/topup', (req: Request, res: Response) => {
  const { company, user } = getAuthenticatedContext(req);
  const { packId, amountCredits, paymentMethod = 'card' } = req.body;

  const validPacks: Record<string, { credits: number; price: number; name: string }> = {
    'pack-25k': { credits: 25000, price: 29, name: 'باقة 25,000 نقطة' },
    'pack-100k': { credits: 100000, price: 99, name: 'باقة 100,000 نقطة' },
    'pack-500k': { credits: 500000, price: 399, name: 'باقة 500,000 نقطة' }
  };

  const selected = validPacks[packId] || {
    credits: Number(amountCredits) || 50000,
    price: 49,
    name: `شحن مخصص ${amountCredits || 50000} نقطة`
  };

  const newBalance = db.addCredits(
    company.id,
    user.id,
    selected.credits,
    'purchase',
    `شحن رصيد: ${selected.name} (${selected.price} USD عبر ${paymentMethod})`,
    `pay-${Date.now()}`
  );

  res.json({
    success: true,
    addedCredits: selected.credits,
    newBalanceCredits: newBalance,
    message: `تم إضافة ${selected.credits.toLocaleString()} نقطة إلى محفظة الشركة بنجاح.`
  });
});
