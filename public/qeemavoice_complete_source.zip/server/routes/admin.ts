import { Router, Request, Response } from 'express';
import { db } from '../db/store';
import { Voice, HumanBooking } from '../types';

export const adminRouter = Router();

// GET Admin Overview
adminRouter.get('/overview', (req: Request, res: Response) => {
  const companies = Array.from(db.companies.values()).map(c => ({
    ...c,
    balance: db.getCompanyBalance(c.id),
    generationsCount: Array.from(db.generations.values()).filter(g => g.companyId === c.id).length
  }));

  const allGenerations = Array.from(db.generations.values());
  const allUsage = Array.from(db.usageRecords.values());
  const totalSystemCost = allUsage.reduce((acc, u) => acc + (u.costUsd || 0), 0);
  const totalCharsGenerated = allGenerations.reduce((acc, g) => acc + (g.textChars || 0), 0);
  
  const allBookings = Array.from(db.humanBookings.values());
  const totalBookingsRevenueUsd = allBookings.reduce((acc, b) => acc + (b.priceUsd || 0), 0);
  const totalTalentPayoutsUsd = allBookings.reduce((acc, b) => acc + (b.talentPayoutUsd || 0), 0);
  const platformBookingMarginUsd = totalBookingsRevenueUsd - totalTalentPayoutsUsd;

  const pendingBookingsCount = allBookings.filter(b => b.status === 'pending' || b.status === 'in_studio').length;

  res.json({
    companies,
    voicesCount: db.voices.size,
    aiVoicesCount: Array.from(db.voices.values()).filter(v => v.type === 'ai').length,
    humanVoicesCount: Array.from(db.voices.values()).filter(v => v.type === 'human').length,
    totalGenerations: allGenerations.length,
    totalCharsGenerated,
    totalSystemCostUsd: Number(totalSystemCost.toFixed(4)),
    totalBookingsRevenueUsd,
    totalTalentPayoutsUsd,
    platformBookingMarginUsd,
    pendingBookingsCount,
    systemSettings: db.systemSettings,
    recentLogs: db.auditLogs.slice(0, 30),
    recentGenerations: allGenerations.slice(-15).reverse()
  });
});

// GET All Bookings
adminRouter.get('/bookings', (req: Request, res: Response) => {
  const bookings = Array.from(db.humanBookings.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  res.json({ bookings });
});

// Update Booking Status
adminRouter.post('/bookings/:id/status', (req: Request, res: Response) => {
  const { status, deliverableUrl } = req.body;
  const validStatuses: HumanBooking['status'][] = ['pending', 'in_studio', 'delivered', 'approved'];

  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'حالة الطلب غير صالحة' });
  }

  const updated = db.updateBookingStatus(req.params.id, status, deliverableUrl);
  if (!updated) {
    return res.status(404).json({ error: 'طلب الحجز غير موجود' });
  }

  res.json({
    success: true,
    booking: updated,
    message: `تم تحديث حالة الحجز ${updated.id} إلى: ${status}`
  });
});

// GET Talent Payouts Ledger
adminRouter.get('/payouts', (req: Request, res: Response) => {
  const payouts = Array.from(db.talentPayouts.values());
  const totalPendingUsd = payouts.reduce((acc, p) => acc + p.pendingBalanceUsd, 0);
  const totalPaidOutUsd = payouts.reduce((acc, p) => acc + p.paidOutUsd, 0);

  res.json({
    payouts,
    totalPendingUsd,
    totalPaidOutUsd
  });
});

// Process Talent Payout
adminRouter.post('/payouts/:talentId/process', (req: Request, res: Response) => {
  const { amount } = req.body;
  const updated = db.processTalentPayout(req.params.talentId, amount ? Number(amount) : undefined);

  if (!updated) {
    return res.status(404).json({ error: 'سجل المعلق غير موجود' });
  }

  res.json({
    success: true,
    payout: updated,
    message: `تم تسجيل تسوية المستحقات للمعلق ${updated.talentName} بنجاح`
  });
});

// Toggle Voice Active/Inactive
adminRouter.post('/voices/:id/toggle', (req: Request, res: Response) => {
  const voice = db.voices.get(req.params.id);
  if (!voice) {
    return res.status(404).json({ error: 'الصوت غير موجود' });
  }

  voice.isActive = !voice.isActive;

  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    companyId: 'system',
    actor: 'admin',
    action: `VOICE_TOGGLE: ${voice.name} -> ${voice.isActive ? 'ACTIVE' : 'INACTIVE'}`,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    voiceId: voice.id,
    isActive: voice.isActive,
    message: `تم تحديث حالة الصوت: ${voice.name} إلى ${voice.isActive ? 'مفعل' : 'معطل'}`
  });
});

// Update Voice details (e.g. bookingsCount, name, isActive, isFeatured)
adminRouter.post('/voices/:id/update', (req: Request, res: Response) => {
  const voice = db.voices.get(req.params.id);
  if (!voice) {
    return res.status(404).json({ error: 'الصوت غير موجود' });
  }

  const { bookingsCount, isActive, name, isFeatured } = req.body;
  if (bookingsCount !== undefined) {
    voice.bookingsCount = Number(bookingsCount);
  }
  if (isActive !== undefined) {
    voice.isActive = Boolean(isActive);
  }
  if (name !== undefined) {
    voice.name = String(name);
  }
  if (isFeatured !== undefined) {
    voice.isFeatured = Boolean(isFeatured);
  }

  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    companyId: 'system',
    actor: 'admin',
    action: `VOICE_UPDATED: ${voice.name} -> bookingsCount=${voice.bookingsCount ?? 'none'}`,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    voice,
    message: `تم تحديث بيانات الصوت ${voice.name} بنجاح`
  });
});

// Create New Voice in Catalog
adminRouter.post('/voices/create', (req: Request, res: Response) => {
  const { name, nameEn, type, gender, dialect, dialectLabel, style, styleLabel, provider, previewUrl, avatar, hasAiTwin } = req.body;

  if (!name || !dialectLabel || !previewUrl) {
    return res.status(400).json({ error: 'يرجى إدخال الحقول الإلزامية للصوت' });
  }

  const newVoiceId = `voice-${type}-${Date.now()}`;
  const newVoice: Voice = {
    id: newVoiceId,
    type: type || 'ai',
    name,
    nameEn: nameEn || name,
    gender: gender || 'male',
    language: 'ar',
    dialect: dialect || 'gulf',
    dialectLabel,
    style: style || 'commercial',
    styleLabel: styleLabel || 'رسمي واحترافي',
    useCases: ['ads', 'corporate', 'social_media'],
    provider: provider || (type === 'human' ? 'human_marketplace' : 'elevenlabs'),
    previewUrl,
    avatar: avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    isActive: true,
    isFeatured: false,
    createdAt: new Date().toISOString()
  };

  db.voices.set(newVoice.id, newVoice);

  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    companyId: 'system',
    actor: 'admin',
    action: `VOICE_CREATED: ${newVoice.name} (${newVoice.type})`,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    voice: newVoice,
    message: `تمت إضافة الصوت الجديد ${newVoice.name} بنجاح`
  });
});

// Update Company Plan
adminRouter.post('/companies/:id/update-plan', (req: Request, res: Response) => {
  const { planId } = req.body;
  const company = db.companies.get(req.params.id);
  if (!company) {
    return res.status(404).json({ error: 'الشركة غير موجودة' });
  }

  company.planId = planId;

  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    companyId: company.id,
    actor: 'admin',
    action: `COMPANY_PLAN_CHANGED: ${company.name} -> ${planId}`,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    company,
    message: `تم ترقية باقة الشركة ${company.name} بنجاح`
  });
});

// Grant Credits to a company
adminRouter.post('/credits/grant', (req: Request, res: Response) => {
  const { companyId, amountCredits, reason } = req.body;
  if (!companyId || !db.companies.has(companyId)) {
    return res.status(404).json({ error: 'الشركة غير موجودة' });
  }

  const amount = Number(amountCredits);
  if (!amount || amount <= 0) {
    return res.status(400).json({ error: 'يرجى إدخال عدد نقاط صالح' });
  }

  const newBalance = db.addCredits(
    companyId,
    'admin-user',
    amount,
    'admin_grant',
    reason || `منحة إدارية استثنائية (+${amount.toLocaleString()} نقطة)`
  );

  res.json({
    success: true,
    companyId,
    amountGranted: amount,
    newBalance,
    message: `تم إضافة ${amount.toLocaleString()} نقطة للشركة بنجاح`
  });
});

// Update System Settings
adminRouter.post('/system/settings', (req: Request, res: Response) => {
  const { platformCommissionPercent, maintenanceMode, creditRatePer10kCharsUsd } = req.body;

  if (platformCommissionPercent !== undefined) {
    db.systemSettings.platformCommissionPercent = Number(platformCommissionPercent);
  }
  if (maintenanceMode !== undefined) {
    db.systemSettings.maintenanceMode = Boolean(maintenanceMode);
  }
  if (creditRatePer10kCharsUsd !== undefined) {
    db.systemSettings.creditRatePer10kCharsUsd = Number(creditRatePer10kCharsUsd);
  }

  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    companyId: 'system',
    actor: 'admin',
    action: `SYSTEM_SETTINGS_UPDATED`,
    metadata: db.systemSettings as unknown as Record<string, unknown>,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    settings: db.systemSettings,
    message: 'تم تحديث إعدادات المنصة بنجاح'
  });
});

