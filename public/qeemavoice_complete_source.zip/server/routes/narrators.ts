import { Router, Request, Response } from 'express';

export const narratorsRouter = Router();

// In-memory or fallback data for API routes
const MOCK_NARRATORS = [
  {
    id: 'narrator_tareq_01',
    displayName: 'طارق الشمري',
    phone: '+966555124567',
    email: 'tareq.shammary@qeema.voice',
    dialects: ['سعودي نجدي', 'فصحى معاصرة'],
    status: 'active',
    claimToken: 'token_tareq_active_2026',
    kycStatus: 'approved'
  },
  {
    id: 'narrator_sara_02',
    displayName: 'سارة الدوسري',
    phone: '+966504891122',
    email: 'sara.aldosari@qeema.voice',
    dialects: ['سعودي حجازي', 'فصحى وثائقية'],
    status: 'invited',
    claimToken: 'token_sara_invite_8891',
    kycStatus: 'none'
  }
];

// GET /api/v1/narrators
narratorsRouter.get('/', (req: Request, res: Response) => {
  res.json({ narrators: MOCK_NARRATORS });
});

// GET /api/v1/narrators/claim/:token
narratorsRouter.get('/claim/:token', (req: Request, res: Response) => {
  const { token } = req.params;
  const narrator = MOCK_NARRATORS.find(n => n.claimToken === token);
  if (!narrator) {
    return res.status(404).json({ error: 'رمز التفعيل غير صالح أو غير موجود' });
  }
  res.json({ narrator, isExpired: false });
});

// POST /api/v1/narrators/clone-instant (Backend ElevenLabs Instant Voice Clone proxy)
narratorsRouter.post('/clone-instant', async (req: Request, res: Response) => {
  const { narratorId, name, sampleFileIds, dialect } = req.body;

  // Real ElevenLabs API proxy would call:
  // POST https://api.elevenlabs.io/v1/voices/add
  // Headers: { 'xi-api-key': process.env.ELEVENLABS_API_KEY }
  // Without exposing key to the client!
  
  const simulatedVoiceId = `el_voice_${narratorId || 'narrator'}_${Date.now()}`;

  res.json({
    success: true,
    elevenLabsVoiceId: simulatedVoiceId,
    status: 'preview_ready',
    message: 'تم تدريب واستنساخ البصمة الصوتية بنجاح عبر خوادم ElevenLabs الآمنة'
  });
});

// POST /api/v1/narrators/verify-otp
narratorsRouter.post('/verify-otp', (req: Request, res: Response) => {
  const { otp } = req.body;
  if (otp === '123456' || (otp && otp.length === 6)) {
    return res.json({ success: true });
  }
  return res.status(400).json({ error: 'رمز التحقق غير صحيح' });
});
