export interface TalentProject {
  id: string;
  title: string;
  client: string;
  clientAvatar?: string;
  brand: string;
  status: 'new_request' | 'in_studio' | 'client_review' | 'delivered';
  category: 'commercial' | 'documentary' | 'ivr' | 'dubbing' | 'audiobook' | 'promo';
  categoryLabel: string;
  dialect: string;
  tone: string;
  wordCount: number;
  estimatedDurationSeconds: number;
  budgetSAR: number;
  budgetUSD: number;
  deadline: string;
  urgency: 'urgent' | 'normal' | 'relaxed';
  inEscrow: boolean;
  script: string;
  notes?: string;
  audioFormat: string;
  revisionsAllowed: number;
  revisionsUsed: number;
  submittedAudioUrl?: string;
}

export interface TalentDemo {
  id: string;
  title: string;
  category: string;
  dialect: string;
  duration: string;
  playsCount: number;
  likesCount: number;
  sampleRate: string;
  tags: string[];
  audioFrequency: number; // for synthetic audio pitch
  scriptExcerpt: string;
}

export interface TalentAudition {
  id: string;
  title: string;
  agency: string;
  deadline: string;
  budgetSAR: number;
  dialectRequired: string;
  toneRequired: string;
  wordCount: number;
  testScript: string;
  applicantsCount: number;
  status: 'open' | 'applied' | 'shortlisted' | 'awarded';
}

export interface TalentInvoice {
  id: string;
  invoiceNumber: string;
  client: string;
  projectTitle: string;
  date: string;
  amountSAR: number;
  status: 'paid' | 'escrow' | 'pending_transfer';
  vatAmountSAR: number;
}

export interface TalentProfile {
  id: string;
  name: string;
  title: string;
  avatar: string;
  code: string;
  rating: number;
  reviewsCount: number;
  completedProjectsCount: number;
  turnaroundAvgHours: number;
  studioStatus: 'available' | 'in_session' | 'away';
  balanceSAR: number;
  escrowSAR: number;
  totalEarningsSAR: number;
  monthlyGrowthPercent: number;
  dialects: string[];
  equipment: {
    mic: string;
    interface: string;
    preamp: string;
    daw: string;
    acousticIsolation: string;
    sourceConnectId: string;
  };
  voiceTwin: {
    name: string;
    version: string;
    isActive: boolean;
    ratePerWordSAR: number;
    wordsThisMonth: number;
    monthlyEarningsSAR: number;
    commercialAllowed: boolean;
    ivrAllowed: boolean;
  };
}

export const INITIAL_TALENT_PROFILE: TalentProfile = {
  id: 'talent-1',
  name: 'طارق الشمري',
  title: 'معلق وثائقي وإعلانات مصرفية معتمد | مهندس صوتيات',
  avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
  code: 'QV-1042',
  rating: 4.98,
  reviewsCount: 68,
  completedProjectsCount: 142,
  turnaroundAvgHours: 3.8,
  studioStatus: 'available',
  balanceSAR: 6200,
  escrowSAR: 3850,
  totalEarningsSAR: 68450,
  monthlyGrowthPercent: 18.5,
  dialects: ['سعودي نجدي', 'خليجي معاصر', 'فصحى وثائقية رنانة', 'فصحى إخبارية'],
  equipment: {
    mic: 'Neumann U87 Ai / Shure SM7B',
    interface: 'Universal Audio Apollo Twin X Quad',
    preamp: 'Rupert Neve Designs Shelford Channel',
    daw: 'Pro Tools Ultimate / Adobe Audition',
    acousticIsolation: 'كابينة مفرغة ومعالجة صوتياً (-64dB Noise Floor)',
    sourceConnectId: 'tariq_voice_live'
  },
  voiceTwin: {
    name: 'طارق AI - النسخة المرخصة',
    version: 'Neural v2.4 Hi-Res',
    isActive: true,
    ratePerWordSAR: 0.12,
    wordsThisMonth: 28500,
    monthlyEarningsSAR: 3420,
    commercialAllowed: true,
    ivrAllowed: true
  }
};

export const INITIAL_PROJECTS: TalentProject[] = [
  {
    id: 'proj-1',
    title: 'إعلان اليوم الوطني 94 - ملحمة طموح وطن',
    client: 'البنك الأهلي السعودي (SNB)',
    clientAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=120&auto=format&fit=crop&q=80',
    brand: 'SNB البنك الأهلي',
    status: 'in_studio',
    category: 'commercial',
    categoryLabel: 'إعلان تلفزيوني ورقمي',
    dialect: 'سعودي نجدي وقور',
    tone: 'فخم، وطني مهيب، مفعم بالعزيمة والأمل',
    wordCount: 78,
    estimatedDurationSeconds: 45,
    budgetSAR: 3500,
    budgetUSD: 933,
    deadline: 'اليوم خلال 4 ساعات',
    urgency: 'urgent',
    inEscrow: true,
    audioFormat: 'WAV 48kHz 24-bit PCM Uncompressed (مع ملف منفصل بنغمة الغرفة Clean Room Tone)',
    revisionsAllowed: 2,
    revisionsUsed: 0,
    script: `[وقفة تمهيدية] هنا، حيث تلتقي أصالة الأرض بعنان السماء.. [نبرة تصاعدية واثقة] لا نبني الغد فقط، بل نصيغ مجداً تتوارثه الأجيال!
[تنفس عميق] مع البنك الأهلي السعودي.. خطوتك الأولى نحو ريادة استثنائية، وعهدٌ يتجدد مع كل إشراقة شمس.
[نبرة دافئة ختامية] طموحنا.. سماءٌ بلا حدود. البنك الأهلي السعودي، معاً نصنع الريادة.`,
    notes: 'الرجاء إبقاء النبرة عميقة ورخيمة في الجملة الأولى، ثم التصاعد التدريجي حتى ختام الإعلان. تجنب السرعة الزائدة.'
  },
  {
    id: 'proj-2',
    title: 'سلسلة وثائقية: أسرار نقوش العلا الصخرية',
    client: 'شركة الإنتاج الوثائقي العربي (دبي)',
    clientAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    brand: 'سلسلة العلا الوثائقية',
    status: 'client_review',
    category: 'documentary',
    categoryLabel: 'فيلم وثائقي وسرد تاريخي',
    dialect: 'فصحى وثائقية سينمائية',
    tone: 'استكشافي، عميق، شاعري، سينمائي',
    wordCount: 380,
    estimatedDurationSeconds: 155,
    budgetSAR: 5200,
    budgetUSD: 1386,
    deadline: 'غداً الساعة 6:00 مساءً',
    urgency: 'normal',
    inEscrow: true,
    audioFormat: 'WAV 48kHz 24-bit Broadcast Master (-23 LUFS)',
    revisionsAllowed: 3,
    revisionsUsed: 1,
    script: `[هدوء وصمت ثانية] في عمق صحراء الحجاز الصامتة، حيث همست الرياح لآلاف السنين في آذان الجبال.. [نبرة استكشافية] تقف جدران العلا شاهقةً ككتابٍ مفتوح خطته أنامل الأنباط والديدانيين.
[تنفس] كل نقشٍ صخري حكاية، وكل ظلٍّ ينحسر مع غروب الشمس يكشف لغزاً لم تطأه قدم إنسان من قبل.
[سرد ملحمي] هنا نامت حضاراتٌ صنعت الفجر، واستيقظ تاريخٌ يعيد تشكيل نظرتنا للجزيرة العربية.`,
    notes: 'تم تسليم النسخة الأولى، طلب العميل إعادة تسجيل الجملة الثانية بنبرة أكثر بطئاً وشاعرية.'
  },
  {
    id: 'proj-3',
    title: 'نظام الرد الآلي الموحد (IVR) - مركز الاتصال الذكي',
    client: 'شركة الاتصالات السعودية (Solutions by stc)',
    clientAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80',
    brand: 'stc solutions',
    status: 'new_request',
    category: 'ivr',
    categoryLabel: 'أنظمة IVR وسنترال',
    dialect: 'سعودي معاصر / فصحى بيضاء مبسطة',
    tone: 'مرحب، شديد الوضوح، احترافي، مريح للأذن',
    wordCount: 140,
    estimatedDurationSeconds: 85,
    budgetSAR: 2200,
    budgetUSD: 586,
    deadline: 'خلال 24 ساعة',
    urgency: 'normal',
    inEscrow: true,
    audioFormat: 'WAV 8kHz / 16-bit u-law & 48kHz HQ Masters',
    revisionsAllowed: 2,
    revisionsUsed: 0,
    script: `أهلاً بك في stc لحلول الأعمال.
للخدمات السحابية ومراكز البيانات، اضغط واحد.
للأمن السيبراني وحلول الشبكات المتقدمة، اضغط اثنين.
للتحدث مع مستشارك التقني المعتمد، يرجى الانتظار، جميع مكالماتنا مسجلة لضمان أرقى معايير الجودة.`,
    notes: 'مطلوب تقطيع المقاطع إلى ملفات منفصلة مرقمة (01_welcome.wav, 02_cloud.wav, 03_security.wav, 04_agent.wav).'
  },
  {
    id: 'proj-4',
    title: 'دوبلاج شخصية "صقر" - المسلسل الكرتوني "فرسان المستقبل"',
    client: 'استوديوهات مانجا للرسوم المتحركة',
    clientAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    brand: 'مانجا للإنتاج',
    status: 'delivered',
    category: 'dubbing',
    categoryLabel: 'دوبلاج وتمثيل صوتي',
    dialect: 'فصحى درامية حماسية',
    tone: 'بطل شجاع، مليء بالحماس والتحدي',
    wordCount: 260,
    estimatedDurationSeconds: 110,
    budgetSAR: 4200,
    budgetUSD: 1120,
    deadline: 'مكتمل ومسلّم',
    urgency: 'relaxed',
    inEscrow: false,
    audioFormat: 'WAV 48kHz 24-bit Dialogue Stems',
    revisionsAllowed: 2,
    revisionsUsed: 1,
    script: `[صرخة حماسية] تمسكوا جميعاً! العاصفة تقترب، لكن درع النور لن ينكسر أبداً ما دامت قلوبنا تنبض بالحق! انطلق يا بارق!`,
    notes: 'تم اعتماد التسليم وتقييم العمل بـ 5 نجوم من المخرج الصوتي.'
  }
];

export const INITIAL_DEMOS: TalentDemo[] = [
  {
    id: 'demo-1',
    title: 'إعلان مصرفي فاخر - نبرة استثمارية وقورة',
    category: 'إعلانات تجارية (Commercial)',
    dialect: 'سعودي نجدي فخم',
    duration: '0:42',
    playsCount: 2450,
    likesCount: 184,
    sampleRate: '48kHz / 24-bit FLAC',
    tags: ['بنوك', 'استثمار', 'وقار', 'فخامة'],
    audioFrequency: 220,
    scriptExcerpt: 'نبتكر حلول الغد بثقة اليوم، لأن طموحنا لا يعرف المستحيل في أرض العطاء.'
  },
  {
    id: 'demo-2',
    title: 'سرد وثائقي تاريخي - صوت سينمائي مهيب',
    category: 'أفلام وثائقية (Documentary)',
    dialect: 'فصحى وثائقية رنانة',
    duration: '1:15',
    playsCount: 3120,
    likesCount: 295,
    sampleRate: '48kHz / 24-bit PCM',
    tags: ['وثائقي', 'تاريخ', 'سينمائي', 'عميق'],
    audioFrequency: 196,
    scriptExcerpt: 'على هذه الرمال الذهبية، تشكلت ملامح أمة صنعت مجدها بيدٍ تبني وأخرى تحمي.'
  },
  {
    id: 'demo-3',
    title: 'رد آلي وسنترال ذكي - نبرة واضحة ومرحبة',
    category: 'أنظمة IVR وسنترال',
    dialect: 'خليجي معاصر / بيضاء',
    duration: '0:35',
    playsCount: 1680,
    likesCount: 112,
    sampleRate: '48kHz / 24-bit HQ',
    tags: ['رد آلي', 'خدمة عملاء', 'مرحب', 'اتصالات'],
    audioFrequency: 247,
    scriptExcerpt: 'أهلاً بك في عالمك الرقمي، نسعد بخدمتك على مدار الساعة لتقديم تجربة لا تُنسى.'
  },
  {
    id: 'demo-4',
    title: 'دوبلاج وتمثيل صوتي - شخصية قيادية بطولية',
    category: 'دوبلاج وتمثيل صوتي',
    dialect: 'فصحى رسوم متحركة',
    duration: '0:50',
    playsCount: 1940,
    likesCount: 178,
    sampleRate: '48kHz / 24-bit PCM',
    tags: ['دوبلاج', 'رسوم متحركة', 'حماسي', 'ألعاب'],
    audioFrequency: 261,
    scriptExcerpt: 'لن نتراجع قيد أنملة! المستقبل ينتظر من يملك الشجاعة ليصنعه اليوم!'
  },
  {
    id: 'demo-5',
    title: 'سرد روائي ومسموع - قصة ملهمة',
    category: 'كتب مسموعة وبودكاست',
    dialect: 'فصحى أدبية دافئة',
    duration: '1:45',
    playsCount: 4210,
    likesCount: 340,
    sampleRate: '48kHz / 24-bit HQ',
    tags: ['كتب صوتية', 'بودكاست', 'سرد', 'دافئ'],
    audioFrequency: 207,
    scriptExcerpt: 'كان المساء يلقي بظلاله الهادئة فوق أسطح المدينة القديمة، لتولد فكرة غيرت مجرى الأحداث.'
  }
];

export const INITIAL_AUDITIONS: TalentAudition[] = [
  {
    id: 'aud-1',
    title: 'حملة موسم الرياض الكبرى - الهوية الجديدة',
    agency: 'الهيئة العامة للترفيه / وكالة ليو بورنيت',
    deadline: 'باقي 14 ساعة',
    budgetSAR: 7500,
    dialectRequired: 'سعودي حماسي معاصر',
    toneRequired: 'مفعم بالطاقة، شاعري حديث، يلامس القلوب',
    wordCount: 85,
    testScript: 'تخيل مكاناً.. كل لحظة فيه تصنع ذكرى، وكل دربٍ يقودك إلى مغامرة غير مسبوقة. الرياض في موسمها الجديد.. حياكم!',
    applicantsCount: 24,
    status: 'open'
  },
  {
    id: 'aud-2',
    title: 'فيلم ترويجي لمشروع نيوم - جزيرة سندالة',
    agency: 'فريق الإنتاج الإبداعي - نيوم',
    deadline: 'باقي يومان',
    budgetSAR: 9000,
    dialectRequired: 'فصحى وثائقية فخمة أو إنجليزي بلكنة عربية راقية',
    toneRequired: 'عالمي، فخم جداً، هادئ وملهم',
    wordCount: 110,
    testScript: 'حيث تلتقي المياه الفيروزية برؤية المستقبل.. سندالة، بوابة البحر الأحمر لليخوت والفخامة الاستثنائية.',
    applicantsCount: 38,
    status: 'applied'
  },
  {
    id: 'aud-3',
    title: 'إعلان رقمي لتطبيق مدفوعات سريع "تابي / تمارا"',
    agency: 'وكالة فكر للتسويق الرقمي',
    deadline: 'باقي 3 أيام',
    budgetSAR: 2800,
    dialectRequired: 'سعودي شبابي عفوي',
    toneRequired: 'عفوي، سريع، ابتسامة واضحة في الصوت',
    wordCount: 45,
    testScript: 'قسمها على أربع دفعات وبدون أي فوائد أو تعقيد! حمّل التطبيق الآن واستمتع بمشترياتك فوراً.',
    applicantsCount: 19,
    status: 'shortlisted'
  }
];

export const INITIAL_INVOICES: TalentInvoice[] = [
  {
    id: 'inv-1',
    invoiceNumber: 'INV-2024-0891',
    client: 'البنك الأهلي السعودي (SNB)',
    projectTitle: 'إعلان اليوم الوطني 94',
    date: '2024-10-14',
    amountSAR: 3500,
    status: 'escrow',
    vatAmountSAR: 525
  },
  {
    id: 'inv-2',
    invoiceNumber: 'INV-2024-0842',
    client: 'استوديوهات مانجا للإنتاج',
    projectTitle: 'دوبلاج شخصية صقر - فرسان المستقبل',
    date: '2024-10-02',
    amountSAR: 4200,
    status: 'paid',
    vatAmountSAR: 630
  },
  {
    id: 'inv-3',
    invoiceNumber: 'INV-2024-0799',
    client: 'شركة الحلول السحابية المتقدمة',
    projectTitle: 'نظام السنترال والرد الآلي IVR',
    date: '2024-09-21',
    amountSAR: 1900,
    status: 'paid',
    vatAmountSAR: 285
  },
  {
    id: 'inv-4',
    invoiceNumber: 'INV-2024-0750',
    client: 'هيئة الأفلام السعودية',
    projectTitle: 'سرد تعليقي لفيلم وثائقي سينمائي',
    date: '2024-09-08',
    amountSAR: 6500,
    status: 'paid',
    vatAmountSAR: 975
  }
];
