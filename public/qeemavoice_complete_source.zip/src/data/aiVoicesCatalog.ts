export interface AIVoiceItem {
  id: string;
  name: string;
  nameEn: string;
  subtitle: string;
  dialect: string;
  dialectLabel: string;
  flag: string;
  gender: 'male' | 'female';
  glassGradient: string;
  category: string;
  sampleQuote: string;
  previewUrl: string;
  isVerified: boolean;
  tag: string;
  sampleFrequency: string;
}

export const AI_VOICES_CATALOG: AIVoiceItem[] = [
  {
    id: 'voice-ai-tariq-pro',
    name: 'طارق AI (التوأم الصوتي)',
    nameEn: 'Tariq AI Pro',
    subtitle: 'صوت جهوري وقور ومخملي معتمد للمؤسسات والإنتاج الوثائقي والإعلانات المصرفية الكبرى.',
    dialect: 'سعودي',
    dialectLabel: 'سعودي نجدي ورسمي',
    flag: '🇸🇦',
    gender: 'male',
    glassGradient: 'radial-gradient(circle at 30% 30%, #3b82f6 0%, #1d4ed8 55%, #0f172a 100%)',
    category: 'إعلاني وبنكي موثق',
    sampleQuote: 'نبتكر حلول الغد بثقة اليوم، لأن طموحنا لا يعرف المستحيل في أرض العطاء والتطور المستمر.',
    previewUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=ambient-sound.mp3',
    isVerified: true,
    tag: 'توأم صوتي معتمد',
    sampleFrequency: '48kHz HD Studio'
  },
  {
    id: 'voice-ai-sara-tech',
    name: 'سارة AI (التفاعلية)',
    nameEn: 'Sara AI Interactive',
    subtitle: 'نبرة تفاعلية حيوية وودودة، ملهمة للشركات وخدمة العملاء والمنصات التعليمية والتطبيقات الذكية.',
    dialect: 'خليجي',
    dialectLabel: 'خليجي وحجازي معاصر',
    flag: '🇸🇦',
    gender: 'female',
    glassGradient: 'radial-gradient(circle at 30% 30%, #f43f5e 0%, #be123c 60%, #4c0519 100%)',
    category: 'حوارية وتفاعلية',
    sampleQuote: 'أهلاً بك في منصتك، كيف يمكنني مساعدتك في تسهيل أعمالك والارتقاء بتجربة عملائك اليوم؟',
    previewUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=ambient-sound.mp3',
    isVerified: true,
    tag: 'تفاعلي فائق الدقة',
    sampleFrequency: '48kHz HD Studio'
  },
  {
    id: 'voice-ai-nour-ads',
    name: 'نور AI (الإعلانات الرقمية)',
    nameEn: 'Nour AI Ads',
    subtitle: 'نبرة حماسية عفوية وسريعة البديهة، مثالية لحملات السوشيال ميديا وريلز وتطبيقات التجارة الإلكترونية.',
    dialect: 'مصري',
    dialectLabel: 'لهجة مصرية بيضاء سريعة',
    flag: '🇪🇬',
    gender: 'female',
    glassGradient: 'radial-gradient(circle at 30% 30%, #f97316 0%, #c2410c 60%, #431407 100%)',
    category: 'إعلانات وترويج',
    sampleQuote: 'معاك خطوة بخطوة عشان نوصل فكرتك لكل الناس بأسهل وأسرع طريقة وبأعلى تفاعل!',
    previewUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=ambient-sound.mp3',
    isVerified: true,
    tag: 'إعلانات سوشيال',
    sampleFrequency: '48kHz HD Studio'
  },
  {
    id: 'voice-ai-karim-narrator',
    name: 'كريم AI (الراوي المخملي)',
    nameEn: 'Karim AI Narrator',
    subtitle: 'خامة سينمائية دافئة وإيقاع روائي متزن، مخصص للوثائقيات والبودكاست وسرد القصص والروايات المؤثرة.',
    dialect: 'شامي',
    dialectLabel: 'شامي سوري وفصحى سينمائية',
    flag: '🇸🇾',
    gender: 'male',
    glassGradient: 'radial-gradient(circle at 30% 30%, #8b5cf6 0%, #6d28d9 60%, #2e1065 100%)',
    category: 'سرد وكتب صوتية',
    sampleQuote: 'في كل زاوية عتيقة قصة تروى، وتفاصيل تسكن الذاكرة لتبعث في النفس الدفء والسكينة.',
    previewUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=ambient-sound.mp3',
    isVerified: true,
    tag: 'سرد سينمائي',
    sampleFrequency: '48kHz HD Studio'
  },
  {
    id: 'voice-ai-zeyad-formal',
    name: 'زياد الفصيح AI',
    nameEn: 'Zeyad AI Fusha',
    subtitle: 'فصحى معيارية مشكولة بدقة متناهية ونطق أكاديمي سليم، للمناهج التعليمية والمقررات الرسمية والمؤتمرات.',
    dialect: 'فصحى',
    dialectLabel: 'لغة عربية فصحى معيارية',
    flag: '🌍',
    gender: 'male',
    glassGradient: 'radial-gradient(circle at 30% 30%, #10b981 0%, #047857 60%, #022c22 100%)',
    category: 'تعليمي ورسمي',
    sampleQuote: 'إن المعرفة هي الركيزة الكبرى في بناء المجتمعات واستدامة الحضارات عبر العصور.',
    previewUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=ambient-sound.mp3',
    isVerified: true,
    tag: 'فصحى مشكولة',
    sampleFrequency: '48kHz HD Studio'
  },
  {
    id: 'voice-ai-sofia-luxury',
    name: 'صوفيا AI (المغاربي الأنيق)',
    nameEn: 'Sofia AI Luxury',
    subtitle: 'نبرة مغاربية ناعمة وأنيقة للمنتجات الفاخرة، والسيارات الفارهة، والإعلانات الراقية متعددة الثقافات.',
    dialect: 'مغاربي',
    dialectLabel: 'لهجة مغاربية ناعمة للمنتجات الفاخرة',
    flag: '🇲🇦',
    gender: 'female',
    glassGradient: 'radial-gradient(circle at 30% 30%, #ec4899 0%, #9d174d 60%, #500724 100%)',
    category: 'إعلانات فاخرة',
    sampleQuote: 'حين تجتمع الحرفية الأصيلة مع أرقى معايير الابتكار، تولد تجربة استثنائية تأسر الحواس.',
    previewUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=ambient-sound.mp3',
    isVerified: true,
    tag: 'علامات فاخرة',
    sampleFrequency: '48kHz HD Studio'
  }
];
