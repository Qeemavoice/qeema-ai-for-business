import React, { useState, useEffect, Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';

// Public SEO Page Components (src/pages/)
import { HomePage } from './pages/HomePage';
import { VoicesPage } from './pages/VoicesPage';
import { BookingVoicePage } from './pages/BookingVoicePage';
import { BlogsPage } from './pages/BlogsPage';
import { BlogDetailsPage } from './pages/BlogDetailsPage';
import { JobsPage } from './pages/JobsPage';
import { GuidesPage } from './pages/GuidesPage';
import { AboutUsPage } from './pages/AboutUsPage';
import { ContactUsPage } from './pages/ContactUsPage';
import { TermsOfUsePage } from './pages/TermsOfUsePage';
import { FaqsPage } from './pages/FaqsPage';
import { BookingStepsPage } from './pages/BookingStepsPage';
import { OurWorksPage } from './pages/OurWorksPage';
import { CategoriesPage } from './pages/CategoriesPage';

// Commercial & Dialect Services Pages
import { DubbingServicePage } from './pages/DubbingServicePage';
import { AudiobooksServicePage } from './pages/AudiobooksServicePage';
import { PodcastServicePage } from './pages/PodcastServicePage';
import { IvrServicePage } from './pages/IvrServicePage';
import { TextToSpeechPage } from './pages/TextToSpeechPage';
import { PricingPage } from './pages/PricingPage';
import { SaudiVoiceOverPage } from './pages/SaudiVoiceOverPage';
import { EmiratiVoiceOverPage } from './pages/EmiratiVoiceOverPage';
import { EgyptianVoiceOverPage } from './pages/EgyptianVoiceOverPage';
import { NotFoundPage } from './pages/NotFoundPage';

// Internal Views & Modals
import { ClientDashboardView } from './components/ClientDashboardView';
import { VoiceTalentDashboardView } from './components/talent/VoiceTalentDashboardView';
import { NarratorClaimView } from './components/talent/NarratorClaimView';
import { AIVoiceCloneWizard } from './components/talent/AIVoiceCloneWizard';
import { AdminView } from './components/AdminView';
import { GenerateVoiceView } from './components/GenerateVoiceView';
import { ChatbotView } from './components/ChatbotView';

// Interactive Overlays / Modals
import { TopUpCreditsModal } from './components/TopUpCreditsModal';
import { BusinessDemoModal } from './components/BusinessDemoModal';
import { BookHumanVoiceModal } from './components/BookHumanVoiceModal';
import { ProjectChangelogModal } from './components/ProjectChangelogModal';
import { AuthModal } from './components/AuthModal';

import { Voice, Company, User, Generation, Plan } from './types';
import { api } from './lib/api';

// Lazy loaded non-blocking widgets
const AssistantWidget = lazy(() => import('./components/ai-assistant/AssistantWidget').then(m => ({ default: m.AssistantWidget })));

// Layout wrapper to control Header/Footer visibility on private workspaces
function AppLayout({ 
  children,
  currentCompany,
  currentUser,
  balanceCredits,
  isLoggedIn,
  onOpenLogin,
  onOpenSignup,
  onLogout,
  onOpenChangelog
}: {
  children: React.ReactNode;
  currentCompany: Company | null;
  currentUser: User | null;
  balanceCredits: number;
  isLoggedIn: boolean;
  onOpenLogin: () => void;
  onOpenSignup: () => void;
  onLogout: () => void;
  onOpenChangelog: () => void;
}) {
  const location = useLocation();
  const path = location.pathname;

  const isWorkspaceDashboard = path === '/ar/dashboard' || 
    path === '/ar/talent-dashboard' || 
    path === '/ar/talent-profile' || 
    path === '/ar/talent-earnings' || 
    path === '/ar/ai-voice-setup';

  return (
    <div className="min-h-screen flex flex-col bg-[#FDFBF9] text-[#0F172A] font-['IBM_Plex_Sans_Arabic','Cairo',sans-serif]">
      {!isWorkspaceDashboard && (
        <Header
          currentCompany={currentCompany}
          currentUser={currentUser}
          balanceCredits={balanceCredits}
          isLoggedIn={isLoggedIn}
          onOpenLogin={onOpenLogin}
          onOpenSignup={onOpenSignup}
          onLogout={onLogout}
        />
      )}

      <main className="flex-1">
        {children}
      </main>

      {!isWorkspaceDashboard && (
        <Footer onOpenChangelog={onOpenChangelog} />
      )}
    </div>
  );
}

export default function App() {
  const [currentCompany, setCurrentCompany] = useState<Company | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [balanceCredits, setBalanceCredits] = useState<number>(24500);
  const [availableCompanies, setAvailableCompanies] = useState<Company[]>([]);
  const [voices, setVoices] = useState<Voice[]>([]);

  // Modals state
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  const [isChangelogOpen, setIsChangelogOpen] = useState(false);
  const [bookingVoice, setBookingVoice] = useState<Voice | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | null>(null);

  // Initialize data on mount
  useEffect(() => {
    const initData = async () => {
      try {
        const [meRes, voicesRes] = await Promise.all([
          api.getMe(),
          api.getVoices()
        ]);
        setCurrentCompany(meRes.company);
        setCurrentUser(meRes.user);
        setBalanceCredits(meRes.balanceCredits);
        setAvailableCompanies(meRes.availableCompanies);
        setVoices(voicesRes.voices);
      } catch (err) {
        console.error('Error initializing data:', err);
      }
    };
    initData();
  }, []);

  const handleSwitchCompany = async (companyId: string) => {
    try {
      const res = await api.switchCompany(companyId);
      setCurrentCompany(res.company);
      setBalanceCredits(res.balanceCredits);
    } catch (err) {
      console.error('Error switching company:', err);
    }
  };

  return (
    <BrowserRouter>
      <AppLayout
        currentCompany={currentCompany}
        currentUser={currentUser}
        balanceCredits={balanceCredits}
        isLoggedIn={isLoggedIn}
        onOpenLogin={() => setAuthModalMode('login')}
        onOpenSignup={() => setAuthModalMode('signup')}
        onLogout={() => setIsLoggedIn(false)}
        onOpenChangelog={() => setIsChangelogOpen(true)}
      >
        <Routes>
          {/* Section 1: / redirects to /ar via <Navigate replace /> */}
          <Route path="/" element={<Navigate to="/ar" replace />} />

          {/* Section 1 & 2: Public Real SEO Routes matching Laravel mapping */}
          <Route 
            path="/ar" 
            element={
              <HomePage
                voices={voices}
                onOpenDemo={() => setIsDemoOpen(true)}
                onOpenSignup={() => setAuthModalMode('signup')}
                onOpenLogin={() => setAuthModalMode('login')}
                isLoggedIn={isLoggedIn}
                onOpenTopUp={() => setIsTopUpOpen(true)}
                onSelectForBooking={(voice) => setBookingVoice(voice)}
              />
            } 
          />

          <Route 
            path="/ar/voices" 
            element={
              <VoicesPage
                voices={voices}
                onSelectForBooking={(voice) => setBookingVoice(voice)}
              />
            } 
          />

          <Route 
            path="/ar/booking/:slug" 
            element={<BookingVoicePage voices={voices} />} 
          />

          <Route path="/ar/blogs" element={<BlogsPage />} />
          <Route path="/ar/blogs/details/:slug" element={<BlogDetailsPage />} />
          <Route path="/ar/jobs" element={<JobsPage />} />
          <Route path="/ar/guides" element={<GuidesPage />} />
          <Route path="/ar/p/about-us" element={<AboutUsPage />} />
          <Route path="/ar/contact-us" element={<ContactUsPage />} />
          <Route path="/ar/p/terms-of-use" element={<TermsOfUsePage />} />
          <Route path="/ar/faqs" element={<FaqsPage />} />
          <Route path="/ar/booking-steps" element={<BookingStepsPage />} />
          <Route path="/ar/our-works" element={<OurWorksPage />} />
          <Route path="/ar/categories" element={<CategoriesPage />} />

          {/* Commercial & Dialect Services */}
          <Route path="/ar/services/dubbing" element={<DubbingServicePage />} />
          <Route path="/ar/services/audiobooks" element={<AudiobooksServicePage />} />
          <Route path="/ar/services/podcast" element={<PodcastServicePage />} />
          <Route path="/ar/services/ivr" element={<IvrServicePage />} />
          <Route path="/ar/text-to-speech" element={<TextToSpeechPage />} />
          <Route path="/ar/pricing" element={<PricingPage />} />
          <Route path="/ar/saudi-voice-over" element={<SaudiVoiceOverPage />} />
          <Route path="/ar/emirati-voice-over" element={<EmiratiVoiceOverPage />} />
          <Route path="/ar/egyptian-voice-over" element={<EgyptianVoiceOverPage />} />

          {/* Private / Operational Routes (with noindex) */}
          <Route 
            path="/ar/dashboard" 
            element={
              <ClientDashboardView
                currentCompany={currentCompany}
                currentUser={currentUser}
                balanceCredits={balanceCredits}
                voices={voices}
                availableCompanies={availableCompanies}
                isLoggedIn={isLoggedIn}
                onSwitchCompany={handleSwitchCompany}
                onNavigate={() => {}}
                onOpenTopUp={() => setIsTopUpOpen(true)}
                onOpenDemo={() => setIsDemoOpen(true)}
                onOpenLogin={() => setAuthModalMode('login')}
                onOpenSignup={() => setAuthModalMode('signup')}
              />
            } 
          />

          <Route 
            path="/ar/talent-dashboard" 
            element={<VoiceTalentDashboardView onNavigate={() => {}} />} 
          />
          <Route 
            path="/ar/talent-profile" 
            element={<VoiceTalentDashboardView initialSubPage="profile" onNavigate={() => {}} />} 
          />
          <Route 
            path="/ar/talent-earnings" 
            element={<VoiceTalentDashboardView initialSubPage="earnings" onNavigate={() => {}} />} 
          />
          <Route 
            path="/ar/claim" 
            element={<NarratorClaimView onNavigate={() => {}} />} 
          />
          <Route 
            path="/claim/:token" 
            element={<NarratorClaimView onNavigate={() => {}} />} 
          />
          <Route 
            path="/ar/ai-voice-setup" 
            element={<AIVoiceCloneWizard onNavigate={() => {}} />} 
          />
          <Route 
            path="/ar/generate" 
            element={
              <GenerateVoiceView
                voices={voices}
                balanceCredits={balanceCredits}
                currentCompany={currentCompany}
                isLoggedIn={isLoggedIn}
                onRequireAuth={() => setAuthModalMode('login')}
                onOpenTopUp={() => setIsTopUpOpen(true)}
                onGenerationComplete={async () => {
                  const meRes = await api.getMe();
                  setBalanceCredits(meRes.balanceCredits);
                }}
              />
            } 
          />
          <Route 
            path="/ar/chatbot" 
            element={<ChatbotView onNavigate={() => {}} />} 
          />
          <Route 
            path="/ar/admin" 
            element={<AdminView voices={voices} onVoicesChange={v => setVoices(v)} />} 
          />

          {/* 404 Catch-All */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </AppLayout>

      {/* Lazy loaded Assistant Widget */}
      <Suspense fallback={null}>
        <AssistantWidget
          voices={voices}
          currentCompany={currentCompany}
          currentUser={currentUser}
          balanceCredits={balanceCredits}
          onNavigate={() => {}}
          onOpenTopUp={() => setIsTopUpOpen(true)}
        />
      </Suspense>

      {/* Global Interactive Modals */}
      {isTopUpOpen && (
        <TopUpCreditsModal
          isOpen={isTopUpOpen}
          onClose={() => setIsTopUpOpen(false)}
          currentCompany={currentCompany}
          currentUser={currentUser}
          onPaymentSuccess={async (newBalance) => {
            setBalanceCredits(newBalance);
            setIsTopUpOpen(false);
          }}
        />
      )}

      {isDemoOpen && (
        <BusinessDemoModal
          isOpen={isDemoOpen}
          onClose={() => setIsDemoOpen(false)}
        />
      )}

      {bookingVoice && (
        <BookHumanVoiceModal
          isOpen={Boolean(bookingVoice)}
          onClose={() => setBookingVoice(null)}
          voice={bookingVoice}
        />
      )}

      {isChangelogOpen && (
        <ProjectChangelogModal
          isOpen={isChangelogOpen}
          onClose={() => setIsChangelogOpen(false)}
        />
      )}

      {authModalMode && (
        <AuthModal
          isOpen={Boolean(authModalMode)}
          onClose={() => setAuthModalMode(null)}
          mode={authModalMode}
          onAuthSuccess={async () => {
            setIsLoggedIn(true);
            setAuthModalMode(null);
            const meRes = await api.getMe();
            setCurrentCompany(meRes.company);
            setCurrentUser(meRes.user);
            setBalanceCredits(meRes.balanceCredits);
          }}
        />
      )}
    </BrowserRouter>
  );
}
