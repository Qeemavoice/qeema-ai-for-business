import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Mic2, 
  Sparkles, 
  ShieldCheck, 
  Layers, 
  Users, 
  Coins, 
  Mail, 
  Globe2, 
  Briefcase, 
  HelpCircle,
  FileCode
} from 'lucide-react';

interface FooterProps {
  onOpenChangelog?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenChangelog }) => {
  return (
    <footer className="bg-slate-950 text-white border-t border-slate-800 pt-16 pb-12" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Column (lg:col-span-2) */}
          <div className="lg:col-span-2 space-y-4">
            <Link 
              to="/ar" 
              className="flex items-center select-none group w-fit"
            >
              <img 
                src="/assets/aistudio/qeemavoice_logo_5d0c91ae.png" 
                alt="قيمة فويس - Qeema Voice" 
                width="145"
                height="50"
                className="h-10 w-auto object-contain transition-transform group-hover:scale-[1.02] brightness-0 invert"
              />
            </Link>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              المنصة العربية الرائدة التي تجمع بين أصالة أكثر من 1000 معلق صوتي عربي حقيقي بكل اللهجات، وطبقة ذكاء اصطناعي صوتي مرخصة بموافقة المعلقين وتقاسم الأرباح معهم. جودة استوديو 48kHz، وهوية لا تتكرر.
            </p>

            <div className="pt-2">
              <Link
                to="/ar/jobs"
                className="inline-flex items-center gap-2 text-xs font-bold text-white bg-[#FF5500] hover:bg-[#E04800] px-4 py-2 rounded-xl transition shadow-sm"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>انضم إلى قيمة فويس كمعلق صوتي</span>
              </Link>
            </div>
          </div>

          {/* Col 2: خدمات التعليق الصوتي والإنتاج */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-[#FF7A29] uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" />
              <span>خدمات الإنتاج الصوتي</span>
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link to="/ar/services/dubbing" className="hover:text-white transition">
                  خدمة الدوبلاج العربي
                </Link>
              </li>
              <li>
                <Link to="/ar/services/audiobooks" className="hover:text-white transition">
                  تسجيل الكتب الصوتية
                </Link>
              </li>
              <li>
                <Link to="/ar/services/podcast" className="hover:text-white transition">
                  إنتاج مقدمات البودكاست
                </Link>
              </li>
              <li>
                <Link to="/ar/services/ivr" className="hover:text-white transition">
                  تسجيلات الرد الآلي IVR
                </Link>
              </li>
              <li>
                <Link to="/ar/text-to-speech" className="hover:text-white transition">
                  تحويل النص إلى صوت (TTS)
                </Link>
              </li>
              <li>
                <Link to="/ar/voices" className="hover:text-[#FF5500] font-bold transition">
                  مكتبة الأصوات العربية
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: فويس اوفر حسب اللهجة */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-[#FF7A29] uppercase tracking-wider flex items-center gap-1.5">
              <Globe2 className="w-3.5 h-3.5 text-blue-400" />
              <span>فويس اوفر باللهجات</span>
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link to="/ar/saudi-voice-over" className="hover:text-white transition">
                  فويس اوفر سعودي
                </Link>
              </li>
              <li>
                <Link to="/ar/emirati-voice-over" className="hover:text-white transition">
                  فويس اوفر إماراتي
                </Link>
              </li>
              <li>
                <Link to="/ar/egyptian-voice-over" className="hover:text-white transition">
                  فويس اوفر مصري
                </Link>
              </li>
              <li>
                <Link to="/ar/categories" className="hover:text-white transition">
                  كافة تصنيفات الأصوات
                </Link>
              </li>
              <li>
                <Link to="/ar/our-works" className="hover:text-white transition">
                  قصص النجاح للشركات
                </Link>
              </li>
              <li>
                <Link to="/ar/booking-steps" className="hover:text-white transition">
                  خطوات حجز معلق صوتي
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: الشركة والدعم والمعرفة */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-[#FF7A29] uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-emerald-400" />
              <span>المعرفة والدعم</span>
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link to="/ar/blogs" className="hover:text-white transition">
                  المدونة والأبحاث
                </Link>
              </li>
              <li>
                <Link to="/ar/pricing" className="hover:text-white transition font-bold text-slate-300">
                  أسعار التعليق الصوتي
                </Link>
              </li>
              <li>
                <Link to="/ar/faqs" className="hover:text-white transition">
                  الأسئلة الشائعة
                </Link>
              </li>
              <li>
                <Link to="/ar/guides" className="hover:text-white transition">
                  أدلة الإنتاج الصوتي
                </Link>
              </li>
              <li>
                <Link to="/ar/p/about-us" className="hover:text-white transition">
                  من نحن
                </Link>
              </li>
              <li>
                <Link to="/ar/contact-us" className="hover:text-white transition">
                  تواصل معنا
                </Link>
              </li>
              <li>
                <Link to="/ar/p/terms-of-use" className="hover:text-slate-400 transition text-[11px]">
                  الشروط والأحكام والتراخيص
                </Link>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            جميع الحقوق محفوظة © {new Date().getFullYear()} منصة قيمة فويس (Qeema Voice).
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>أصوات مرخصة وتراخيص تجارية موثقة</span>
            </span>
            <span>•</span>
            <span className="font-mono text-slate-400">https://qeemavoice.com</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
