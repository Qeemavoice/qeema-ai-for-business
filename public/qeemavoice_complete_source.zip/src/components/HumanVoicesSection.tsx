import React, { useState, useRef } from 'react';
import { Play, Pause, Heart, Sparkles, User, ArrowLeft, Check, SlidersHorizontal, ShieldCheck } from 'lucide-react';
import { GlassyVoiceOrb } from './GlassyVoiceOrb';

interface HumanVoiceDemoItem {
  id: string;
  name: string;
  talentName: string;
  sampleName: string;
  voiceDescription: string;
  gender: 'male' | 'female';
  ageRange: 'شبابي' | 'متوسط' | 'ناضج وقور';
  dialect: string;
  flag: string;
  style: string;
  glassGradient: string;
  sampleQuote: string;
  subtitle: string;
  previewUrl: string;
  avatar: string;
  hasAiTwin?: boolean;
  trustYears?: string;
}

const DEMO_HUMAN_VOICES: HumanVoiceDemoItem[] = [
  {
    id: 'h-sa-1',
    name: 'محمد.ع',
    talentName: 'محمد.ع',
    sampleName: 'عينة وثائقية ومؤسسية فخمة',
    gender: 'male',
    ageRange: 'متوسط',
    dialect: 'سعودي نجدي',
    flag: '🇸🇦',
    style: 'وثائقي ورسمي',
    glassGradient: 'radial-gradient(circle at 30% 30%, #1e3a8a 0%, #172554 60%, #030712 100%)',
    sampleQuote: 'في قلب الصحراء تزهر أفكار المستقبل، وترتسم ملامح الغد بهمة أبناء الوطن.',
    voiceDescription: 'خامة جهورية وقورة بنبرة مؤسسية عميقة، مخارج حروف فخمة تناسب الأفلام الوثائقية والخطابات الكبرى.',
    subtitle: 'خامة جهورية وقورة بنبرة مؤسسية عميقة، مخارج حروف فخمة تناسب الأفلام الوثائقية والخطابات الكبرى.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2874/2874-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    hasAiTwin: true,
    trustYears: '6 سنوات'
  },
  {
    id: 'h-sa-2',
    name: 'سارة.د',
    talentName: 'سارة.د',
    sampleName: 'عينة حوارية تفاعلية للتقنية والبودكاست',
    gender: 'female',
    ageRange: 'شبابي',
    dialect: 'خليجي وحجازي',
    flag: '🇸🇦',
    style: 'إعلاني وحواري',
    glassGradient: 'radial-gradient(circle at 30% 30%, #be123c 0%, #881337 60%, #4c0519 100%)',
    sampleQuote: 'أهلاً بك في منصتك، كيف يمكنني مساعدتك في تسهيل أعمالك اليوم؟',
    voiceDescription: 'نبرة شابة دافئة مفعمة بالحيوية والألفة، إيقاع متوازن ومريح يناسب المساعدين الأذكياء ومراكز الاتصال.',
    subtitle: 'نبرة شابة دافئة مفعمة بالحيوية والألفة، إيقاع متوازن ومريح يناسب المساعدين الأذكياء ومراكز الاتصال.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2873/2873-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    hasAiTwin: true,
    trustYears: '5 سنوات'
  },
  {
    id: 'h-eg-1',
    name: 'نور.إ',
    talentName: 'نور.إ',
    sampleName: 'عينة إعلانية ترويجية للسوشيال ميديا',
    gender: 'female',
    ageRange: 'شبابي',
    dialect: 'مصري أبيض',
    flag: '🇪🇬',
    style: 'سوشيال وإعلانات',
    glassGradient: 'radial-gradient(circle at 30% 30%, #c2410c 0%, #9a3412 60%, #431407 100%)',
    sampleQuote: 'معاك خطوة بخطوة عشان نوصل فكرتك لكل الناس بأسهل وأقرب طريقة.',
    voiceDescription: 'إيقاع مصري عفوي محبب ودافئ، أداء حركي مقنع يرفع معدلات التفاعل في الحملات الرقمية والريلز.',
    subtitle: 'إيقاع مصري عفوي محبب ودافئ، أداء حركي مقنع يرفع معدلات التفاعل في الحملات الرقمية والريلز.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2873/2873-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
    hasAiTwin: true,
    trustYears: '6 سنوات'
  },
  {
    id: 'h-em-1',
    name: 'سلطان.م',
    talentName: 'سلطان.م',
    sampleName: 'عينة مؤتمرات وإنتاج وطني رفيع',
    gender: 'male',
    ageRange: 'ناضج وقور',
    dialect: 'إماراتي رسمي',
    flag: '🇦🇪',
    style: 'حكومي ومؤسسي',
    glassGradient: 'radial-gradient(circle at 30% 30%, #065f46 0%, #064e3b 60%, #022c22 100%)',
    sampleQuote: 'رؤيتنا لا تعترف بالحدود، وطموحنا يصنع الفارق في كل قطاع حيوي.',
    voiceDescription: 'صوت إماراتي فخم ورزين بطبقة صوتية مهيبة، حضور صوتي راقٍ للمؤتمرات والإنتاج الوطني الفاخر.',
    subtitle: 'صوت إماراتي فخم ورزين بطبقة صوتية مهيبة، حضور صوتي راقٍ للمؤتمرات والإنتاج الوطني الفاخر.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2872/2872-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
    trustYears: '8 سنوات'
  },
  {
    id: 'h-lev-1',
    name: 'كريم.م',
    talentName: 'كريم.م',
    sampleName: 'عينة سرد روائي ووثائقي سينمائي',
    gender: 'male',
    ageRange: 'متوسط',
    dialect: 'شامي سوري',
    flag: '🇸🇾',
    style: 'سرد وثائقي وبودكاست',
    glassGradient: 'radial-gradient(circle at 30% 30%, #6d28d9 0%, #4c1d95 60%, #2e1065 100%)',
    sampleQuote: 'كل تفصيل يحكي قصة من القلب، ويعطي للمعنى أثراً لا ينسى.',
    voiceDescription: 'خامة مخملية آسرة تتقن التلوين الدرامي ومخارج الحروف الشامية والفصحى للروايات والإنتاج الضخم.',
    subtitle: 'خامة مخملية آسرة تتقن التلوين الدرامي ومخارج الحروف الشامية والفصحى للروايات والإنتاج الضخم.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2871/2871-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    hasAiTwin: true,
    trustYears: '7 سنوات'
  },
  {
    id: 'h-msa-1',
    name: 'عبدالرحمن.ف',
    talentName: 'عبدالرحمن.ف',
    sampleName: 'عينة فصحى أكاديمية ونشرات إخبارية',
    gender: 'male',
    ageRange: 'ناضج وقور',
    dialect: 'فصحى معيارية',
    flag: '🌍',
    style: 'نشرات وكتب صوتية',
    glassGradient: 'radial-gradient(circle at 30% 30%, #0369a1 0%, #075985 60%, #082f49 100%)',
    sampleQuote: 'إن المعرفة هي الركيزة الكبرى في بناء المجتمعات واستدامة الحضارات.',
    voiceDescription: 'فصحى معيارية نقية بأعلى درجات الفخامة والأصالة اللغوية، نطق مشكول محكم للمراجع والكتب.',
    subtitle: 'فصحى معيارية نقية بأعلى درجات الفخامة والأصالة اللغوية، نطق مشكول محكم للمراجع والكتب.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2870/2870-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80',
    trustYears: '6 سنوات'
  },
  {
    id: 'h-gulf-1',
    name: 'نوف.هـ',
    talentName: 'نوف.هـ',
    sampleName: 'عينة ترحيبية لأنظمة الرد الآلي IVR',
    gender: 'female',
    ageRange: 'متوسط',
    dialect: 'خليجي معاصر',
    flag: '🇰🇼',
    style: 'مؤسسي وخدمة عملاء',
    glassGradient: 'radial-gradient(circle at 30% 30%, #0e7490 0%, #155e75 60%, #083344 100%)',
    sampleQuote: 'يسرنا خدمتكم وتقديم أفضل الحلول المتكاملة لتلبية تطلعاتكم دائماً.',
    voiceDescription: 'صوت ترحيبي وقور ودافئ لخدمة العملاء، نبرة مريحة وواضحة تمنح المتصل تجربة موثوقة ومحترفة.',
    subtitle: 'صوت ترحيبي وقور ودافئ لخدمة العملاء، نبرة مريحة وواضحة تمنح المتصل تجربة موثوقة ومحترفة.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&auto=format&fit=crop&q=80',
    trustYears: '5 سنوات'
  },
  {
    id: 'h-mag-1',
    name: 'أمين.ف',
    talentName: 'أمين.ف',
    sampleName: 'عينة تسويقية وسردية متعددة اللغات',
    gender: 'male',
    ageRange: 'ناضج وقور',
    dialect: 'مغاربي وفصحى',
    flag: '🇲🇦',
    style: 'تسويق وإعلانات',
    glassGradient: 'radial-gradient(circle at 30% 30%, #7c2d12 0%, #431407 60%, #1c0502 100%)',
    sampleQuote: 'نبتكر حلولاً صوتية تعبر الحدود وتلهم جمهورك في كل مكان.',
    voiceDescription: 'صوت شمال أفريقي رخيم ومثقف، تلوين صوتي بالفرنسية والعربية بطلاقة وثقة بالغة.',
    subtitle: 'صوت شمال أفريقي رخيم ومثقف، تلوين صوتي بالفرنسية والعربية بطلاقة وثقة بالغة.',
    previewUrl: 'https://assets.mixkit.co/active_storage/sfx/2868/2868-preview.mp3',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80',
    trustYears: '7 سنوات'
  }
];

const DIALECT_FILTERS = [
  { key: 'all', label: 'الكل (1,000+)' },
  { key: 'سعودي', label: '🇸🇦 سعودي' },
  { key: 'إماراتي', label: '🇦🇪 إماراتي' },
  { key: 'مصري', label: '🇪🇬 مصري' },
  { key: 'شامي', label: '🇸🇾 شامي' },
  { key: 'خليجي', label: '🇰🇼 خليجي' },
  { key: 'فصحى', label: '🌍 فصحى معيارية' },
  { key: 'مغاربي', label: '🇲🇦 مغاربي' },
];

interface HumanVoicesSectionProps {
  onSelectVoice: (voice: HumanVoiceDemoItem) => void;
  onExploreLibrary: () => void;
}

export const HumanVoicesSection: React.FC<HumanVoicesSectionProps> = ({
  onSelectVoice,
  onExploreLibrary
}) => {
  const [selectedDialect, setSelectedDialect] = useState('all');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<Record<string, boolean>>({});
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const toggleFavorite = (id: string) => {
    setFavorites(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handlePlayVoice = (voice: HumanVoiceDemoItem) => {
    if (playingId === voice.id) {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      setPlayingId(null);
      return;
    }

    if (audioRef.current) {
      audioRef.current.pause();
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }

    setPlayingId(voice.id);

    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(voice.sampleQuote);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.95;
      utterance.onend = () => setPlayingId(null);
      utterance.onerror = () => setPlayingId(null);
      window.speechSynthesis.speak(utterance);
    } else {
      const audio = new Audio(voice.previewUrl);
      audioRef.current = audio;
      audio.play().catch(() => setPlayingId(null));
      audio.onended = () => setPlayingId(null);
    }
  };

  const filteredVoices = selectedDialect === 'all'
    ? DEMO_HUMAN_VOICES
    : DEMO_HUMAN_VOICES.filter(v => v.dialect.includes(selectedDialect));

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16" dir="rtl">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            أصوات حقيقية تمنح علامتك المصداقية.
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2 max-w-2xl leading-relaxed">
            استكشف نخبة المعلقين الصوتيين العرب المحترفين المعتمدين، واستمع لنماذج استوديو بدقة احترافية مع إمكانية الحجز المباشر أو الاستماع لتجربة AI قبل الحجز
          </p>
        </div>

        <button
          onClick={onExploreLibrary}
          className="inline-flex items-center gap-2 text-sm font-bold text-slate-900 hover:text-[#FF5500] group transition-colors self-start md:self-auto cursor-pointer"
        >
          <span>تصفح كافة الأصوات البشرية (1,000+)</span>
          <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
        </button>
      </div>

      {/* Dialect Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 no-scrollbar">
        <div className="flex items-center gap-1.5 text-xs text-slate-500 pl-2 shrink-0">
          <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
          <span>تصفية باللهجة:</span>
        </div>
        {DIALECT_FILTERS.map(filter => (
          <button
            key={filter.key}
            onClick={() => setSelectedDialect(filter.key)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              selectedDialect === filter.key
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Voice Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {filteredVoices.map(voice => {
          const isPlaying = playingId === voice.id;
          const isFav = !!favorites[voice.id];

          return (
            <div
              key={voice.id}
              className={`group bg-white rounded-2xl p-5 border transition-all duration-300 flex flex-col justify-between hover:shadow-xl hover:shadow-slate-900/5 ${
                isPlaying ? 'border-[#FF5500] ring-1 ring-[#FF5500]/30' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              {/* Card Top: Avatar & Info */}
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    {/* Voice Glassy Orb Avatar (Matching Voices Page) */}
                    <GlassyVoiceOrb
                      gradient={voice.glassGradient}
                      isPlaying={isPlaying}
                      isVerified={true}
                      onTogglePlay={(e) => {
                        e.stopPropagation();
                        handlePlayVoice(voice);
                      }}
                      size="lg"
                    />

                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-bold text-slate-900 text-sm group-hover:text-[#FF5500] transition-colors">
                          {voice.name}
                        </h3>
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                        <span>{voice.flag}</span>
                        <span className="font-medium text-slate-700">{voice.dialect}</span>
                        <span>•</span>
                        <span>{voice.gender === 'female' ? 'أنثوي' : 'رجالي'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Favorite Toggle */}
                  <button
                    onClick={() => toggleFavorite(voice.id)}
                    className="p-1.5 rounded-lg text-slate-300 hover:text-rose-500 hover:bg-rose-50 transition-colors cursor-pointer"
                    title={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                  >
                    <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>
                </div>

                {/* Subtitle / Rich Description (Matching Voices Page Description) */}
                <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 mb-3" title={voice.subtitle}>
                  {voice.subtitle}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap items-center gap-1.5 mb-3">
                  <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200/60 font-medium">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                    <span>موثوق منذ {voice.trustYears || '6 سنوات'}</span>
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                    {voice.ageRange}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200/50 font-medium">
                    {voice.style}
                  </span>
                </div>

                {/* Sample Quote */}
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed italic bg-slate-50/80 p-2.5 rounded-xl mb-4 border border-slate-100">
                  "{voice.sampleQuote}"
                </p>
              </div>

              {/* Card Bottom: Play button & Use Voice */}
              <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => handlePlayVoice(voice)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isPlaying
                      ? 'bg-slate-950 text-white'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                  }`}
                >
                  {isPlaying ? (
                    <>
                      <Pause className="w-3.5 h-3.5 fill-current" />
                      <span>إيقاف</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                      <span>استماع للنموذج</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => onSelectVoice(voice)}
                  className="py-2 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer shadow-xs hover:bg-slate-950 active:scale-95"
                >
                  احجز الصوت
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
