import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Building2, 
  Mic2, 
  Layers, 
  Play, 
  Pause, 
  CheckCircle2, 
  ArrowLeft, 
  Volume2, 
  Zap, 
  ShieldCheck, 
  Radio, 
  Globe2, 
  Film, 
  BookOpen, 
  ShoppingBag,
  Coins,
  ChevronRight,
  User,
  Copy,
  Sliders,
  ExternalLink,
  Lock
} from 'lucide-react';
import { ActiveView, Voice } from '../types';
import { VoiceOrb, OrbMode, OrbState } from './VoiceOrb';
import { HeroAudioPlayer } from './HeroAudioPlayer';
import { ProductSwitcher } from './ProductSwitcher';
import { TextToSpeechPlayground } from './TextToSpeechPlayground';
import { HumanVoicesSection } from './HumanVoicesSection';
import { AIVoicesSection } from './AIVoicesSection';
import { VoiceTwinsSection } from './VoiceTwinsSection';
import { EnterpriseCapabilitiesSection } from './EnterpriseCapabilitiesSection';
import { TrustedEnterpriseBrands } from './TrustedEnterpriseBrands';

interface B2BHomeProps {
  onNavigate: (view: ActiveView, extra?: { voiceId?: string; text?: string; tab?: 'human' | 'ai' | 'my-voices' }) => void;
  onOpenDemo: () => void;
  onOpenSignup?: () => void;
  onOpenLogin?: () => void;
  isLoggedIn?: boolean;
  onOpenTopUp: () => void;
  voices: Voice[];
  onSelectForBooking?: (voice: Voice) => void;
}

interface HeroPreset {
  title: string;
  subtitle: string;
  primaryCta: string;
  secondaryCta: string;
  voiceName: string;
  dialect: string;
  gender: string;
  category: string;
  audioUrl: string;
  sampleQuote: string;
}

const HERO_PRESETS: Record<OrbMode, HeroPreset> = {
  ai: {
    title: 'مستقبل الصوت العربي، مصمم للتوسع.',
    subtitle: 'أصوات بشرية، أصوات AI، وتوائم صوتية، في منصة واحدة.',
    primaryCta: 'جرّب صوت AI الآن',
    secondaryCta: 'اكتشف الأصوات',
    voiceName: 'سارة الذكية (Sarah AI)',
    dialect: 'فصحى معيارية معاصرة',
    gender: 'female',
    category: 'ذكاء اصطناعي فوري',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2874/2874-preview.mp3',
    sampleQuote: 'مرحبًا بك في Qeema Voice. اكتشف مستقبل الصوت العربي بتقنيات الذكاء الاصطناعي التوليدي.'
  },
  human: {
    title: 'أصوات بشرية حقيقية.',
    subtitle: 'اكتشف أصواتًا عربية احترافية تناسب علامتك ومحتواك من نخبة المعلقين المعتمدين في الوطن العربي.',
    primaryCta: 'استكشف الأصوات',
    secondaryCta: 'حجز جلسة تسجيل',
    voiceName: 'عينة وثائقية ومؤسسية فخمة',
    dialect: 'سعودي وقور',
    gender: 'male',
    category: 'عينة صوت بشري 48kHz',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2872/2872-preview.mp3',
    sampleQuote: 'في كل كلمة ننطقها، نزرع الثقة ونصنع أثراً يدوم في ذاكرة المستمعين.'
  },
  twins: {
    title: 'صوتك، بنسخة ذكية.',
    subtitle: 'أنشئ توأمًا صوتيًا يحافظ على هويتك ونبرتك لإنتاج المحتوى على نطاق واسع دون إعادة التسجيل.',
    primaryCta: 'أنشئ توأمك الصوتي',
    secondaryCta: 'استكشف التوائم الرقمية',
    voiceName: 'توأم نور الصوتي (AI Twin)',
    dialect: 'إماراتي / خليجي',
    gender: 'female',
    category: 'توأم رقمي مرخص',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2873/2873-preview.mp3',
    sampleQuote: 'هذا صوتي الذكي المعتمد، ينتج مئات الساعات بجودة مطابقة لتسجيلي الحقيقي.'
  },
  tts: {
    title: 'تحويل النص إلى صوت فائق الدقة.',
    subtitle: 'محرك نطق ذكي يضبط التشكيل ومخارج الحروف العربية بدقة استثنائية للمقالات، الكتب، والأنظمة التفاعلية.',
    primaryCta: 'تجربة استوديو TTS',
    secondaryCta: 'الشات بوت الذكي',
    voiceName: 'محرك النطق العصبي (Qeema Neural HD)',
    dialect: 'فصحى معيارية مشكولة',
    gender: 'male',
    category: 'نص إلى صوت (Text to Speech)',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2870/2870-preview.mp3',
    sampleQuote: 'يسرنا تمكين الشركات من تحويل ملايين الكلمات إلى صوت عربي سليم خلال دقائق.'
  },
  cloning: {
    title: 'استنساخ صوتي رقمي آمن.',
    subtitle: 'استنسخ صوت المتحدث في دقائق معدودة مع حماية كاملة لحقوق الملكية والتراخيص التجارية.',
    primaryCta: 'بدء استنساخ الصوت',
    secondaryCta: 'شروط التراخيص والأمان',
    voiceName: 'نموذج استنساخ تجاري',
    dialect: 'مصري معاصر',
    gender: 'male',
    category: 'Instant Voice Clone',
    audioUrl: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3',
    sampleQuote: 'تقنية الاستنساخ الصوتي تتيح لك الحفاظ على حضورك الصوتي الدائم في كل حملاتك.'
  }
};

export const B2BHome: React.FC<B2BHomeProps> = ({ 
  onNavigate, 
  onOpenDemo, 
  onOpenSignup, 
  onOpenLogin,
  isLoggedIn = false,
  voices,
  onSelectForBooking
}) => {
  // Active category / product navigation state - يبدأ بالأصوات البشرية
  const [activeTab, setActiveTab] = useState<OrbMode>('human');

  // Audio & Orb States
  const [isPlaying, setIsPlaying] = useState(false);
  const [orbState, setOrbState] = useState<OrbState>('idle');
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(12);

  // Hidden audio element for real audio and Web Audio API node binding
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const activePreset = HERO_PRESETS[activeTab] || HERO_PRESETS.ai;

  // Initialize and handle audio playback
  useEffect(() => {
    const audio = new Audio();
    audio.crossOrigin = 'anonymous';
    audioElementRef.current = audio;

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const onEnded = () => {
      setIsPlaying(false);
      setOrbState('completed');
      setTimeout(() => setOrbState('idle'), 1500);
      setCurrentTime(0);
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.pause();
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
    };
  }, []);

  // Update audio source when preset changes
  useEffect(() => {
    if (audioElementRef.current) {
      const wasPlaying = isPlaying;
      audioElementRef.current.pause();
      audioElementRef.current.src = activePreset.audioUrl;
      setCurrentTime(0);
      setDuration(12);

      if (wasPlaying) {
        audioElementRef.current.play().catch(e => console.log('Audio autoplay prevented:', e));
        setIsPlaying(true);
        setOrbState('playing');
      } else {
        setIsPlaying(false);
        setOrbState('idle');
      }
    }
  }, [activeTab]);

  // Play / Pause toggle
  const togglePlay = () => {
    if (!audioElementRef.current) return;

    if (isPlaying) {
      audioElementRef.current.pause();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsPlaying(false);
      setOrbState('idle');
    } else {
      audioElementRef.current.src = activePreset.audioUrl;
      audioElementRef.current.play()
        .then(() => {
          setIsPlaying(true);
          setOrbState('playing');
        })
        .catch(err => {
          console.debug('Playing synthetic voice via SpeechSynthesis fallback:', err);
          // Fallback to speech synthesis
          if ('speechSynthesis' in window) {
            const utter = new SpeechSynthesisUtterance(activePreset.sampleQuote);
            utter.lang = 'ar-SA';
            utter.onend = () => {
              setIsPlaying(false);
              setOrbState('completed');
              setTimeout(() => setOrbState('idle'), 1200);
            };
            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(utter);
            setIsPlaying(true);
            setOrbState('playing');
          }
        });
    }
  };

  // Switch sample
  const handleSwitchSample = () => {
    const keys: OrbMode[] = ['ai', 'human', 'twins', 'tts', 'cloning'];
    const nextIdx = (keys.indexOf(activeTab) + 1) % keys.length;
    setActiveTab(keys[nextIdx]);
  };

  // Primary CTA handler based on current active tab
  const handlePrimaryCta = () => {
    if (activeTab === 'human') {
      onNavigate('voice-library', { tab: 'human' });
    } else if (activeTab === 'twins' || activeTab === 'cloning') {
      onNavigate('voice-clone');
    } else {
      onNavigate('generate');
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-28 selection:bg-[#FF5500] selection:text-white" dir="rtl">
      
      {/* ========================================================================= */}
      {/* 1. THE HERO SECTION: 3D LIVING VOICE ORB + DYNAMIC INTERACTION            */}
      {/* ========================================================================= */}
      <section className="relative pt-16 pb-16 sm:pt-20 sm:pb-20 md:pt-24 md:pb-24 overflow-hidden border-b border-slate-200/70">
        
        {/* Subtle Ambient Background Gradients */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[550px] bg-gradient-to-tr from-amber-500/10 via-blue-500/10 to-orange-500/10 rounded-full blur-3xl pointer-events-none -z-10" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">

          {/* Trusted Headline Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-50 border border-orange-200/90 text-[#FF5500] text-xs sm:text-sm font-black mb-5 shadow-xs animate-in fade-in">
            <Sparkles className="w-4 h-4 text-[#FF5500]" />
            <span>أكبر منصة عربية للتعليق الصوتي في الوطن العربي</span>
          </div>

          {/* Hero Headline */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-slate-950 tracking-tight leading-[1.25] max-w-4xl mx-auto mb-6 py-1">
            مستقبل الصوت العربي يبدأ بصوتٍ بشري.
          </h1>

          {/* Hero Subtitle */}
          <p className="text-base sm:text-lg lg:text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed mb-8 font-normal">
            أكبر منصة عربية للتعليق الصوتي في الوطن العربي، تجمع أكثر من 1,000 معلق محترف بكل اللهجات العربية، مدعومة بأدوات AI فائقة الدقة للإنتاج والتوسع.
          </p>

          {/* Fixed CTA Buttons Row */}
          <div className="flex flex-wrap items-center justify-center gap-3.5 mb-14">
            {/* 1. استكشف الأصوات البشرية */}
            <button
              onClick={() => onNavigate('voice-library', { tab: 'human' })}
              className="px-7 py-3.5 rounded-full bg-[#FF5500] hover:bg-[#E04800] text-white text-sm font-bold shadow-lg shadow-[#FF5500]/25 hover:scale-[1.02] active:scale-95 transition-all cursor-pointer flex items-center gap-2 border border-[#FF5500]"
            >
              <span>استكشف الأصوات البشرية</span>
              <ArrowLeft className="w-4 h-4" />
            </button>

            {/* 2. جرب صوت AI */}
            <button
              onClick={() => onNavigate('generate')}
              className="px-7 py-3.5 rounded-full bg-white hover:bg-slate-50 text-slate-900 text-sm font-bold border border-slate-200 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex items-center gap-2"
            >
              <span>جرب صوت AI</span>
            </button>

            {/* 3. إنشاء حساب */}
            <button
              onClick={onOpenSignup || onOpenDemo}
              className="px-7 py-3.5 rounded-full bg-orange-50/80 hover:bg-orange-100/90 text-[#FF5500] text-sm font-bold border border-orange-200/80 transition-all cursor-pointer flex items-center gap-1.5 shadow-xs hover:scale-[1.02] active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-[#FF5500]" />
              <span>إنشاء حساب</span>
            </button>
          </div>

          {/* ========================================================================= */}
          {/* THE INTEGRATED LIVE VOICE SHOWCASE CONSOLE (قسم المشغل التفاعلي المتكامل)  */}
          {/* ========================================================================= */}
          <div className="relative max-w-5xl mx-auto rounded-3xl bg-white/80 border border-slate-200/90 shadow-xl shadow-slate-900/[0.04] backdrop-blur-md p-5 sm:p-7 md:p-9">
            
            {/* Top Bar of the Showcase */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-5 border-b border-slate-100">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF5500] opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#FF5500]"></span>
                </span>
                <span>المشغل الصوتي التفاعلي الحي</span>
                <span className="text-slate-300">|</span>
                <span className="text-slate-500 font-normal">استمع لنماذج الصوت المباشرة لكل تقنية</span>
              </div>
              
              <div className="hidden sm:flex items-center gap-2 text-[11px] font-medium text-slate-500 bg-slate-100/70 px-3 py-1 rounded-full border border-slate-200/60">
                <span>تفاعل صوتي نقي</span>
                <span className="text-slate-300">•</span>
                <span className="text-slate-700 font-semibold">48kHz Ultra Studio</span>
              </div>
            </div>

            {/* If activeTab === 'tts' (نص إلى صوت), render the ElevenLabs-style Text-to-Speech Playground */}
            {activeTab === 'tts' ? (
              <div className="mb-6 animate-in fade-in duration-300">
                <TextToSpeechPlayground
                  onExploreVoices={() => onNavigate('voice-library', { tab: 'ai' })}
                />
              </div>
            ) : (
              <>
                {/* Organic 3D Voice Orb */}
                <div className="relative flex flex-col items-center justify-center py-2 mb-3">
                  <VoiceOrb
                    mode={activeTab}
                    state={orbState}
                    isPlaying={isPlaying}
                    audioElement={audioElementRef.current}
                    size={340}
                    onClick={togglePlay}
                    className="mx-auto"
                  />

                  {/* Quote Pill */}
                  <div className="max-w-lg mx-auto mt-3 px-4 py-2 rounded-2xl bg-slate-50/90 border border-slate-200/70 text-xs text-slate-600 italic">
                    "{activePreset.sampleQuote}"
                  </div>
                </div>

                {/* Minimalist Hero Audio Player */}
                <div className="mb-6">
                  <HeroAudioPlayer
                    isPlaying={isPlaying}
                    onTogglePlay={togglePlay}
                    voiceName={activePreset.voiceName}
                    dialect={activePreset.dialect}
                    gender={activePreset.gender}
                    category={activePreset.category}
                    mode={activeTab}
                    currentTime={currentTime}
                    duration={duration}
                    onSeek={(pct) => {
                      if (audioElementRef.current && duration > 0) {
                        audioElementRef.current.currentTime = pct * duration;
                        setCurrentTime(pct * duration);
                      }
                    }}
                    onSwitchSample={handleSwitchSample}
                  />
                </div>
              </>
            )}

            {/* ========================================================================= */}
            {/* INTEGRATED SUITE TABS (العناوين التابعة للقسم المتكامل)                    */}
            {/* ========================================================================= */}
            <div className="pt-4 border-t border-slate-100/90">
              <div className="flex items-center justify-center gap-2 mb-3">
                <span className="text-xs font-bold text-slate-500">
                  اختر التقنية الصوتية للاستماع المباشر وتجربة النبرات:
                </span>
              </div>

              {/* Product Switcher Tabs (5 Tabs without dubbing) */}
              <ProductSwitcher
                activeTab={activeTab}
                onSelectTab={(tab) => {
                  setActiveTab(tab);
                }}
              />

              {/* Contextual Descriptor Row directly tied to the active tab */}
              <div className="mt-4 pt-3 border-t border-slate-100/70 flex flex-col sm:flex-row items-center justify-between gap-2.5 px-2 text-xs">
                <div className="flex items-center gap-2 text-slate-600">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#FF5500] shrink-0" />
                  <span className="font-medium text-slate-700">
                    {activeTab === 'human' && 'معلقون وممثلون صوتيون محترفون بأكثر من 20 لهجة عربية للمشاريع الإعلانية والرسمية.'}
                    {activeTab === 'ai' && 'نماذج ذكاء اصطناعي صوتية فائقة الواقعية بنبرات ومخارج حروف عربية مضبوطة التشكيل بالكامل.'}
                    {activeTab === 'tts' && 'أستوديو تحويل النص إلى صوت (TTS) عالي الأداء للمقالات، الكتب الصوتية، والأنظمة التفاعلية.'}
                  </span>
                </div>

                <button
                  onClick={() => {
                    if (onOpenSignup) {
                      onOpenSignup();
                    } else if (onOpenDemo) {
                      onOpenDemo();
                    }
                  }}
                  className="px-6 py-2 rounded-full bg-slate-950 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-sm hover:shadow-md cursor-pointer shrink-0"
                >
                  إنشاء حساب
                </button>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* ========================================================================= */}
      {/* ENTERPRISE TRUSTED BRANDS SHOWCASE (Section based on Reference Image)      */}
      {/* ========================================================================= */}
      <TrustedEnterpriseBrands
        onReadStories={(storyId) => {
          onNavigate('customer-stories', { voiceId: storyId });
        }}
      />

      {/* ========================================================================= */}
      {/* 2. SECTION: HUMAN VOICES MARKETPLACE (1,000+ Real Voices)                 */}
      {/* ========================================================================= */}
      <div id="section-human-voices">
        <HumanVoicesSection
          onSelectVoice={(voice) => {
            if (onSelectForBooking) {
              const matchedVoice = voices.find(v => v.id === voice.id || v.name === voice.talentName || v.name === voice.name);
              const targetVoice = (matchedVoice || {
                id: voice.id,
                name: voice.talentName || voice.name,
                arabicName: voice.talentName || voice.name,
                gender: voice.gender || 'male',
                language: 'ar-SA',
                dialect: 'gulf',
                dialectLabel: voice.dialect,
                style: 'commercial',
                styleLabel: voice.style,
                previewUrl: voice.previewUrl,
                avatar: voice.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
                type: 'human',
                verified: true,
                rating: 4.9,
                totalGenerations: 140,
                pricePerMinuteCredits: 500,
                deliveryTimeDays: 3,
                wordCountLimit: 1500,
                isRecommended: true,
                useCases: ['commercial', 'narration'],
                provider: 'human',
                isActive: true
              }) as Voice;
              onSelectForBooking(targetVoice);
            } else {
              onNavigate('voice-library', { tab: 'human', voiceId: voice.id });
            }
          }}
          onExploreLibrary={() => onNavigate('voice-library', { tab: 'human' })}
        />
      </div>

      {/* ========================================================================= */}
      {/* 3. SECTION: AI VOICES INTERACTIVE GENERATION DEMO (Text to Speech Studio) */}
      {/* ========================================================================= */}
      <AIVoicesSection
        isLoggedIn={isLoggedIn}
        onOpenLogin={onOpenLogin}
        onOpenSignup={onOpenSignup}
        onOpenStudio={(params) => {
          onNavigate('generate', { text: params?.text, voiceId: params?.voiceId });
        }}
      />

      {/* ========================================================================= */}
      {/* 4. SECTION: INTERACTIVE TEXT CHATBOT & AI VOICE RECOMMENDATION (PHASE 1)  */}
      {/* ========================================================================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16" dir="rtl">
        <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-orange-950/40 rounded-3xl p-8 sm:p-12 text-white border border-slate-800 shadow-2xl relative overflow-hidden">
          {/* Ambient Glows */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF5500]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-5 text-right">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF5500]/20 border border-[#FF5500]/40 text-[#FF7733] text-xs font-bold shadow-xs">
                <Sparkles className="w-3.5 h-3.5" />
                <span>ميزة أطلقت حديثاً • المرحلة الأولى</span>
              </div>

              <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
                الشات بوت التفاعلي الذكي <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF7733] to-amber-400">
                  مستشارك لترشيح الأصوات ونماذج AI
                </span>
              </h2>

              <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl">
                أخبر الشات بوت بنوع مشروعك، النص المراد تسجيله، أو ميزانيتك، وسيقوم بتحليل المحتوى فورياً وترشيح أنسب الأصوات البشرية المعتمدة ونماذج الذكاء الاصطناعي مع إمكانية تجربة النبرة والانتقال إلى استوديو النطق بنقرة زر.
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                  <div className="text-[#FF7733] font-bold text-xs">ترشيح نماذج AI</div>
                  <div className="text-[11px] text-slate-400">اختيار النموذج الأدق للوثائقي، الإعلاني، أو التعليمي</div>
                </div>
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                  <div className="text-amber-400 font-bold text-xs">استماع فوري</div>
                  <div className="text-[11px] text-slate-400">معاينة مقاطع ونبرات الأصوات المرشحة مباشرة</div>
                </div>
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                  <div className="text-emerald-400 font-bold text-xs">ربط فوري بالاستوديو</div>
                  <div className="text-[11px] text-slate-400">نقل النص والصوت المختار إلى استوديو TTS بضغطة واحدة</div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => onNavigate('chatbot')}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#FF5500] to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-[#FF5500]/25 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>فتح الشات بوت وتجربة الترشيح</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onNavigate('generate')}
                  className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs sm:text-sm border border-white/10 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                  <span>استوديو تحويل النص إلى صوت (TTS)</span>
                </button>
              </div>
            </div>

            {/* Visual Chat Preview Card */}
            <div className="lg:col-span-5">
              <div className="bg-slate-900/90 rounded-2xl border border-white/10 p-4 shadow-xl space-y-3 font-sans text-right">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#FF5500] flex items-center justify-center text-white font-black text-xs">
                      ق
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">مستشار قيمة الصوتي الذكي</div>
                      <div className="text-[10px] text-emerald-400">متصل الآن • مرحلة 1</div>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-slate-300">نصي تفاعلي</span>
                </div>

                {/* Sample Prompt / Reply */}
                <div className="space-y-2 text-xs">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-slate-200">
                    <span className="text-[10px] text-slate-400 block mb-1">أنت:</span>
                    "عندي إعلان تسويقي لتطبيق جوال سعودي، أحتاج صوتاً حيوياً ومقنعاً مع ترشيح محرك النطق المناسب."
                  </div>

                  <div className="p-3 rounded-xl bg-orange-500/10 border border-[#FF5500]/30 text-white space-y-1.5">
                    <span className="text-[10px] text-[#FF7733] font-bold block">مستشار قيمة:</span>
                    <p className="text-[11px] text-slate-300">
                      رشحت لك <strong>سارة الذكية</strong> (محرك Qeema Neural HD) بنبرة إعلانية حماسية ولهجة سعودية معاصرة، أو المعلق البشري المعتمد <strong>أحمد العتيبي</strong>.
                    </p>
                    <div className="pt-1 flex items-center gap-2">
                      <button
                        onClick={() => onNavigate('chatbot')}
                        className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-[#FF5500] text-white hover:bg-[#E04800] transition cursor-pointer"
                      >
                        معاينة التوليد بالاستوديو ⚡
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. SECTION: ENTERPRISE & B2B INFRASTRUCTURE                               */}
      {/* ========================================================================= */}
      <EnterpriseCapabilitiesSection
        onContactSales={onOpenDemo}
        onExploreSolutions={() => onNavigate('industries')}
      />

      {/* ========================================================================= */}
      {/* 6. FINAL BOTTOM CONVERSION CTA BANNER                                     */}
      {/* ========================================================================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6" dir="rtl">
        <div className="rounded-3xl bg-gradient-to-br from-slate-50 via-white to-orange-50/50 text-slate-900 p-8 sm:p-14 border border-slate-200/90 shadow-xl shadow-slate-100 flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
          
          <div className="absolute right-0 top-0 w-80 h-80 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -left-10 -bottom-10 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="space-y-3 text-right max-w-2xl relative z-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-50 text-[#ea580c] text-xs font-bold border border-orange-200/70 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5" />
              <span>جاهز لصوتٍ يعبّر عن علامتك؟</span>
            </div>
            <h3 className="text-2xl sm:text-4xl font-black tracking-tight text-slate-900">
              ابدأ الآن بصوتٍ بشري احترافي لعلامتك
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              اختر من أصوات معلّقين عرب محترفين وموثّقين، واحصل على أداء صوتي حقيقي مصمم لمشروعك — مع أدوات AI تساعدك على التجربة والتوسع.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3.5 shrink-0 relative z-10">
            <button
              onClick={() => onNavigate('voice-library', { tab: 'human' })}
              className="px-7 py-3.5 rounded-xl bg-[#FF5500] hover:bg-[#E04800] text-white font-bold text-sm transition-all shadow-lg shadow-[#FF5500]/25 hover:shadow-[#FF5500]/35 cursor-pointer flex items-center gap-2"
            >
              <span>استكشف الأصوات البشرية</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenDemo}
              className="px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm transition-all border border-slate-300 shadow-xs hover:border-slate-400 cursor-pointer"
            >
              تحدث مع فريقنا
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
