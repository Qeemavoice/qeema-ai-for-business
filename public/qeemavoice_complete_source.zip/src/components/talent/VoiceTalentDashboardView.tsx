import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Play, 
  Pause, 
  Sliders, 
  Lock, 
  Check, 
  AlertTriangle, 
  Bell, 
  ChevronDown, 
  LogOut, 
  FileText, 
  User, 
  ArrowLeft, 
  ArrowRight,
  ShieldCheck, 
  Download, 
  ExternalLink,
  Info,
  Calendar,
  DollarSign,
  AlertCircle,
  HelpCircle,
  X,
  CreditCard,
  Building,
  Smartphone,
  ChevronLeft,
  Music,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Upload,
  CheckCircle2,
  Clock,
  Wallet,
  Mic,
  Volume2,
  Edit2,
  Send,
  LayoutDashboard,
  CheckSquare,
  FileCheck,
  Printer,
  QrCode,
  Shield,
  Camera,
  Square,
  RotateCcw,
  BadgeCheck
} from 'lucide-react';
import { 
  ActiveView, 
  Narrator, 
  AIVoice, 
  VoiceContract, 
  UsageEvent, 
  UseCase,
  AIVoiceStatus,
  VoiceSample,
  VoiceSampleStatus,
  VoiceOverBooking,
  VoiceOverBookingStatus
} from '../../types';
import { narratorService } from '../../services/narratorService';
import { audioSynth } from '../../utils/audioSynthesizer';

interface VoiceTalentDashboardViewProps {
  onNavigate: (view: ActiveView, tab?: any) => void;
  initialSubPage?: 'main' | 'profile' | 'earnings' | 'settings';
}

const USE_CASE_LABELS: Record<UseCase, string> = {
  ads: 'إعلانات تجارية',
  corporate: 'هوية مؤسسية',
  elearning: 'تعليم إلكتروني',
  ivr: 'رد آلي IVR',
  documentary: 'وثائقي ورواية',
  podcast: 'بودكاست وإنتاج صوتي',
  social: 'سوشيال ميديا',
  audiobook: 'كتب ومقالات صوتية',
  political: 'محتوى سياسي',
  religious: 'محتوى ديني',
  adult: 'محتوى للبالغين',
  gambling: 'قمار ومراهنات',
  impersonation: 'انتحال شخصية'
};

const NOTICE_PERIOD_OPTIONS = [
  { days: 30, share: 20, label: '30 يومًا', desc: 'حصة أرباح 20%' },
  { days: 180, share: 30, label: '6 أشهر', desc: 'حصة أرباح 30%' },
  { days: 365, share: 40, label: 'سنة واحدة', desc: 'حصة أرباح 40% (الأكثر شيوعاً)' },
  { days: 730, share: 50, label: 'سنتان', desc: 'حصة أرباح 50% (الأعلى عائداً)' }
];

const SAMPLE_CATEGORIES = [
  'إعلان',
  'فيديو شركة',
  'تعليمي',
  'IVR',
  'وثائقي',
  'بودكاست',
  'سوشيال',
  'كتاب صوتي'
];

const COUNTRY_CODES = [
  { code: '+966', name: 'المملكة العربية السعودية', flag: '🇸🇦' },
  { code: '+971', name: 'الإمارات العربية المتحدة', flag: '🇦🇪' },
  { code: '+965', name: 'الكويت', flag: '🇰🇼' },
  { code: '+974', name: 'قطر', flag: '🇶🇦' },
  { code: '+968', name: 'سلطنة عمان', flag: '🇴🇲' },
  { code: '+973', name: 'البحرين', flag: '🇧🇭' },
  { code: '+20', name: 'جمهورية مصر العربية', flag: '🇪🇬' },
  { code: '+962', name: 'الأردن', flag: '🇯🇴' }
];

export const VoiceTalentDashboardView: React.FC<VoiceTalentDashboardViewProps> = ({
  onNavigate,
  initialSubPage
}) => {
  // Pre-seeded narrators for instant switching between preview states
  const [narratorList, setNarratorList] = useState<Narrator[]>([]);
  const [selectedNarratorId, setSelectedNarratorId] = useState<string>('narrator_tareq_01');
  
  // Core loaded state
  const [narrator, setNarrator] = useState<Narrator | null>(null);
  const [aiVoice, setAiVoice] = useState<AIVoice | null>(null);
  const [contract, setContract] = useState<VoiceContract | null>(null);
  const [usageEvents, setUsageEvents] = useState<UsageEvent[]>([]);
  const [voiceSamples, setVoiceSamples] = useState<VoiceSample[]>([]);
  const [voiceOverBookings, setVoiceOverBookings] = useState<VoiceOverBooking[]>([]);

  // Earnings Summary
  const [earningsSummary, setEarningsSummary] = useState({
    voThisMonth: 830,
    aiThisMonth: 128.09,
    totalMonthly: 958.09,
    availableBalance: 160.60
  });

  // Current Sub-Page: 'main' | 'profile' | 'earnings' | 'settings'
  const [currentSubPage, setCurrentSubPage] = useState<'main' | 'profile' | 'earnings' | 'settings'>(() => {
    if (initialSubPage) return initialSubPage;
    try {
      const p = window.location.pathname;
      if (p.includes('/narrator/profile')) return 'profile';
      if (p.includes('/narrator/earnings')) return 'earnings';
      if (p.includes('/narrator/settings')) return 'settings';
    } catch {}
    return 'main';
  });

  // Sync subpage with browser path and popstate
  const navigateToSubPage = (subPage: 'main' | 'profile' | 'earnings' | 'settings') => {
    setCurrentSubPage(subPage);
    try {
      const routeMap: Record<string, string> = {
        main: '/narrator/dashboard',
        profile: '/narrator/profile',
        earnings: '/narrator/earnings',
        settings: '/narrator/settings'
      };
      window.history.pushState({ subPage }, '', routeMap[subPage] || '/narrator');
    } catch {}
  };

  useEffect(() => {
    const handlePopState = () => {
      const p = window.location.pathname;
      if (p.includes('/narrator/profile')) setCurrentSubPage('profile');
      else if (p.includes('/narrator/earnings')) setCurrentSubPage('earnings');
      else if (p.includes('/narrator/settings')) setCurrentSubPage('settings');
      else setCurrentSubPage('main');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Audio player state
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [isPlayingConsent, setIsPlayingConsent] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Modals state
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isPayoutSheetOpen, setIsPayoutSheetOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isEmergencyHaltOpen, setIsEmergencyHaltOpen] = useState(false);
  const [isGuidelinesOpen, setIsGuidelinesOpen] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Payout form state
  const [payoutAmount, setPayoutAmount] = useState<string>('160.60');
  const [payoutMethod, setPayoutMethod] = useState<'bank' | 'wallet'>('bank');
  const [payoutAccount, setPayoutAccount] = useState<string>('SA4420000001234567891234');
  const [payoutSuccessMsg, setPayoutSuccessMsg] = useState<string | null>(null);

  // Withdrawal confirm form state
  const [confirmInputText, setConfirmInputText] = useState('');
  const [isWithdrawSubmitting, setIsWithdrawSubmitting] = useState(false);

  // Emergency halt form state
  const [emergencyReason, setEmergencyReason] = useState('ظروف قاهرة تمنع استخدام الصوت');
  const [emergencyNotes, setEmergencyNotes] = useState('');
  const [emergencySuccess, setEmergencySuccess] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // ========================================================
  // PROFILE STATE & FORMS
  // ========================================================
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactCountryCode, setContactCountryCode] = useState('+966');
  const [contactPhoneLocal, setContactPhoneLocal] = useState('');
  const [contactErrors, setContactErrors] = useState<{ email?: string; phone?: string; name?: string }>({});
  
  // Verification code modal state
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [pendingVerificationData, setPendingVerificationData] = useState<{ email?: string; phone?: string; displayName?: string } | null>(null);
  const [verificationTargetDesc, setVerificationTargetDesc] = useState('');
  const [otpCodeInput, setOtpCodeInput] = useState('');
  const [generatedDemoOtp, setGeneratedDemoOtp] = useState('839201');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);

  // Add Sample Modal state (Max 3 samples)
  const [isAddSampleModalOpen, setIsAddSampleModalOpen] = useState(false);
  const [newSampleTitle, setNewSampleTitle] = useState('');
  const [newSampleCategory, setNewSampleCategory] = useState(SAMPLE_CATEGORIES[0]);
  const [newSampleDialect, setNewSampleDialect] = useState('سعودي نجدي');
  const [newSampleFileName, setNewSampleFileName] = useState<string | null>(null);
  const [isSubmittingSample, setIsSubmittingSample] = useState(false);
  const [sampleFormError, setSampleFormError] = useState<string | null>(null);

  // Simplified Contract consent checkbox state
  const [isContractConsentChecked, setIsContractConsentChecked] = useState(true);

  // ========================================================
  // HUMAN TALENT BADGE VERIFICATION STATE («معلق بشري»)
  // ========================================================
  const [humanBadgeStatus, setHumanBadgeStatus] = useState<'verified' | 'pending' | 'unverified'>('verified');
  const [selfiePhotoUrl, setSelfiePhotoUrl] = useState<string | null>('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300');
  const [selfieFileName, setSelfieFileName] = useState<string | null>('tareq_live_selfie.jpg');
  const [isRecordingHumanVoice, setIsRecordingHumanVoice] = useState(false);
  const [humanVoiceRecorded, setHumanVoiceRecorded] = useState(true);
  const [isPlayingHumanVoice, setIsPlayingHumanVoice] = useState(false);
  const [humanVoiceDuration, setHumanVoiceDuration] = useState(8);
  const [humanVoiceTimer, setHumanVoiceTimer] = useState(0);
  const [isSubmittingHumanVerification, setIsSubmittingHumanVerification] = useState(false);
  const selfieFileRef = useRef<HTMLInputElement | null>(null);

  // ========================================================
  // EARNINGS PAGE STATE
  // ========================================================
  const [earningsTab, setEarningsTab] = useState<'vo' | 'ai'>('vo');
  const [selectedMonthFilter, setSelectedMonthFilter] = useState<'all' | '2026-10' | '2026-09' | '2026-08'>('all');

  // Load initial narrators
  useEffect(() => {
    const loadNarrators = async () => {
      const all = await narratorService.getAllNarrators();
      setNarratorList(all);
    };
    loadNarrators();
  }, []);

  // Fetch data whenever selected narrator changes
  useEffect(() => {
    loadNarratorData(selectedNarratorId);
  }, [selectedNarratorId]);

  const loadNarratorData = async (narratorId: string) => {
    const n = await narratorService.getNarratorById(narratorId);
    setNarrator(n);

    if (n) {
      setContactName(n.displayName);
      setContactEmail(n.email || '');
      
      const phoneStr = n.phone || '+966555124567';
      const matchedCode = COUNTRY_CODES.find(c => phoneStr.startsWith(c.code));
      if (matchedCode) {
        setContactCountryCode(matchedCode.code);
        setContactPhoneLocal(phoneStr.replace(matchedCode.code, ''));
      } else {
        setContactCountryCode('+966');
        setContactPhoneLocal(phoneStr.replace('+966', ''));
      }
    }

    const voice = await narratorService.getAIVoice(narratorId);
    setAiVoice(voice);

    if (voice?.contractId) {
      const c = await narratorService.getVoiceContract(voice.contractId);
      setContract(c);
    } else {
      setContract(null);
    }

    if (voice) {
      const events = await narratorService.getUsageEvents(voice.id);
      setUsageEvents(events);
    } else {
      setUsageEvents([]);
    }

    // Voice Samples
    const samples = await narratorService.getVoiceSamples(narratorId);
    setVoiceSamples(samples);

    // Voice Over Bookings
    const bookings = await narratorService.getVoiceOverBookings(narratorId);
    setVoiceOverBookings(bookings);

    // Monthly Earnings & Balance
    const earnings = await narratorService.getMonthlyEarnings(narratorId);
    setEarningsSummary(earnings);
    setPayoutAmount(earnings.availableBalance.toFixed(2));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Audio Playback Handler
  const handleTogglePlayAudio = (id: string, url: string) => {
    if (playingAudioId === id) {
      if (audioRef.current) audioRef.current.pause();
      setPlayingAudioId(null);
    } else {
      if (audioRef.current) audioRef.current.pause();
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.play().catch(e => console.log(e));
      setPlayingAudioId(id);
      setIsPlayingConsent(false);

      audio.onended = () => {
        setPlayingAudioId(null);
      };
    }
  };

  const handleToggleConsentAudio = () => {
    const consentUrl = aiVoice?.consentRecordingUrl || 'https://cdn.freesound.org/previews/320/320655_5260872-lq.mp3';
    handleTogglePlayAudio('consent_sentence', consentUrl);
    setIsPlayingConsent(playingAudioId !== 'consent_sentence');
  };

  // Status Action Handlers
  const handleTogglePause = async () => {
    if (!selectedNarratorId) return;
    try {
      const updated = await narratorService.togglePauseAIVoice(selectedNarratorId);
      setAiVoice(updated);
      showToast(updated.status === 'paused' ? 'تم إيقاف صوتك الذكي مؤقتاً' : 'تم استئناف تشغيل صوتك الذكي');
    } catch (e) {
      console.error(e);
    }
  };

  const handleConfirmWithdrawNotice = async () => {
    if (confirmInputText.trim() !== 'تأكيد' || !selectedNarratorId) return;
    setIsWithdrawSubmitting(true);
    try {
      const updated = await narratorService.startNoticePeriodWithdrawal(selectedNarratorId);
      setAiVoice(updated);
      setIsWithdrawModalOpen(false);
      setConfirmInputText('');
      navigateToSubPage('main');
      showToast('بدأت فترة الإشعار المحددة في العقد بنجاح');
    } catch (err) {
      console.error(err);
    } finally {
      setIsWithdrawSubmitting(false);
    }
  };

  const handleToggleUseCase = async (useCaseKey: UseCase) => {
    if (!contract || !selectedNarratorId) return;
    const isAllowed = contract.allowedUseCases.includes(useCaseKey);
    let nextAllowed: UseCase[];
    if (isAllowed) {
      if (contract.allowedUseCases.length <= 1) {
        showToast('يجب إبقاء مجال استخدام مصرح به واحد على الأقل');
        return;
      }
      nextAllowed = contract.allowedUseCases.filter(u => u !== useCaseKey);
    } else {
      nextAllowed = [...contract.allowedUseCases, useCaseKey];
    }

    try {
      const updatedContract = await narratorService.updateAllowedUseCases(selectedNarratorId, nextAllowed);
      setContract(updatedContract);
      showToast(`تم تحديث مجالات الاستخدام وحفظ نسخة العقد (${updatedContract.version})`);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSelectNoticePeriod = async (days: 30 | 180 | 365 | 730) => {
    if (!contract || !selectedNarratorId) return;
    if (days < contract.noticePeriodDays) {
      showToast('لا يمكن تقليل فترة الإشعار المتفق عليها بالعقد، فقط تمديدها لخيار أطول');
      return;
    }
    if (days === contract.noticePeriodDays) return;

    try {
      const updatedContract = await narratorService.updateNoticePeriod(selectedNarratorId, days);
      setContract(updatedContract);
      showToast(`تم تمديد فترة الإشعار وزيادة حصتك من الأرباح إلى ${updatedContract.revenueSharePercent}%`);
    } catch (err) {
      console.error(err);
    }
  };

  const handleConfirmPayout = async () => {
    if (!selectedNarratorId) return;
    const amountNum = parseFloat(payoutAmount);
    if (isNaN(amountNum) || amountNum <= 0) return;

    try {
      await narratorService.requestPayout(selectedNarratorId, amountNum, payoutMethod);
      setPayoutSuccessMsg(`تم إرسال طلب سحب مبلغ $${amountNum.toFixed(2)} بنجاح`);
      setTimeout(() => {
        setIsPayoutSheetOpen(false);
        setPayoutSuccessMsg(null);
        loadNarratorData(selectedNarratorId);
      }, 2000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmitEmergencyHalt = async () => {
    if (!selectedNarratorId) return;
    try {
      await narratorService.submitEmergencyStopRequest(selectedNarratorId, emergencyReason, emergencyNotes);
      setEmergencySuccess(true);
      setTimeout(() => {
        setIsEmergencyHaltOpen(false);
        setEmergencySuccess(false);
        setEmergencyNotes('');
        showToast('تم رفع طلب الإيقاف الاستثنائي إلى فريق العمليات للمراجعة العاجلة');
      }, 2000);
    } catch (err) {
      console.error(err);
    }
  };

  // ========================================================
  // CONTACT INFO VERIFICATION & SAVE
  // ========================================================
  const validateContactForm = () => {
    const errors: { email?: string; phone?: string; name?: string } = {};
    
    if (!contactName.trim()) {
      errors.name = 'يرجى إدخال الاسم الكامل';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!contactEmail.trim() || !emailRegex.test(contactEmail.trim())) {
      errors.email = 'يرجى إدخال بريد إلكتروني صحيح (مثال: name@domain.com)';
    }

    const cleanPhone = contactPhoneLocal.replace(/[\s-]/g, '');
    if (!cleanPhone || cleanPhone.length < 8 || cleanPhone.length > 12 || !/^\d+$/.test(cleanPhone)) {
      errors.phone = 'يرجى إدخال رقم هاتف صحيح مكوّن من 8 إلى 12 رقمًا';
    }

    setContactErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSaveContactChanges = async () => {
    if (!validateContactForm() || !narrator) return;

    const fullPhone = `${contactCountryCode}${contactPhoneLocal.replace(/[\s-]/g, '')}`;
    const isEmailChanged = contactEmail.trim().toLowerCase() !== (narrator.email || '').toLowerCase();
    const isPhoneChanged = fullPhone !== narrator.phone;

    if (isEmailChanged || isPhoneChanged) {
      const targetStr = isPhoneChanged ? fullPhone : contactEmail.trim();
      const codeRes = await narratorService.sendVerificationCode(targetStr, isPhoneChanged ? 'phone' : 'email');
      setGeneratedDemoOtp(codeRes.code);
      setOtpCodeInput('');
      setOtpError(null);
      setPendingVerificationData({
        displayName: contactName.trim(),
        email: contactEmail.trim(),
        phone: fullPhone
      });
      setVerificationTargetDesc(isPhoneChanged ? `رقم واتساب الجديد (${fullPhone})` : `البريد الإلكتروني الجديد (${contactEmail})`);
      setIsVerificationModalOpen(true);
    } else {
      await narratorService.updateNarratorContact(narrator.id, {
        displayName: contactName.trim()
      });
      await loadNarratorData(narrator.id);
      showToast('تم حفظ التعديلات بنجاح');
    }
  };

  const handleConfirmVerificationOtp = async () => {
    if (!pendingVerificationData || !narrator) return;
    if (!otpCodeInput.trim()) {
      setOtpError('يرجى إدخال رمز التحقق المكوّن من 6 أرقام');
      return;
    }

    setIsVerifyingOtp(true);
    try {
      const targetStr = pendingVerificationData.phone || pendingVerificationData.email || '';
      const isValid = await narratorService.verifyCode(targetStr, otpCodeInput.trim());
      if (!isValid) {
        setOtpError('رمز التحقق غير صحيح، يرجى المحاولة مجددًا');
        setIsVerifyingOtp(false);
        return;
      }

      await narratorService.updateNarratorContact(narrator.id, pendingVerificationData);
      await loadNarratorData(narrator.id);
      setIsVerificationModalOpen(false);
      setPendingVerificationData(null);
      setOtpCodeInput('');
      showToast('تم التحقق وتحديث بيانات التواصل بنجاح ✅');
    } catch (e: any) {
      setOtpError(e.message || 'فشل التحقق من الرمز');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // ========================================================
  // VOICE SAMPLES ACTIONS (MAX 3 SAMPLES - MP3 ONLY)
  // ========================================================
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file extension / MIME type strictly for MP3
    const isMp3 = file.name.toLowerCase().endsWith('.mp3') || file.type === 'audio/mpeg' || file.type === 'audio/mp3';
    if (!isMp3) {
      setSampleFormError('جودة الملف: صيغة MP3. فقط (يرجى اختيار ملف بامتداد .mp3)');
      setNewSampleFileName(null);
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      setSampleFormError('حجم الملف يتجاوز الحد الأقصى المسموح (20 ميجابايت)');
      setNewSampleFileName(null);
      return;
    }

    setSampleFormError(null);
    setNewSampleFileName(file.name);
  };

  const handleCreateSample = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!narrator) return;

    if (!newSampleTitle.trim()) {
      setSampleFormError('يرجى كتابة عنوان العينة');
      return;
    }

    if (voiceSamples.length >= 3) {
      setSampleFormError('متاح إضافة 3 عينات فقط بشرط التوافق مع شروط العينات في المنصة');
      return;
    }

    // Strict MP3 check
    const fileName = newSampleFileName || 'audio_sample_master.mp3';
    if (!fileName.toLowerCase().endsWith('.mp3')) {
      setSampleFormError('جودة الملف: صيغة MP3. فقط');
      return;
    }

    setIsSubmittingSample(true);
    setSampleFormError(null);

    try {
      await narratorService.addVoiceSample({
        narratorId: narrator.id,
        title: newSampleTitle.trim(),
        category: newSampleCategory,
        dialect: newSampleDialect,
        pricePerMinute: 80,
        durationSec: Math.floor(Math.random() * 50) + 35
      });

      await loadNarratorData(narrator.id);
      setIsAddSampleModalOpen(false);
      setNewSampleTitle('');
      setNewSampleFileName(null);
      showToast('تم رفع العينة الصوتية بنجاح واعتمادها للمراجعة');
    } catch (err: any) {
      setSampleFormError(err.message || 'حدث خطأ أثناء إضافة العينة');
    } finally {
      setIsSubmittingSample(false);
    }
  };

  const handleDeleteSample = async (sampleId: string) => {
    if (!window.confirm('هل أنت متأكد من رغبتك في حذف هذه العينة؟')) return;
    try {
      await narratorService.deleteVoiceSample(sampleId);
      if (narrator) await loadNarratorData(narrator.id);
      showToast('تم حذف العينة بنجاح');
    } catch (err: any) {
      showToast(err.message || 'فشل حذف العينة');
    }
  };

  // ========================================================
  // HUMAN TALENT BADGE VERIFICATION HANDLERS («معلق بشري»)
  // ========================================================
  const handleSelfieSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('يرجى اختيار ملف صورة صالح (JPG أو PNG)');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      showToast('حجم صورة السيلفي يجب ألا يتجاوز 10 ميجابايت');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setSelfiePhotoUrl(reader.result as string);
      setSelfieFileName(file.name);
      showToast('تم التقاط / رفع صورة السيلفي للتحقق بنجاح 📸');
    };
    reader.readAsDataURL(file);
  };

  const handleStartRecordHumanVoice = () => {
    setIsRecordingHumanVoice(true);
    setHumanVoiceTimer(0);
    const interval = setInterval(() => {
      setHumanVoiceTimer(prev => {
        if (prev >= 10) {
          clearInterval(interval);
          handleStopRecordHumanVoice();
          return 10;
        }
        return prev + 1;
      });
    }, 1000);
  };

  const handleStopRecordHumanVoice = () => {
    setIsRecordingHumanVoice(false);
    setHumanVoiceRecorded(true);
    setHumanVoiceDuration(Math.max(5, humanVoiceTimer || 8));
    showToast('تم تسجيل عينة التحقق الصوتي الحي بنجاح 🎙️');
  };

  const handleTogglePlayHumanVoice = () => {
    if (isPlayingHumanVoice) {
      audioSynth.stopAll();
      setIsPlayingHumanVoice(false);
    } else {
      setIsPlayingHumanVoice(true);
      audioSynth.playAcousticPreview(() => {
        setIsPlayingHumanVoice(false);
      }, humanVoiceDuration || 6);
    }
  };

  const handleSubmitHumanVerification = async () => {
    if (!selfiePhotoUrl) {
      showToast('يرجى التقاط أو رفع صورة سيلفي مباشرة أولاً');
      return;
    }
    if (!humanVoiceRecorded) {
      showToast('يرجى تسجيل النص الصوتي المطلوب للتحقق');
      return;
    }

    setIsSubmittingHumanVerification(true);
    setTimeout(() => {
      setIsSubmittingHumanVerification(false);
      setHumanBadgeStatus('verified');
      showToast('تهانينا! تم التحقق بنجاح وحصلت على شارة «معلق بشري معتمد» 🎙️✓');
    }, 1200);
  };

  // Voice Status Card Configuration
  const isVoiceNeverPublished = !aiVoice || aiVoice.status === 'not_started';

  const renderStatusCard = () => {
    const status: AIVoiceStatus = aiVoice?.status || 'not_started';

    switch (status) {
      case 'not_started':
        return {
          dotColor: 'bg-orange-500',
          sentence: 'حوّل صوتك إلى دخل إضافي مستمر مع الحفاظ على كامل حقوقك.',
          actionButton: (
            <button
              onClick={() => onNavigate('ai-voice-setup')}
              className="px-5 py-2.5 rounded-2xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm shadow-md shadow-orange-500/25 transition-all cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>ابدأ الآن</span>
            </button>
          )
        };

      case 'kyc_pending':
      case 'contract_signed':
      case 'recording':
        return {
          dotColor: 'bg-amber-500 animate-pulse',
          sentence: 'أكملت 2 من 5 خطوات في إعداد صوتك الذكي.',
          actionButton: (
            <button
              onClick={() => onNavigate('ai-voice-setup')}
              className="px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm shadow-md transition-all cursor-pointer flex items-center gap-2"
            >
              <span>أكمل الإعداد</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          )
        };

      case 'processing':
        return {
          dotColor: 'bg-blue-500 animate-ping',
          sentence: 'نجهّز صوتك… سنرسل لك إشعارًا فور جاهزيته.',
          actionButton: null
        };

      case 'preview_ready':
        return {
          dotColor: 'bg-emerald-500 animate-bounce',
          sentence: 'صوتك جاهز للمعاينة والموافقة النهائية.',
          actionButton: (
            <button
              onClick={() => onNavigate('ai-voice-setup')}
              className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md shadow-emerald-600/25 transition-all cursor-pointer flex items-center gap-2"
            >
              <Play className="w-4 h-4" />
              <span>اسمع ووافق</span>
            </button>
          )
        };

      case 'published':
        return {
          dotColor: 'bg-emerald-500',
          sentence: 'منشور ويعمل — متاح للعملاء المصرح لهم فقط.',
          actionButton: (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleTogglePlayAudio('ai_preview', aiVoice?.previewUrls?.[0] || 'https://cdn.freesound.org/previews/320/320655_5260872-lq.mp3')}
                className="px-3.5 py-2 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-orange-500/20"
              >
                {playingAudioId === 'ai_preview' ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>اسمع صوتك الذكي</span>
              </button>

              <button
                onClick={handleTogglePause}
                className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
              >
                <Pause className="w-3.5 h-3.5 text-slate-500" />
                <span>إيقاف مؤقت</span>
              </button>
            </div>
          )
        };

      case 'paused':
        return {
          dotColor: 'bg-amber-500',
          sentence: 'متوقف مؤقتًا — لا يراه عملاء جدد.',
          actionButton: (
            <button
              onClick={handleTogglePause}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Play className="w-3.5 h-3.5" />
              <span>استئناف</span>
            </button>
          )
        };

      case 'notice_period':
        const disableDate = aiVoice?.disableAt 
          ? new Date(aiVoice.disableAt).toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' })
          : '31 ديسمبر 2026';
        return {
          dotColor: 'bg-rose-500',
          sentence: `سيتوقف صوتك نهائيًا في ${disableDate}.`,
          actionButton: null
        };

      default:
        return {
          dotColor: 'bg-slate-400',
          sentence: 'صوتك غير نشط.',
          actionButton: null
        };
    }
  };

  const statusCardConfig = renderStatusCard();

  return (
    <div className="min-h-screen bg-[#FBFBFC] text-slate-900 font-sans pb-20 text-right selection:bg-orange-500 selection:text-white" dir="rtl">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl bg-slate-900 text-white text-xs font-bold shadow-2xl flex items-center gap-2 animate-fade-in border border-slate-800">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Mobile/Header Strip */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo & Brand */}
          <div 
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-white font-black text-sm shadow-md shadow-orange-500/25 group-hover:scale-105 transition-transform">
              ق
            </div>
            <div>
              <span className="font-black text-sm text-slate-900 tracking-tight">قيمة فويس</span>
              <span className="text-[10px] text-orange-600 block font-semibold leading-none">منصة المعلقين الصوتيين</span>
            </div>
          </div>

          {/* Top Actions: Notification bell + Quick preview switcher */}
          <div className="flex items-center gap-3">
            {/* Demo Narrator Switcher */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 px-2.5 py-1 rounded-xl text-xs">
              <span className="text-[10px] text-slate-400 font-bold hidden sm:inline">معاينة الحساب:</span>
              <select
                value={selectedNarratorId}
                onChange={(e) => setSelectedNarratorId(e.target.value)}
                className="bg-transparent text-slate-800 font-bold text-xs focus:outline-hidden cursor-pointer"
              >
                <option value="narrator_tareq_01">طارق الشمري (صوت ذكي منشور)</option>
                <option value="narrator_sara_02">سارة الدوسري (صوت ذكي لم يبدأ)</option>
                <option value="narrator_karim_03">كريم المنصور (صوت ذكي متوقف مؤقتاً)</option>
                <option value="narrator_nour_04">نور الهدى إبراهيم (حساب تجريبي)</option>
              </select>
            </div>

            {/* Notification Bell */}
            <button
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              className="w-9 h-9 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200/60 flex items-center justify-center transition-colors relative cursor-pointer"
              title="الإشعارات"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-orange-500" />
            </button>

            {isNotificationsOpen && (
              <div className="absolute left-4 top-16 w-72 bg-white rounded-2xl shadow-xl border border-slate-100 p-4 z-50 text-xs space-y-3 animate-fade-in">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="font-bold text-slate-800">التنبيهات</span>
                  <span className="text-[10px] text-slate-400">اليوم</span>
                </div>
                <div className="space-y-2 text-slate-600">
                  <div className="p-2.5 rounded-xl bg-orange-50/60 text-orange-900 border border-orange-100">
                    <p className="font-bold">استخدام جديد لصوتك الذكي</p>
                    <p className="text-[10px] text-orange-700 mt-0.5">تم تسجيل إعلان بواسطة صوتك وإيداع $18.90 في رصيدك</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 text-slate-700">
                    <p className="font-bold">حجز استوديو بشري</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">مشروع إعلان اليوم الوطني مكتمل ومودع في حسابك</p>
                  </div>
                </div>
              </div>
            )}

            {/* Avatar Dropdown Menu (الملف الشخصي · العقد والموافقات · تسجيل الخروج) */}
            <div className="relative">
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-2 p-1 pl-2 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200/60 transition-colors cursor-pointer"
                title="قائمة الحساب"
              >
                <img
                  src={narrator?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80'}
                  alt={narrator?.displayName}
                  className="w-7 h-7 rounded-lg object-cover border border-slate-200"
                />
                <span className="text-xs font-bold text-slate-800 hidden md:inline">
                  {narrator?.displayName ? narrator.displayName.split(' ')[0] : 'المعلق'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {isUserMenuOpen && (
                <div className="absolute left-0 top-11 w-52 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 text-xs space-y-1 animate-fade-in">
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="font-bold text-slate-900 truncate">{narrator?.displayName}</p>
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5" dir="ltr">{narrator?.phone}</p>
                  </div>

                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      navigateToSubPage('profile');
                    }}
                    className="w-full text-right px-3 py-2 rounded-xl text-slate-700 hover:bg-slate-50 hover:text-slate-950 font-bold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>الملف الشخصي</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      navigateToSubPage('settings');
                    }}
                    className="w-full text-right px-3 py-2 rounded-xl text-slate-700 hover:bg-slate-50 hover:text-slate-950 font-bold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <Sliders className="w-3.5 h-3.5 text-slate-400" />
                    <span>إعدادات صوتي الذكي</span>
                  </button>

                  <div className="pt-1 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onNavigate('home');
                      }}
                      className="w-full text-right px-3 py-2 rounded-xl text-rose-600 hover:bg-rose-50 font-bold flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>تسجيل الخروج</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* MAIN TWO-COLUMN WORKSPACE: RIGHT SIDEBAR + LEFT PAGES CONTENT AREA */}
      {/* ========================================================================= */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col lg:flex-row items-start gap-6">

          {/* ===================================================================== */}
          {/* 1. RIGHT SIDEBAR (سايد بار عاليمين) */}
          {/* ===================================================================== */}
          <aside className="w-full lg:w-72 shrink-0 bg-white rounded-3xl p-5 border border-slate-100 shadow-sm lg:sticky lg:top-20 space-y-6">
            {/* Narrator Profile Widget in Sidebar */}
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
              <img
                src={narrator?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120'}
                alt={narrator?.displayName}
                className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shrink-0"
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-sm text-slate-900 truncate">
                    {narrator?.displayName || 'المعلق الصوتي'}
                  </h3>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                </div>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5" dir="ltr">
                  {narrator?.phone}
                </p>
                <div className="flex flex-wrap items-center gap-1.5 mt-1">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span className="text-[10px] font-bold text-emerald-600">حساب موثق</span>
                  </span>
                  
                  {humanBadgeStatus === 'verified' && (
                    <span className="px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-0.5">
                      <Mic className="w-2.5 h-2.5 text-blue-600" />
                      <span>معلق بشري</span>
                    </span>
                  )}
                  {humanBadgeStatus === 'pending' && (
                    <span className="px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-0.5">
                      <Clock className="w-2.5 h-2.5 text-amber-600" />
                      <span>مراجعة الشارة</span>
                    </span>
                  )}
                  {humanBadgeStatus === 'unverified' && (
                    <span className="px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-slate-100 text-slate-500">
                      بدون شارة بشرية
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Sidebar Navigation Items */}
            <nav className="space-y-1">
              <button
                onClick={() => navigateToSubPage('main')}
                className={`w-full text-right px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                  currentSubPage === 'main'
                    ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-950'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <LayoutDashboard className={`w-4 h-4 ${currentSubPage === 'main' ? 'text-white' : 'text-slate-400'}`} />
                  <span>لوحة المعلق</span>
                </div>
              </button>

              <button
                onClick={() => navigateToSubPage('profile')}
                className={`w-full text-right px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                  currentSubPage === 'profile'
                    ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-950'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <User className={`w-4 h-4 ${currentSubPage === 'profile' ? 'text-white' : 'text-slate-400'}`} />
                  <span>ملفي الشخصي</span>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                  currentSubPage === 'profile' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {voiceSamples.length}/3
                </span>
              </button>

              <button
                onClick={() => navigateToSubPage('earnings')}
                className={`w-full text-right px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                  currentSubPage === 'earnings'
                    ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-950'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Wallet className={`w-4 h-4 ${currentSubPage === 'earnings' ? 'text-white' : 'text-slate-400'}`} />
                  <span>سجل الأرباح</span>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                  currentSubPage === 'earnings' ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700'
                }`}>
                  ${earningsSummary.availableBalance.toFixed(0)}
                </span>
              </button>

              <button
                onClick={() => navigateToSubPage('settings')}
                className={`w-full text-right px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                  currentSubPage === 'settings'
                    ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-950'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Sliders className={`w-4 h-4 ${currentSubPage === 'settings' ? 'text-white' : 'text-slate-400'}`} />
                  <span>إعدادات صوتي الذكي</span>
                </div>
              </button>
            </nav>

            {/* Quick Balance & Payout Box in Sidebar */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white space-y-3">
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">الرصيد المتاح للسحب</span>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-2xl font-black font-mono text-emerald-400">
                    ${earningsSummary.availableBalance.toFixed(2)}
                  </span>
                  <span className="text-[10px] text-slate-400">دولار</span>
                </div>
              </div>

              <button
                onClick={() => setIsPayoutSheetOpen(true)}
                className="w-full py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold shadow-md shadow-orange-500/20 transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>سحب الأرباح الآن</span>
              </button>
            </div>

            {/* Logout button in sidebar */}
            <div className="pt-2 border-t border-slate-100">
              <button
                onClick={() => onNavigate('home')}
                className="w-full text-right px-3.5 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-rose-600 hover:bg-rose-50/50 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>العودة للرئيسية</span>
              </button>
            </div>
          </aside>

          {/* ===================================================================== */}
          {/* 2. LEFT CONTENT AREA (تظهر الصفحات عاليسار) */}
          {/* ===================================================================== */}
          <main className="flex-1 min-w-0 w-full space-y-6">

            {/* ========================================================= */}
            {/* SUBPAGE 1: MAIN DASHBOARD */}
            {/* ========================================================= */}
            {currentSubPage === 'main' && (
              <div className="space-y-6 animate-fade-in">
                {/* Greeting */}
                <div>
                  <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                    أهلًا {narrator?.displayName ? narrator.displayName.split(' ')[0] : 'طارق'} 👋
                  </h1>
                  <p className="text-xs text-slate-500 mt-1">
                    لوحة تحكمك الصوتية الموحدة • متابعة الأرباح، إدارة العينات المعتمدة، وضبط تراخيص صوتك الذكي
                  </p>
                </div>

                {/* BLOCK 1: STATUS CARD «صوتي الذكي» */}
                <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm transition-all hover:shadow-md">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                    <span className="text-xs font-bold text-slate-400 tracking-wide uppercase">صوتي الذكي المعتمد</span>
                    {aiVoice?.status === 'published' && (
                      <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100 font-mono">
                        حصة الأرباح {contract?.revenueSharePercent || 45}%
                      </span>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <span className={`w-3.5 h-3.5 rounded-full shrink-0 ${statusCardConfig.dotColor}`} />
                      <p className="text-base sm:text-lg font-bold text-slate-800 leading-snug">
                        {statusCardConfig.sentence}
                      </p>
                    </div>

                    {statusCardConfig.actionButton && (
                      <div className="shrink-0 self-start sm:self-auto">
                        {statusCardConfig.actionButton}
                      </div>
                    )}
                  </div>
                </div>

                {/* BLOCK 2: EARNINGS CARDS SPLIT BY SOURCE */}
                {isVoiceNeverPublished ? (
                  <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-400">أرباحك هذا الشهر (من التعليق الصوتي البشري)</span>
                      <Mic className="w-4 h-4 text-orange-500" />
                    </div>
                    
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-black font-mono text-slate-900">${earningsSummary.voThisMonth}</span>
                      <span className="text-xs font-bold text-slate-400">دولار</span>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <span className="text-slate-600">
                        رصيدك المتاح: <strong className="font-mono text-slate-900 font-bold">${earningsSummary.availableBalance.toFixed(2)}</strong>
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onNavigate('ai-voice-setup')}
                          className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 cursor-pointer"
                        >
                          <span>فعّل صوتك الذكي لدخل إضافي ←</span>
                        </button>

                        <button
                          onClick={() => setIsPayoutSheetOpen(true)}
                          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                        >
                          سحب الأرباح
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Card 1: Human Voice-over */}
                      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm">
                        <div className="flex items-center justify-between text-slate-400 text-xs font-bold mb-2">
                          <span>من التعليق الصوتي</span>
                          <Mic className="w-4 h-4 text-blue-500" />
                        </div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-2xl sm:text-3xl font-black font-mono text-slate-900">
                            ${earningsSummary.voThisMonth}
                          </span>
                          <span className="text-[11px] font-bold text-slate-400">دولار</span>
                        </div>
                        <span className="text-[10px] text-slate-400 mt-1 block">حجوزات الاستوديو البشري لهذا الشهر</span>
                      </div>

                      {/* Card 2: AI Voice */}
                      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm">
                        <div className="flex items-center justify-between text-slate-400 text-xs font-bold mb-2">
                          <span>من الصوت الذكي</span>
                          <Sparkles className="w-4 h-4 text-orange-500" />
                        </div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-2xl sm:text-3xl font-black font-mono text-orange-600">
                            ${earningsSummary.aiThisMonth}
                          </span>
                          <span className="text-[11px] font-bold text-slate-400">دولار</span>
                        </div>
                        <span className="text-[10px] text-slate-400 mt-1 block">ترخيص التوليد الفوري بالذكاء الاصطناعي</span>
                      </div>
                    </div>

                    {/* Balance Line */}
                    <div className="bg-white rounded-2xl px-5 py-4 border border-slate-100 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="text-slate-600">
                        الإجمالي هذا الشهر: <strong className="font-mono text-slate-900">${earningsSummary.totalMonthly}</strong>
                        <span className="mx-2 text-slate-300">•</span>
                        رصيدك المتاح: <strong className="font-mono text-emerald-600 font-bold">${earningsSummary.availableBalance.toFixed(2)}</strong>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => navigateToSubPage('earnings')}
                          className="text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
                        >
                          سجل الأرباح ←
                        </button>
                        <button
                          onClick={() => setIsPayoutSheetOpen(true)}
                          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                        >
                          سحب الأرباح
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* BLOCK 3: LAST 5 USAGES */}
                {!isVoiceNeverPublished && (
                  <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                      <h3 className="text-sm font-bold text-slate-900">آخر الاستخدامات</h3>
                      <button
                        onClick={() => navigateToSubPage('earnings')}
                        className="text-xs font-bold text-orange-600 hover:text-orange-700 cursor-pointer transition-colors"
                      >
                        عرض الكل ←
                      </button>
                    </div>

                    {usageEvents.length === 0 ? (
                      <p className="text-center py-6 text-slate-400 text-xs">لم يُسجّل أي استخدام لصوتك بعد.</p>
                    ) : (
                      <div className="divide-y divide-slate-50">
                        {usageEvents.slice(0, 5).map(ev => (
                          <div key={ev.id} className="py-3 flex items-center justify-between text-xs hover:bg-slate-50/50 px-2 rounded-xl transition-colors">
                            <div className="flex items-center gap-2.5">
                              <span className="w-2 h-2 rounded-full bg-orange-400" />
                              <span className="font-bold text-slate-800">
                                {USE_CASE_LABELS[ev.useCase] || ev.useCase}
                              </span>
                              <span className="text-[11px] text-slate-400 font-mono">
                                {new Date(ev.createdAt).toLocaleDateString('ar-SA')}
                              </span>
                            </div>

                            <span className="font-bold font-mono text-emerald-600 text-sm">
                              + ${ev.narratorEarning?.toFixed(2) || '0.00'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Quick Row Links to Profile and Settings */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <button
                    onClick={() => navigateToSubPage('profile')}
                    className="bg-white hover:bg-slate-50 rounded-2xl p-4 border border-slate-100 shadow-xs flex items-center justify-between text-right text-slate-800 font-bold text-xs transition-all cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                        <User className="w-4 h-4" />
                      </div>
                      <div>
                        <span>ملفي الشخصي والعينات</span>
                        <span className="text-[10px] text-slate-400 font-normal block">تعديل بيانات التواصل والعينات الصوتية المعتمدة</span>
                      </div>
                    </div>
                    <ArrowLeft className="w-4 h-4 text-slate-400 group-hover:-translate-x-1 transition-transform shrink-0" />
                  </button>

                  <button
                    onClick={() => navigateToSubPage('settings')}
                    className="bg-white hover:bg-slate-50 rounded-2xl p-4 border border-slate-100 shadow-xs flex items-center justify-between text-right text-slate-800 font-bold text-xs transition-all cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center shrink-0">
                        <Sliders className="w-4 h-4" />
                      </div>
                      <div>
                        <span>إعدادات صوتي الذكي</span>
                        <span className="text-[10px] text-slate-400 font-normal block">تراخيص الاستخدام، فترة الإشعار، وسحب الموافقة</span>
                      </div>
                    </div>
                    <ArrowLeft className="w-4 h-4 text-slate-400 group-hover:-translate-x-1 transition-transform shrink-0" />
                  </button>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* SUBPAGE 2: PROFILE PAGE «ملفي الشخصي» */}
            {/* ========================================================= */}
            {currentSubPage === 'profile' && (
              <div className="space-y-6 animate-fade-in">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-4">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <h2 className="text-xl font-black text-slate-900">ملفي الشخصي</h2>
                      {humanBadgeStatus === 'verified' && (
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1">
                          <Mic className="w-3.5 h-3.5 text-blue-600" />
                          <span>معلق بشري معتمد ✓</span>
                        </span>
                      )}
                      {humanBadgeStatus === 'pending' && (
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>تحقق الهوية قيد المراجعة</span>
                        </span>
                      )}
                      {humanBadgeStatus === 'unverified' && (
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                          غير موثق بشرياً
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      بيانات التواصل الرسمية، العينات الصوتية، وتوثيق شارة «معلق بشري»
                    </p>
                  </div>
                  <button
                    onClick={() => navigateToSubPage('main')}
                    className="text-xs font-bold text-slate-500 hover:text-slate-900 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>العودة للوحة المعلق</span>
                  </button>
                </div>

                {/* A) CONTACT INFO CARD «بيانات التواصل» */}
                <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-blue-600" />
                      <h3 className="font-bold text-sm text-slate-900">بيانات التواصل</h3>
                    </div>
                    <span className="text-[10px] text-slate-400">تحديث فوري مع تحقق أمني</span>
                  </div>

                  <div className="space-y-4 text-xs">
                    {/* Full Name */}
                    <div>
                      <label className="block text-slate-700 font-bold mb-1.5">الاسم الكامل *</label>
                      <input
                        type="text"
                        value={contactName}
                        onChange={(e) => {
                          setContactName(e.target.value);
                          if (contactErrors.name) setContactErrors(prev => ({ ...prev, name: undefined }));
                        }}
                        placeholder="مثال: طارق الشمري"
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-blue-500 transition-colors"
                      />
                      {contactErrors.name && (
                        <p className="text-[11px] text-rose-500 mt-1 font-medium">{contactErrors.name}</p>
                      )}
                    </div>

                    {/* Email */}
                    <div>
                      <label className="block text-slate-700 font-bold mb-1.5">البريد الإلكتروني *</label>
                      <input
                        type="email"
                        value={contactEmail}
                        onChange={(e) => {
                          setContactEmail(e.target.value);
                          if (contactErrors.email) setContactErrors(prev => ({ ...prev, email: undefined }));
                        }}
                        placeholder="name@domain.com"
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-800 focus:outline-hidden focus:border-blue-500 transition-colors"
                        dir="ltr"
                      />
                      {contactErrors.email && (
                        <p className="text-[11px] text-rose-500 mt-1 font-medium text-right">{contactErrors.email}</p>
                      )}
                    </div>

                    {/* WhatsApp Phone with Country Code Picker */}
                    <div>
                      <label className="block text-slate-700 font-bold mb-1.5">رقم واتساب للتواصل *</label>
                      <div className="flex gap-2" dir="ltr">
                        {/* Country Code Picker */}
                        <div className="relative min-w-[130px]">
                          <select
                            value={contactCountryCode}
                            onChange={(e) => setContactCountryCode(e.target.value)}
                            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-blue-500 cursor-pointer"
                          >
                            {COUNTRY_CODES.map(c => (
                              <option key={c.code} value={c.code}>
                                {c.flag} {c.code}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Local Phone Input */}
                        <input
                          type="tel"
                          value={contactPhoneLocal}
                          onChange={(e) => {
                            setContactPhoneLocal(e.target.value);
                            if (contactErrors.phone) setContactErrors(prev => ({ ...prev, phone: undefined }));
                          }}
                          placeholder="555 124 567"
                          className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-hidden focus:border-blue-500 transition-colors"
                        />
                      </div>
                      {contactErrors.phone && (
                        <p className="text-[11px] text-rose-500 mt-1 font-medium">{contactErrors.phone}</p>
                      )}
                      <p className="text-[10px] text-slate-400 mt-1">
                        * ملاحظة: تعديل البريد أو رقم الواتساب يتطلب إدخال رمز تحقق مكوّن من 6 أرقام لحماية حسابك.
                      </p>
                    </div>

                    <div className="pt-2">
                      <button
                        onClick={handleSaveContactChanges}
                        className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                      >
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span>حفظ التعديلات</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* B) VOICE SAMPLES CARD «عيناتي الصوتية» (MAX 3 SAMPLES) */}
                <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Music className="w-4 h-4 text-orange-500" />
                        <h3 className="font-bold text-sm text-slate-900">عيناتي الصوتية</h3>
                        <span className="text-xs font-mono font-bold text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full">
                          {voiceSamples.length} / 3 عينات
                        </span>
                      </div>
                      <p className="text-xs font-bold text-orange-700">
                        متاح إضافة 3 عينات بشرط التوافق مع شروط العينات في المنصة
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setIsGuidelinesOpen(!isGuidelinesOpen)}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Info className="w-3.5 h-3.5 text-blue-600" />
                        <span>شروط العينات</span>
                      </button>

                      <button
                        onClick={() => setIsAddSampleModalOpen(true)}
                        disabled={voiceSamples.length >= 3}
                        className="px-3.5 py-1.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>إضافة عينة</span>
                      </button>
                    </div>
                  </div>

                  {/* Platform Sample Conditions Guideline Box */}
                  {(isGuidelinesOpen || voiceSamples.length === 0) && (
                    <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200/80 text-xs text-blue-950 space-y-2 animate-fade-in">
                      <div className="flex items-center justify-between font-bold text-blue-900">
                        <span className="flex items-center gap-1.5">
                          <CheckSquare className="w-4 h-4 text-blue-600" />
                          <span>شروط العينات الصوتية المعتمدة في منصة قيمة فويس:</span>
                        </span>
                        <button
                          onClick={() => setIsGuidelinesOpen(false)}
                          className="text-blue-500 hover:text-blue-800 text-[11px]"
                        >
                          إغلاق
                        </button>
                      </div>
                      <ul className="space-y-1 text-slate-700 text-[11px] list-disc list-inside">
                        <li><strong>نقاء التسجيل:</strong> خلو التسجيل بنسبة 100% من صدى الصوت والضوضاء والتشويش الخلفي.</li>
                        <li><strong>صوت خام نقي:</strong> عدم إضافة أي مؤثرات موسيقية أو أصداء غير طبيعية في الخلفية.</li>
                        <li><strong>جودة الملف:</strong> صيغة إم بي ثري الصوتية فقط (الحد الأقصى 20 ميجابايت) وبجودة استوديو احترافية.</li>
                      </ul>
                    </div>
                  )}

                  {/* Samples List */}
                  <div className="space-y-3">
                    {voiceSamples.length === 0 ? (
                      <p className="text-center py-6 text-slate-400 text-xs">لا توجد عينات صوتية مرفوعة حتى الآن. يمكنك إضافة حتى 3 عينات متوافقة مع الشروط.</p>
                    ) : (
                      voiceSamples.map(sample => {
                        const isPlaying = playingAudioId === sample.id;

                        return (
                          <div
                            key={sample.id}
                            className={`p-4 rounded-2xl border transition-all ${
                              sample.status === 'rejected'
                                ? 'bg-rose-50/30 border-rose-100'
                                : 'bg-white border-slate-100 hover:border-slate-200'
                            }`}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              {/* Left: Play button + Title + Badges */}
                              <div className="flex items-center gap-3">
                                <button
                                  onClick={() => handleTogglePlayAudio(sample.id, sample.audioUrl)}
                                  className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                                    isPlaying
                                      ? 'bg-orange-500 text-white shadow-md shadow-orange-500/25 animate-pulse'
                                      : 'bg-slate-100 text-slate-700 hover:bg-orange-500 hover:text-white'
                                  }`}
                                  title={isPlaying ? 'إيقاف' : 'تشغيل العينة'}
                                >
                                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                                </button>

                                <div className="space-y-1">
                                  <span className="font-bold text-slate-900 text-sm block">{sample.title}</span>
                                  <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                                    <span className="px-2 py-0.5 rounded-md bg-orange-50 text-orange-700 font-bold">
                                      {sample.category}
                                    </span>
                                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                                      {sample.dialect}
                                    </span>
                                    <span className="font-mono text-slate-400 text-[10px]">
                                      {Math.floor(sample.durationSec / 60)}:{String(sample.durationSec % 60).padStart(2, '0')} دقيقة
                                    </span>
                                  </div>
                                </div>
                              </div>

                              {/* Right: Minute Price (Always Displayed & Read-only) + Status Chip («معتمد») + Actions */}
                              <div className="flex flex-wrap items-center gap-2.5 sm:justify-end">
                                <div 
                                  className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 text-xs flex items-center gap-1.5 font-bold"
                                  title="سعر الدقيقة"
                                >
                                  <span className="text-slate-500 font-medium text-[11px]">سعر الدقيقة:</span>
                                  <span className="font-mono text-sm text-slate-900 font-black">
                                    ${sample.pricePerMinute || 80} / دقيقة
                                  </span>
                                </div>

                                {/* Status Chip: «معتمد» instead of «منشورة» */}
                                {sample.status === 'published' && (
                                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>معتمد</span>
                                  </span>
                                )}

                                {sample.status === 'pending_review' && (
                                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1">
                                    <Clock className="w-3 h-3" />
                                    <span>قيد المراجعة</span>
                                  </span>
                                )}

                                {sample.status === 'rejected' && (
                                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1">
                                    <AlertCircle className="w-3 h-3" />
                                    <span>مرفوضة</span>
                                  </span>
                                )}

                                {/* Action Buttons: Delete (pending/rejected) ONLY - NO HIDE BUTTON */}
                                {(sample.status === 'pending_review' || sample.status === 'rejected') && (
                                  <button
                                    onClick={() => handleDeleteSample(sample.id)}
                                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                    title="حذف العينة"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* Rejection Reason notice if rejected */}
                            {sample.status === 'rejected' && sample.rejectionReason && (
                              <div className="mt-3 p-2.5 rounded-xl bg-rose-50 border border-rose-200/80 text-[11px] text-rose-800 flex items-start gap-2">
                                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                                <div>
                                  <strong className="block">سبب الرفض وتوجيه الإدارة:</strong>
                                  <span>{sample.rejectionReason}</span>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* C) HUMAN IDENTITY VERIFICATION & "HUMAN TALENT" BADGE CARD */}
                {/* «تحقق الهوية وشارة معلق بشري» */}
                <div className="bg-white rounded-3xl p-6 border-2 border-blue-500/30 shadow-sm space-y-6">
                  {/* Hidden Selfie File Input */}
                  <input
                    ref={selfieFileRef}
                    type="file"
                    accept="image/*"
                    capture="user"
                    className="hidden"
                    onChange={handleSelfieSelect}
                  />

                  {/* Header & Status */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 border border-blue-100">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-black text-base text-slate-900">تحقق الهوية وشارة «معلق بشري»</h3>
                          {humanBadgeStatus === 'verified' && (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-600 text-white flex items-center gap-1 shadow-xs">
                              <BadgeCheck className="w-3.5 h-3.5" />
                              <span>شارة معتمدة ✓</span>
                            </span>
                          )}
                          {humanBadgeStatus === 'pending' && (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5" />
                              <span>قيد التدقيق ⏳</span>
                            </span>
                          )}
                          {humanBadgeStatus === 'unverified' && (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600">
                              غير موثق
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          التحقق بصورة سيلفي حية وتسجيل صوتي لنص معتمد للحصول على شارة «معلق بشري» الرسمية أو إيقافها
                        </p>
                      </div>
                    </div>

                    {/* Interactive Badge State Switcher (Allows testing both states: with badge or without badge) */}
                    <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 self-start sm:self-auto text-xs">
                      <span className="text-[10px] text-slate-500 px-2 font-bold hidden sm:inline">تبديل الحالة:</span>
                      <button
                        type="button"
                        onClick={() => {
                          setHumanBadgeStatus('verified');
                          showToast('تم تفعيل شارة «معلق بشري معتمد» 🎙️✓');
                        }}
                        className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                          humanBadgeStatus === 'verified'
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                        title="الحصول على الشارة"
                      >
                        معلق بشري ✓
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setHumanBadgeStatus('pending');
                          showToast('تم نقل الطلب إلى حالة قيد المراجعة ⏳');
                        }}
                        className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                          humanBadgeStatus === 'pending'
                            ? 'bg-amber-500 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                        title="قيد التدقيق"
                      >
                        قيد المراجعة
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setHumanBadgeStatus('unverified');
                          showToast('تم إزالة شارة المعلق البشري (غير موثق)');
                        }}
                        className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                          humanBadgeStatus === 'unverified'
                            ? 'bg-slate-700 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                        title="بدون شارة"
                      >
                        بدون شارة (لا)
                      </button>
                    </div>
                  </div>

                  {/* Top Status Notification Banner */}
                  {humanBadgeStatus === 'verified' && (
                    <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50/50 to-blue-50 border border-blue-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse" />
                          <strong className="text-blue-950 font-black text-sm">
                            شارة «معلق بشري معتمد» مفعلة وتظهر على ملفك الشخصي
                          </strong>
                        </div>
                        <p className="text-blue-800 text-[11px] leading-relaxed">
                          ملفك موثق بنجاح بصورة السيلفي الحية والتسجيل الصوتي. تمنحك هذه الشارة أولوية الظهور للعملاء الباحثين عن تسجيلات بشرية في الاستوديو.
                        </p>
                      </div>

                      <div className="shrink-0 text-left sm:text-right font-mono text-[11px] text-blue-700 bg-white/80 px-3 py-1.5 rounded-xl border border-blue-200">
                        <span className="block font-bold">كود التوثيق: HUM-2026-9812</span>
                        <span className="text-[10px] text-slate-500">معتمد حتى فبراير 2027</span>
                      </div>
                    </div>
                  )}

                  {humanBadgeStatus === 'pending' && (
                    <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-start gap-3 text-xs">
                      <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <strong className="text-amber-950 font-bold block text-sm">
                          طلب التحقق من الهوية قيد المراجعة والتدقيق ⏳
                        </strong>
                        <p className="text-amber-800 text-[11px] leading-relaxed">
                          تم استلام صورة السيلفي والتسجيل الصوتي الحي. يجري فريق ضبط الجودة مطابقة الصوت مع ملامح المعلق. يستغرق التحقق عادة من 15 دقيقة إلى ساعتين.
                        </p>
                      </div>
                    </div>
                  )}

                  {humanBadgeStatus === 'unverified' && (
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3 text-xs">
                      <AlertCircle className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <strong className="text-slate-900 font-bold block text-sm">
                          أنت غير حاصل على شارة «معلق بشري» حالياً
                        </strong>
                        <p className="text-slate-600 text-[11px] leading-relaxed">
                          لإثبات أنك معلق صوتي بشري حقيقي وتمييز حسابك عن النماذج الآلية أو الحصول على مشاريع الاستوديو، يرجى إتمام الخطوتين أدناه (سيلفي حي + تسجيل نص التحقق).
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Two Main Verification Steps */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
                    
                    {/* STEP 1: LIVE SELFIE PHOTO */}
                    <div className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200/90 space-y-4 flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                            <Camera className="w-4 h-4 text-blue-600" />
                            <span>1. التقاط صورة سيلفي حية</span>
                          </span>
                          {selfiePhotoUrl ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span>تم الالتقاط</span>
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                              مطلوب
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 leading-relaxed">
                          التقط صورة ذاتية (Selfie) مباشرة لوجهك بإضاءة واضحة لمطابقتها مع هوية المعلق الصوتي.
                        </p>

                        {/* Selfie Preview or Capture Prompt */}
                        {selfiePhotoUrl ? (
                          <div className="pt-2">
                            <div className="relative w-36 h-36 mx-auto rounded-2xl overflow-hidden border-2 border-blue-500 shadow-md group">
                              <img
                                src={selfiePhotoUrl}
                                alt="Selfie Verification"
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => selfieFileRef.current?.click()}
                                  className="p-2 rounded-xl bg-white text-slate-900 hover:bg-slate-100 text-xs font-bold cursor-pointer"
                                  title="تغيير الصورة"
                                >
                                  <Camera className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSelfiePhotoUrl(null);
                                    setSelfieFileName(null);
                                    showToast('تم حذف صورة السيلفي');
                                  }}
                                  className="p-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700 text-xs font-bold cursor-pointer"
                                  title="حذف"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                              <div className="absolute bottom-1 right-1 bg-blue-600 text-white p-1 rounded-lg text-[9px] font-bold shadow-xs flex items-center gap-0.5">
                                <Check className="w-2.5 h-2.5" />
                              </div>
                            </div>
                            <span className="block text-center text-[10px] text-slate-400 font-mono mt-2 truncate">
                              {selfieFileName || 'live_selfie_verification.jpg'}
                            </span>
                          </div>
                        ) : (
                          <div
                            onClick={() => selfieFileRef.current?.click()}
                            className="p-6 rounded-2xl border-2 border-dashed border-slate-300 hover:border-blue-500 bg-white hover:bg-blue-50/20 text-center transition-all cursor-pointer space-y-2"
                          >
                            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                              <Camera className="w-6 h-6" />
                            </div>
                            <span className="font-bold text-xs text-slate-800 block">
                              انقر لالتقاط صورة سيلفي بالكاميرا أو اختيار صورة
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              صيغة JPG أو PNG (الحد الأقصى 10MB)
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Selfie Guidelines */}
                      <div className="pt-2 border-t border-slate-200/80 text-[10px] text-slate-500 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span>وجه واضح ومباشر نحو الكاميرا</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span>بدون نظارات شمسية أو أقنعة أو فلاتر</span>
                        </div>
                      </div>

                      {/* Selfie Action Button */}
                      <button
                        type="button"
                        onClick={() => selfieFileRef.current?.click()}
                        className="w-full py-2 px-3 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Camera className="w-3.5 h-3.5 text-blue-600" />
                        <span>{selfiePhotoUrl ? 'التقاط صورة سيلفي أخرى' : 'التقاط صورة السيلفي'}</span>
                      </button>
                    </div>

                    {/* STEP 2: VOICE RECORDING OF TEXT */}
                    <div className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200/90 space-y-4 flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                            <Mic className="w-4 h-4 text-orange-500" />
                            <span>2. تسجيل صوتي حي لنص التحقق</span>
                          </span>
                          {humanVoiceRecorded ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span>تم التسجيل ({humanVoiceDuration}ث)</span>
                            </span>
                          ) : isRecordingHumanVoice ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 animate-pulse flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                              <span>جاري التسجيل</span>
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                              مطلوب
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-slate-500">
                          اقرأ النص المعتمد أدناه بصوتك الطبيعي الحي لتأكيد قدرتك وأدائك البشري:
                        </p>

                        {/* Official Required Arabic Verification Text */}
                        <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-slate-800 text-xs leading-relaxed font-serif relative">
                          <span className="text-orange-500 font-black text-lg select-none">“</span>
                          <span className="font-bold text-slate-900">
                            أنا المعلق الصوتي {narrator?.displayName || 'طارق الشمري'}، أؤكد بصوتي الحي وبكامل أهليتي أنني معلق صوتي بشري حقيقي مسجل في منصة قيمة فويس، وأن أدائي الصوتي والعينات المعتمدة تمثل صوتي الطبيعي.
                          </span>
                          <span className="text-orange-500 font-black text-lg select-none">”</span>
                        </div>

                        {/* Live Recording Box & Visual Feedback */}
                        {isRecordingHumanVoice ? (
                          <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-center space-y-3 animate-pulse">
                            <div className="flex items-center justify-center gap-2 text-rose-700 font-black text-sm">
                              <span className="w-3 h-3 rounded-full bg-rose-600 animate-ping" />
                              <span>جاري التسجيل المباشر... 00:{String(humanVoiceTimer).padStart(2, '0')}</span>
                            </div>

                            {/* Sound wave bars */}
                            <div className="flex items-center justify-center gap-1 h-8">
                              {[40, 70, 95, 60, 85, 100, 50, 75, 90, 45, 80, 65].map((h, idx) => (
                                <span
                                  key={idx}
                                  className="w-1 bg-rose-500 rounded-full animate-pulse"
                                  style={{ height: `${h}%`, animationDelay: `${idx * 80}ms` }}
                                />
                              ))}
                            </div>

                            <button
                              type="button"
                              onClick={handleStopRecordHumanVoice}
                              className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center gap-1.5 mx-auto"
                            >
                              <Square className="w-3.5 h-3.5" />
                              <span>إنهاء التسجيل وحفظ العينة</span>
                            </button>
                          </div>
                        ) : humanVoiceRecorded ? (
                          <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2.5">
                              <button
                                type="button"
                                onClick={handleTogglePlayHumanVoice}
                                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                                  isPlayingHumanVoice
                                    ? 'bg-emerald-600 text-white shadow-md animate-pulse'
                                    : 'bg-emerald-600 text-white hover:bg-emerald-700'
                                }`}
                                title={isPlayingHumanVoice ? 'إيقاف' : 'الاستماع للتسجيل'}
                              >
                                {isPlayingHumanVoice ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                              </button>
                              <div className="text-xs">
                                <span className="font-bold text-emerald-950 block">عينة التحقق الصوتي الحي</span>
                                <span className="text-[10px] text-emerald-700 font-mono">المدة: {humanVoiceDuration} ثوانٍ • نبرة طبيعية بنسبة 100%</span>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={handleStartRecordHumanVoice}
                              className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                              title="تسجيل العينة من جديد"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>إعادة التسجيل</span>
                            </button>
                          </div>
                        ) : (
                          <div className="p-3 rounded-xl bg-white border border-slate-200 text-center">
                            <span className="text-[11px] text-slate-500 block mb-2">
                              انقر لبدء التسجيل بصوتك الآن عبر ميكروفون جهازك
                            </span>
                            <button
                              type="button"
                              onClick={handleStartRecordHumanVoice}
                              className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md shadow-orange-500/20 transition-all cursor-pointer flex items-center gap-1.5 mx-auto"
                            >
                              <Mic className="w-4 h-4" />
                              <span>بدء تسجيل النص الآن</span>
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Voice Recording Requirements */}
                      <div className="pt-2 border-t border-slate-200/80 text-[10px] text-slate-500 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span>صوت واضح وخالي من الموسيقى أو الفلاتر الاصطناعية</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span>مطابقة الكلمات مع النص المعتمد أعلاه</span>
                        </div>
                      </div>

                      {/* Voice Action Button */}
                      {!isRecordingHumanVoice && (
                        <button
                          type="button"
                          onClick={handleStartRecordHumanVoice}
                          className="w-full py-2 px-3 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <Mic className="w-3.5 h-3.5 text-orange-500" />
                          <span>{humanVoiceRecorded ? 'إعادة تسجيل عينة التحقق' : 'تسجيل النص الصوتي'}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Submit / Verification Execution Bar */}
                  <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="text-xs space-y-1">
                      <div className="flex items-center gap-3">
                        <span className={`flex items-center gap-1 font-bold ${selfiePhotoUrl ? 'text-emerald-700' : 'text-slate-400'}`}>
                          {selfiePhotoUrl ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-2 h-2 rounded-full bg-slate-300" />}
                          <span>صورة السيلفي الحية</span>
                        </span>

                        <span className={`flex items-center gap-1 font-bold ${humanVoiceRecorded ? 'text-emerald-700' : 'text-slate-400'}`}>
                          {humanVoiceRecorded ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-2 h-2 rounded-full bg-slate-300" />}
                          <span>التسجيل الصوتي للنص</span>
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 block">
                        اكتمال الخطوتين يؤهلك مباشرة للاحتفاظ بشارة «معلق بشري» الموثقة
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {humanBadgeStatus === 'verified' ? (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              setHumanBadgeStatus('unverified');
                              showToast('تم إلغاء تفعيل شارة «معلق بشري» في حسابك');
                            }}
                            className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 font-bold text-xs transition-colors cursor-pointer"
                          >
                            إلغاء الشارة (بدون شارة)
                          </button>

                          <button
                            type="button"
                            onClick={handleSubmitHumanVerification}
                            disabled={isSubmittingHumanVerification}
                            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 transition-all cursor-pointer flex items-center gap-2"
                          >
                            <BadgeCheck className="w-4 h-4" />
                            <span>{isSubmittingHumanVerification ? 'جاري التحديث...' : 'تحديث وتثبيت التوثيق'}</span>
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={handleSubmitHumanVerification}
                          disabled={!selfiePhotoUrl || !humanVoiceRecorded || isSubmittingHumanVerification}
                          className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/25 transition-all cursor-pointer disabled:opacity-40 flex items-center justify-center gap-2"
                        >
                          <BadgeCheck className="w-4 h-4" />
                          <span>{isSubmittingHumanVerification ? 'جاري التحقق والاعتماد...' : 'إرسال طلب الحصول على شارة «معلق بشري»'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* SUBPAGE 3: EARNINGS PAGE «أرباحي» */}
            {/* ========================================================= */}
            {currentSubPage === 'earnings' && (
              <div className="space-y-6 animate-fade-in">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-200/80 pb-4">
                  <div>
                    <h2 className="text-xl font-black text-slate-900">سجل الأرباح</h2>
                    <p className="text-xs text-slate-500 mt-0.5">تفاصيل العوائد المالية من التعليق الصوتي وحجوزات الاستوديو وصوتك الذكي</p>
                  </div>
                  <button
                    onClick={() => navigateToSubPage('main')}
                    className="text-xs font-bold text-slate-500 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>العودة للوحة المعلق</span>
                  </button>
                </div>

                {/* Available Balance & Payout Bar */}
                <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-bold text-slate-400 block">الرصيد المتاح للسحب الفوري</span>
                    <div className="flex items-baseline gap-2 mt-1">
                      <span className="text-3xl font-black font-mono text-emerald-600">
                        ${earningsSummary.availableBalance.toFixed(2)}
                      </span>
                      <span className="text-xs font-bold text-slate-400">دولار</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsPayoutSheetOpen(true)}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CreditCard className="w-4 h-4 text-orange-400" />
                    <span>سحب الأرباح</span>
                  </button>
                </div>

                {/* Tabs: «التعليق الصوتي» | «صوتي AI» */}
                <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl">
                      <button
                        onClick={() => setEarningsTab('vo')}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          earningsTab === 'vo'
                            ? 'bg-white text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        التعليق الصوتي ({voiceOverBookings.length})
                      </button>

                      <button
                        onClick={() => setEarningsTab('ai')}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          earningsTab === 'ai'
                            ? 'bg-white text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        صوتي AI ({usageEvents.length})
                      </button>
                    </div>

                    {/* Month Selector */}
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-slate-400 font-bold">الشهر:</span>
                      <select
                        value={selectedMonthFilter}
                        onChange={(e: any) => setSelectedMonthFilter(e.target.value)}
                        className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-800 font-bold text-xs focus:outline-hidden cursor-pointer"
                      >
                        <option value="all">كل الأشهر (آخر 3 أشهر)</option>
                        <option value="2026-10">أكتوبر 2026</option>
                        <option value="2026-09">سبتمبر 2026</option>
                        <option value="2026-08">أغسطس 2026</option>
                      </select>
                    </div>
                  </div>

                  {/* Tab 1: Human Voice-over bookings */}
                  {earningsTab === 'vo' && (
                    <div className="divide-y divide-slate-100">
                      {voiceOverBookings
                        .filter(b => selectedMonthFilter === 'all' || b.date.startsWith(selectedMonthFilter))
                        .length === 0 ? (
                        <p className="text-center py-8 text-slate-400 text-xs">لا توجد حجوزات في هذه الفترة.</p>
                      ) : (
                        voiceOverBookings
                          .filter(b => selectedMonthFilter === 'all' || b.date.startsWith(selectedMonthFilter))
                          .map(booking => {
                            const statusBadge = {
                              in_progress: { label: 'قيد التنفيذ', color: 'bg-amber-50 text-amber-700' },
                              completed: { label: 'مكتمل', color: 'bg-blue-50 text-blue-700' },
                              paid: { label: 'مدفوع', color: 'bg-emerald-50 text-emerald-700' }
                            }[booking.status];

                            return (
                              <div key={booking.id} className="py-3.5 flex items-center justify-between text-xs hover:bg-slate-50/50 px-2 rounded-xl transition-colors">
                                <div className="space-y-1">
                                  <span className="font-bold text-slate-900 block text-sm">{booking.projectTitle}</span>
                                  <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                                    <span>{booking.date}</span>
                                    <span>•</span>
                                    <span className={`px-2 py-0.5 rounded-full font-sans font-bold text-[10px] ${statusBadge.color}`}>
                                      {statusBadge.label}
                                    </span>
                                  </div>
                                </div>

                                <span className="font-bold font-mono text-slate-900 text-base">
                                  ${booking.amount.toFixed(2)}
                                </span>
                              </div>
                            );
                          })
                      )}
                    </div>
                  )}

                  {/* Tab 2: AI Voice Usages (NEVER SHOW CLIENT NAMES) */}
                  {earningsTab === 'ai' && (
                    <div className="divide-y divide-slate-100">
                      {usageEvents
                        .filter(ev => selectedMonthFilter === 'all' || ev.createdAt.startsWith(selectedMonthFilter))
                        .length === 0 ? (
                        <p className="text-center py-8 text-slate-400 text-xs">لا توجد استخدامات لصوتك الذكي في هذه الفترة.</p>
                      ) : (
                        usageEvents
                          .filter(ev => selectedMonthFilter === 'all' || ev.createdAt.startsWith(selectedMonthFilter))
                          .map(ev => (
                            <div key={ev.id} className="py-3.5 flex items-center justify-between text-xs hover:bg-slate-50/50 px-2 rounded-xl transition-colors">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="w-2 h-2 rounded-full bg-orange-400" />
                                  <span className="font-bold text-slate-900 text-sm">
                                    {USE_CASE_LABELS[ev.useCase] || ev.useCase}
                                  </span>
                                </div>
                                <span className="text-[11px] text-slate-400 font-mono block">
                                  {new Date(ev.createdAt).toLocaleDateString('ar-SA')}
                                </span>
                              </div>

                              <span className="font-bold font-mono text-emerald-600 text-base">
                                + ${ev.narratorEarning?.toFixed(2) || '0.00'}
                              </span>
                            </div>
                          ))
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* SUBPAGE 4: SETTINGS PAGE «إعدادات صوتي الذكي» */}
            {/* ========================================================= */}
            {currentSubPage === 'settings' && (
              <div className="space-y-6 animate-fade-in">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-200/80 pb-4">
                  <div>
                    <h2 className="text-xl font-black text-slate-900">إعدادات صوتي الذكي</h2>
                    <p className="text-xs text-slate-500 mt-0.5">التحكم في التراخيص وحصص الأرباح والضوابط الأخلاقية</p>
                  </div>
                  <button
                    onClick={() => navigateToSubPage('main')}
                    className="text-xs font-bold text-slate-500 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>العودة للوحة المعلق</span>
                  </button>
                </div>

                {/* Allowed Use Cases */}
                <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">مجالات الاستخدام المصرح بها</h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      حدد المجالات التي توافق على توليد صوتك الذكي فيها. أي تعديل ينشئ تلقائيًا نسخة عقد جديدة في سجل التدقيق.
                    </p>
                  </div>

                  {/* Allowed Toggles */}
                  <div className="flex flex-wrap gap-2 pt-2">
                    {(['ads', 'corporate', 'elearning', 'ivr', 'documentary', 'podcast', 'social', 'audiobook'] as UseCase[]).map(key => {
                      const isChecked = contract?.allowedUseCases.includes(key);

                      return (
                        <button
                          key={key}
                          onClick={() => handleToggleUseCase(key)}
                          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
                            isChecked
                              ? 'bg-orange-500 text-white border-orange-500 shadow-xs'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {isChecked && <Check className="w-3.5 h-3.5" />}
                          <span>{USE_CASE_LABELS[key]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Notice Period Selection */}
                <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">فترة الإشعار لإنهاء العقد وحصة الأرباح</h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      الفترة الزمنية الحالية: <strong className="text-slate-800">{contract?.noticePeriodDays || 365} يومًا</strong> (حصة أرباح {contract?.revenueSharePercent || 45}%).
                      يمكنك فقط اختيار فترات أطول لرفع نسبة أرباحك، ولا يمكن تقليلها.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {NOTICE_PERIOD_OPTIONS.map(opt => {
                      const currentDays = contract?.noticePeriodDays || 365;
                      const isCurrent = currentDays === opt.days;
                      const isShorter = opt.days < currentDays;

                      return (
                        <div
                          key={opt.days}
                          onClick={() => !isShorter && handleSelectNoticePeriod(opt.days as any)}
                          className={`p-3.5 rounded-2xl border transition-all text-xs flex items-center justify-between ${
                            isCurrent
                              ? 'border-orange-500 bg-orange-50/40 text-orange-950 font-bold'
                              : isShorter
                              ? 'border-slate-100 bg-slate-50/50 text-slate-400 cursor-not-allowed'
                              : 'border-slate-200 hover:border-slate-300 bg-white cursor-pointer'
                          }`}
                        >
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span>{opt.label}</span>
                              {isCurrent && <span className="text-[10px] bg-orange-500 text-white px-2 py-0.2 rounded-full">الحالي</span>}
                            </div>
                            <span className="text-[10px] text-slate-500 block mt-0.5">{opt.desc}</span>
                          </div>

                          {isShorter ? (
                            <Lock className="w-3.5 h-3.5 text-slate-300" />
                          ) : isCurrent ? (
                            <Check className="w-4 h-4 text-orange-600" />
                          ) : (
                            <span className="text-orange-600 font-bold text-[11px]">ترقية ↑</span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* قسم "الموافقة والإقرار الرقمي المعتمد" */}
                <div className="bg-white rounded-3xl p-6 border-2 border-orange-500/30 shadow-sm space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-orange-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </div>
                      <div>
                        <h3 className="font-black text-base text-slate-900">الموافقة والإقرار الرقمي المعتمد</h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          ترخيص البصمة الصوتية والموافقة الصريحة وتواريخ سريان العقد
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Fixed Approved Status Badge matching screenshot */}
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1.5 shadow-xs">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>تم اعتماد الموافقة ✓</span>
                      </span>

                      <button
                        onClick={() => window.print()}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                        title="طباعة العقد"
                      >
                        <Printer className="w-3.5 h-3.5 text-slate-600" />
                        <span>طباعة</span>
                      </button>

                      <button
                        onClick={() => {
                          showToast('تم إعداد وتحميل نسخة وثيقة العقد الرقمية المعتمدة');
                        }}
                        className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5 text-orange-400" />
                        <span>تحميل وثيقة العقد</span>
                      </button>
                    </div>
                  </div>

                  {/* 1. KEY DATES & METRICS CARDS */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                    {/* Start Date */}
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                      <span className="text-[11px] text-slate-400 block font-medium">تاريخ بدء سريان الترخيص:</span>
                      <div className="flex items-center gap-1.5 text-slate-900 font-bold">
                        <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="font-mono text-sm font-black">15 فبراير 2026</span>
                      </div>
                      <span className="text-[10px] text-emerald-700 font-bold block">✓ سارٍ من تاريخ التوقيع</span>
                    </div>

                    {/* Expiry Date */}
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                      <span className="text-[11px] text-slate-400 block font-medium">تاريخ انتهاء سريان الترخيص:</span>
                      <div className="flex items-center gap-1.5 text-slate-900 font-bold">
                        <Clock className="w-3.5 h-3.5 text-orange-600" />
                        <span className="font-mono text-sm font-black text-orange-600">15 فبراير 2027</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-medium block">تجديد سنوي بموافقة الطرفين</span>
                    </div>

                    {/* Period */}
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-slate-400 font-medium">فترة الترخيص التعاقدية:</span>
                        <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-orange-500 text-white">الحالي</span>
                      </div>
                      <div className="text-sm font-black text-slate-900">
                        سنة واحدة (365 يومًا)
                      </div>
                      <span className="text-[10px] text-slate-500 block">فترة إشعار سحب الموافقة</span>
                    </div>

                    {/* Revenue Share */}
                    <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-slate-400 font-medium">نسبة حصتك من الإيرادات:</span>
                        <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-100 text-amber-800">الأكثر شيوعاً</span>
                      </div>
                      <div className="text-base font-black font-mono text-orange-600">
                        40%
                      </div>
                      <span className="text-[10px] text-slate-500 block">من إجمالي مبيعات كل استخدام</span>
                    </div>
                  </div>

                  {/* 2. FIXED / IMMUTABLE CONSENT APPROVAL CARD (موافقة وإقرار ثابت لا يمكن تغييره) */}
                  <div className="p-5 rounded-2xl bg-orange-50/40 border border-orange-200/90 transition-all select-none">
                    <div className="flex items-start gap-3.5">
                      {/* Fixed Checked Box - permanently locked and checked */}
                      <div className="mt-1 shrink-0">
                        <div 
                          className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs ring-2 ring-blue-600/30 cursor-default"
                          title="إقرار معتمد وموثق رقمياً (ثابت ولا يمكن تعديله)"
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      </div>

                      <div className="space-y-3 flex-1">
                        <span className="font-bold text-slate-900 text-xs sm:text-sm leading-relaxed block">
                          أقر بكامل أهليتي الشرعية والنظامية بموافقتي التامة على بنود عقد ترخيص واستنساخ بصمتي الصوتية لصالح منصة قيمة فويس، وفق الشروط المحددة بحصة أرباح 40% (الأكثر شيوعاً) وتواريخ السريان الموضحة أدناه:
                        </span>

                        {/* Display of License Validity Start and End Dates matching the pills in image */}
                        <div className="flex flex-wrap items-center gap-2.5 pt-1 text-xs">
                          <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white border border-emerald-400 font-bold text-emerald-950 shadow-xs">
                            <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                            <span>تاريخ بدء سريان الترخيص:</span>
                            <span className="font-mono font-black text-sm text-emerald-700">15 فبراير 2026</span>
                          </div>

                          <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white border border-orange-400 font-bold text-orange-950 shadow-xs">
                            <Clock className="w-3.5 h-3.5 text-orange-600" />
                            <span>تاريخ انتهاء سريان الترخيص:</span>
                            <span className="font-mono font-black text-sm text-orange-700">15 فبراير 2027</span>
                          </div>

                          <div className="flex items-center gap-1 px-3.5 py-1.5 rounded-full bg-slate-100 text-slate-700 font-bold text-xs">
                            <span>المدة:</span>
                            <span>سنة واحدة (الحالي)</span>
                          </div>

                          <span className="px-2.5 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-[10px] font-black flex items-center gap-1">
                            <Check className="w-3 h-3 text-blue-600" />
                            <span>إقرار ثابت ومعتمد لا يمكن تغييره</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Signatory details */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <span className="text-[11px] text-slate-400 block font-medium">الاسم الموقع إلكترونياً (المعلق الصوتي):</span>
                      <strong className="text-slate-900 font-black text-sm">{contract?.signatureName || narrator?.displayName}</strong>
                    </div>

                    <div className="text-right sm:text-left font-mono text-[11px] text-slate-500 space-y-0.5">
                      <p>عنوان بروتوكول الإنترنت المعتمد: {contract?.ipAddress || '151.254.12.89'}</p>
                      <p className="text-emerald-700 font-bold">ختم زمني رقمي مشفر وموثق • معتمد قانونياً</p>
                    </div>
                  </div>

                  {/* Secondary Action: Withdraw consent & emergency */}
                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs border-t border-slate-100">
                    <button
                      onClick={() => setIsWithdrawModalOpen(true)}
                      className="text-rose-600 hover:text-rose-700 font-bold underline cursor-pointer"
                    >
                      سحب الموافقة وبدء فترة إشعار إنهاء العقد
                    </button>

                    <button
                      onClick={() => setIsEmergencyHaltOpen(true)}
                      className="text-slate-400 hover:text-slate-600 text-[11px] cursor-pointer"
                    >
                      طلب إيقاف فوري لأسباب استثنائية ←
                    </button>
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* ========================================================= */}
      {/* MODAL 1: PAYOUT BOTTOM SHEET */}
      {/* ========================================================= */}
      {isPayoutSheetOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-[480px] bg-white rounded-t-3xl sm:rounded-3xl p-6 text-right space-y-4 shadow-2xl animate-fade-in max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900">سحب الأرباح المتاحة</h3>
              <button
                onClick={() => setIsPayoutSheetOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {payoutSuccessMsg ? (
              <div className="p-6 text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <p className="font-bold text-sm text-slate-900">{payoutSuccessMsg}</p>
                <p className="text-xs text-slate-500">تتم معالجة التحويلات البنكية خلال 24 ساعة عمل.</p>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">المبلغ المطلوب سحبه (بالدولار)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="10"
                    max={earningsSummary.availableBalance}
                    value={payoutAmount}
                    onChange={(e) => setPayoutAmount(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-lg font-mono font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    الحد الأقصى المتاح: ${earningsSummary.availableBalance.toFixed(2)}
                  </span>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">طريقة استلام الأرباح</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPayoutMethod('bank')}
                      className={`p-3 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                        payoutMethod === 'bank'
                          ? 'border-orange-500 bg-orange-50/50 text-orange-950'
                          : 'border-slate-200 text-slate-600'
                      }`}
                    >
                      <Building className="w-4 h-4 mx-auto mb-1 text-slate-600" />
                      <span>تحويل بنكي (آيبان)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPayoutMethod('wallet')}
                      className={`p-3 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                        payoutMethod === 'wallet'
                          ? 'border-orange-500 bg-orange-50/50 text-orange-950'
                          : 'border-slate-200 text-slate-600'
                      }`}
                    >
                      <Smartphone className="w-4 h-4 mx-auto mb-1 text-slate-600" />
                      <span>محفظة رقمية محلية</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {payoutMethod === 'bank' ? 'رقم الحساب الدولي (الآيبان)' : 'رقم جوال المحفظة'}
                  </label>
                  <input
                    type="text"
                    value={payoutAccount}
                    onChange={(e) => setPayoutAccount(e.target.value)}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs text-slate-900 focus:outline-hidden focus:border-orange-500"
                    dir="ltr"
                  />
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleConfirmPayout}
                    className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer"
                  >
                    تأكيد طلب السحب
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 2: WITHDRAW CONSENT MODAL */}
      {/* ========================================================= */}
      {isWithdrawModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-[460px] bg-white rounded-3xl p-6 text-right space-y-4 shadow-2xl animate-fade-in">
            <div className="flex items-center gap-2 text-rose-600 pb-2 border-b border-slate-100">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h3 className="font-bold text-base text-slate-900">سحب الموافقة وبدء فترة الإشعار</h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              وفقًا للعقد المعتمد، عند سحب الموافقة، يدخل صوتك الذكي في <strong>فترة إشعار مدتها ({contract?.noticePeriodDays || 365} يومًا)</strong>.
              سيتوقف صوتك نهائيًا عن العمل ولن يتمكن أي عميل جديد من استخدامه، مع استمرار إيفاء المشاريع القائمة حتى نهاية المدة.
            </p>

            <div className="p-3 bg-rose-50 border border-rose-100 rounded-2xl text-xs text-rose-900 space-y-1">
              <p className="font-bold">التاريخ النهائي لإيقاف صوتك الذكي بالكامل:</p>
              <p className="text-base font-black font-mono text-rose-700">
                {new Date(Date.now() + (contract?.noticePeriodDays || 365) * 86400000).toLocaleDateString('ar-SA', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                لتأكيد القرار، اكتب كلمة <span className="text-rose-600 font-black">تأكيد</span> أدناه:
              </label>
              <input
                type="text"
                value={confirmInputText}
                onChange={(e) => setConfirmInputText(e.target.value)}
                placeholder="اكتب: تأكيد"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:border-rose-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleConfirmWithdrawNotice}
                disabled={confirmInputText.trim() !== 'تأكيد' || isWithdrawSubmitting}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-all shadow-md shadow-rose-600/25 disabled:opacity-40 cursor-pointer"
              >
                {isWithdrawSubmitting ? 'جاري التنفيذ...' : 'تأكيد بدء فترة الإشعار'}
              </button>
              <button
                onClick={() => {
                  setIsWithdrawModalOpen(false);
                  setConfirmInputText('');
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
              >
                تراجع
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 3: EMERGENCY HALT REQUEST FORM */}
      {/* ========================================================= */}
      {isEmergencyHaltOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-[460px] bg-white rounded-3xl p-6 text-right space-y-4 shadow-2xl animate-fade-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-base text-slate-900">طلب إيقاف فوري لأسباب استثنائية</h3>
              <button
                onClick={() => setIsEmergencyHaltOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {emergencySuccess ? (
              <div className="p-6 text-center space-y-2">
                <Check className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="font-bold text-sm text-slate-900">تم رفع الطلب بنجاح</p>
                <p className="text-xs text-slate-500">سيتواصل معك فريق الشؤون القانونية والعمليات فورًا.</p>
              </div>
            ) : (
              <div className="space-y-3 text-xs">
                <p className="text-slate-600">
                  مخصص للحالات القاهرة الطارئة (مثل الوفاة، التعاقد الحصري الرسمي المانع، أو النزاعات القانونية).
                </p>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">سبب طلب الإيقاف الاستثنائي</label>
                  <select
                    value={emergencyReason}
                    onChange={(e) => setEmergencyReason(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="ظروف قاهرة تمنع استخدام الصوت">ظروف قاهرة تمنع استخدام الصوت</option>
                    <option value="تعاقد حصري حكومي أو إذاعي مانع">تعاقد حصري حكومي أو إذاعي مانع</option>
                    <option value="وفاة أو عجز قانوني">وفاة أو عجز قانوني</option>
                    <option value="أخرى">أسباب أخرى استثنائية</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">تفاصيل إضافية للمراجعة</label>
                  <textarea
                    rows={3}
                    value={emergencyNotes}
                    onChange={(e) => setEmergencyNotes(e.target.value)}
                    placeholder="وضح ملابسات الحالة لفريق العمليات..."
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:border-orange-500 resize-none"
                  />
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={handleSubmitEmergencyHalt}
                    className="flex-1 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all shadow-md cursor-pointer"
                  >
                    إرسال الطلب للإدارة
                  </button>
                  <button
                    onClick={() => setIsEmergencyHaltOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 4: 6-DIGIT OTP VERIFICATION MODAL */}
      {/* ========================================================= */}
      {isVerificationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-[420px] bg-white rounded-3xl p-6 text-right space-y-4 shadow-2xl animate-fade-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-blue-600">
                <ShieldCheck className="w-5 h-5" />
                <h3 className="font-bold text-sm text-slate-900">التحقق من بيانات التواصل الجديدة</h3>
              </div>
              <button
                onClick={() => {
                  setIsVerificationModalOpen(false);
                  setPendingVerificationData(null);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              لحماية حسابك، تم إرسال رمز تحقق مكوّن من 6 أرقام إلى:
              <br />
              <strong className="text-slate-900 font-mono text-sm block mt-1" dir="ltr">
                {verificationTargetDesc}
              </strong>
            </p>

            {/* Simulated SMS/Email Notification Banner */}
            <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200 text-blue-900 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <span>📩 إشعار وصول الرمز (تجريبي):</span>
              </div>
              <p className="text-slate-600">
                رمز التحقق لتأكيد التعديل هو:{' '}
                <strong className="font-mono text-base text-blue-700 font-black">{generatedDemoOtp}</strong>
              </p>
            </div>

            <div>
              <label className="block text-slate-700 font-bold text-xs mb-1.5">
                أدخل رمز التحقق (6 أرقام):
              </label>
              <input
                type="text"
                maxLength={6}
                value={otpCodeInput}
                onChange={(e) => {
                  setOtpCodeInput(e.target.value.replace(/\D/g, ''));
                  setOtpError(null);
                }}
                placeholder="######"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-center font-mono font-black text-xl tracking-widest text-slate-900 focus:outline-hidden focus:border-blue-500"
                dir="ltr"
              />
              {otpError && (
                <p className="text-[11px] text-rose-500 mt-1 font-medium">{otpError}</p>
              )}
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={handleConfirmVerificationOtp}
                disabled={isVerifyingOtp || otpCodeInput.length !== 6}
                className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-all shadow-md shadow-blue-600/25 disabled:opacity-40 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{isVerifyingOtp ? 'جاري التحقق...' : 'تأكيد وحفظ البيانات'}</span>
              </button>
              <button
                onClick={() => {
                  setIsVerificationModalOpen(false);
                  setPendingVerificationData(null);
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 5: ADD VOICE SAMPLE FORM (MAX 3 SAMPLES) */}
      {/* ========================================================= */}
      {isAddSampleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-[460px] bg-white rounded-3xl p-6 text-right space-y-4 shadow-2xl animate-fade-in max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-orange-600">
                <Music className="w-5 h-5" />
                <div>
                  <h3 className="font-bold text-sm text-slate-900">إضافة عينة صوتية جديدة</h3>
                  <span className="text-[10px] text-slate-500 block">العينة رقم {voiceSamples.length + 1} من 3 عينات متاحة</span>
                </div>
              </div>
              <button
                onClick={() => setIsAddSampleModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSample} className="space-y-4 text-xs">
              {/* Sample Title */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">عنوان العينة *</label>
                <input
                  type="text"
                  value={newSampleTitle}
                  onChange={(e) => setNewSampleTitle(e.target.value)}
                  placeholder="مثال: إعلان سيارة عائلية فاخرة أو رد آلي بنكي"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
                  required
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">التصنيف *</label>
                <select
                  value={newSampleCategory}
                  onChange={(e) => setNewSampleCategory(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:border-orange-500 cursor-pointer"
                >
                  {SAMPLE_CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Dialect */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">اللهجة المعتمدة *</label>
                <input
                  type="text"
                  value={newSampleDialect}
                  onChange={(e) => setNewSampleDialect(e.target.value)}
                  placeholder="مثال: سعودي نجدي، فصحى معاصرة، خليجي عام..."
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
                  required
                />
              </div>

              {/* Minute Price Display (Read-only, Cannot be modified by narrator) */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs flex items-center justify-between">
                <div>
                  <span className="text-slate-700 font-bold block">سعر الدقيقة المعتمد:</span>
                  <span className="text-[10px] text-slate-500">سعر الدقيقة محدد للعينة ومسجل في المنصة</span>
                </div>
                <div className="px-3 py-1 rounded-lg bg-white border border-slate-200 font-mono font-black text-slate-900 text-sm">
                  $80 / دقيقة
                </div>
              </div>

              {/* File Upload Simulation (Strictly MP3 only, Max 20MB) */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  رفع الملف الصوتي (<span className="text-orange-600 font-black">صيغة إم بي ثري الصوتية فقط</span>، الحد الأقصى 20 ميجابايت) *
                </label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const file = e.dataTransfer.files?.[0];
                    if (file) {
                      const isMp3 = file.name.toLowerCase().endsWith('.mp3') || file.type === 'audio/mpeg' || file.type === 'audio/mp3';
                      if (!isMp3) {
                        setSampleFormError('جودة الملف: يرجى اختيار ملف صوتي بصيغة mp3 فقط');
                        setNewSampleFileName(null);
                        return;
                      }
                      if (file.size > 20 * 1024 * 1024) {
                        setSampleFormError('حجم الملف يتجاوز الحد الأقصى المسموح (20 ميجابايت)');
                        setNewSampleFileName(null);
                        return;
                      }
                      setSampleFormError(null);
                      setNewSampleFileName(file.name);
                    }
                  }}
                  className="p-5 border-2 border-dashed border-slate-200 hover:border-orange-500 rounded-2xl bg-slate-50 text-center space-y-2 cursor-pointer transition-colors group"
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept=".mp3,audio/mpeg,audio/mp3"
                    className="hidden"
                  />
                  <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                    <Upload className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-800 text-xs">
                      {newSampleFileName || 'انقر لاختيار ملف صوتي أو سحبه هنا'}
                    </p>
                    <span className="text-[10px] text-slate-500 block font-mono mt-0.5">
                      {newSampleFileName 
                        ? `✓ تم اعتماد واختيار الملف: ${newSampleFileName}` 
                        : 'جودة الملف: صيغة صوتية نقية (الحد الأقصى 20 ميجابايت)'}
                    </span>
                  </div>
                  {!newSampleFileName && (
                    <div className="pt-1">
                      <span 
                        onClick={(e) => {
                          e.stopPropagation();
                          setSampleFormError(null);
                          setNewSampleFileName('عينة_صوتية_استوديو_نقية.mp3');
                        }}
                        className="inline-block text-[10px] font-bold text-orange-600 bg-orange-50 hover:bg-orange-100 px-2.5 py-1 rounded-lg border border-orange-200 cursor-pointer"
                      >
                        ⚡ تجربة عينة صوتية جاهزة للمعاينة
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Guidelines reminder notice */}
              <div className="p-3 rounded-xl bg-orange-50/70 border border-orange-200 text-[11px] text-orange-950 space-y-1">
                <span className="font-bold block">ملاحظة التوافق مع شروط المنصة:</span>
                <p className="text-slate-700">
                  متاح إضافة 3 عينات بشرط التوافق مع شروط العينات في المنصة: جودة الملف: <strong>صيغة صوتية نقية</strong>، ونقاء التسجيل وعزل الصدى والضوضاء، وتقديم صوت خام نقي ومباشر بدون موسيقى خلفية.
                </p>
              </div>

              {sampleFormError && (
                <p className="text-[11px] text-rose-500 font-medium">{sampleFormError}</p>
              )}

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  disabled={isSubmittingSample}
                  className="flex-1 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs transition-all shadow-md shadow-orange-500/25 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isSubmittingSample ? 'جاري الرفع...' : 'رفع العينة للاعتماد'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddSampleModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
