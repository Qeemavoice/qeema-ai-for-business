import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Lock, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Upload, 
  Camera, 
  Mic, 
  Square, 
  Play, 
  Pause, 
  RotateCcw, 
  FileText, 
  Check, 
  ArrowLeft, 
  ArrowRight, 
  Sliders, 
  Volume2, 
  VolumeX, 
  Clock, 
  ExternalLink,
  ChevronLeft
} from 'lucide-react';
import { narratorService } from '../../services/narratorService';
import { 
  Narrator, 
  VoiceContract, 
  AIVoice, 
  UseCase, 
  ActiveView 
} from '../../types';

interface AIVoiceCloneWizardProps {
  narratorId?: string;
  onNavigate: (view: ActiveView, tab?: any) => void;
  onFinished?: () => void;
}

export const AIVoiceCloneWizard: React.FC<AIVoiceCloneWizardProps> = ({
  narratorId = 'narrator_tareq_01',
  onNavigate,
  onFinished
}) => {
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [narrator, setNarrator] = useState<Narrator | null>(null);
  const [aiVoice, setAiVoice] = useState<AIVoice | null>(null);
  const [loading, setLoading] = useState(true);

  // STEP 1 State: FAQ Accordion
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  // STEP 2 State: KYC
  const [idPhotoName, setIdPhotoName] = useState<string>('national_id_front.jpg');
  const [selfiePhotoName, setSelfiePhotoName] = useState<string>('live_selfie_verify.jpg');
  const [kycStatus, setKycStatus] = useState<'none' | 'pending' | 'approved' | 'rejected'>('none');
  const [isSubmittingKyc, setIsSubmittingKyc] = useState(false);

  // STEP 3 State: Contract & Consent
  const ALL_ALLOWED_USE_CASES: { id: UseCase; label: string }[] = [
    { id: 'ads', label: 'إعلانات تجارية وترويجية' },
    { id: 'corporate', label: 'عروض وفيديوهات الشركات' },
    { id: 'elearning', label: 'التعليم والتدريب الإلكتروني' },
    { id: 'ivr', label: 'الردود الآلية والبدالات IVR' },
    { id: 'documentary', label: 'الأفلام الوثائقية والتقارير' },
    { id: 'podcast', label: 'البودكاست والمحتوى الصوتي' },
    { id: 'social', label: 'فيديوهات منصات التواصل الاجتماعي' },
    { id: 'audiobook', label: 'الكتب والروايات المسموعة' }
  ];

  const BLOCKED_USE_CASES = [
    'المحتوى السياسي والانتخابي',
    'المحتوى الديني والجدلي',
    'محتوى البالغين والممنوعات',
    'ألعاب القمار واليانصيب',
    'انتحال الشخصيات والتضليل المالي'
  ];

  const [allowedCases, setAllowedCases] = useState<UseCase[]>([
    'ads', 'corporate', 'elearning', 'ivr', 'documentary', 'podcast', 'social', 'audiobook'
  ]);
  const [noticePeriod, setNoticePeriod] = useState<30 | 180 | 365 | 730>(365);
  const [hasScrolledToContractBottom, setHasScrolledToContractBottom] = useState(false);
  const [signatureName, setSignatureName] = useState('');
  const [consentAgreementChecked, setConsentAgreementChecked] = useState(false);
  const [isSigningContract, setIsSigningContract] = useState(false);
  const contractScrollRef = useRef<HTMLDivElement>(null);

  // Revenue share calculation from notice period
  const getRevShare = (days: 30 | 180 | 365 | 730) => {
    switch (days) {
      case 30: return 25;
      case 180: return 35;
      case 365: return 45;
      case 730: return 50;
      default: return 45;
    }
  };

  // STEP 4 State: Recording & Quality
  const [consentRandomCode] = useState(() => Math.floor(1000 + Math.random() * 9000).toString());
  const [isRecordingConsent, setIsRecordingConsent] = useState(false);
  const [consentAudioRecorded, setConsentAudioRecorded] = useState(false);
  const [consentAudioTimer, setConsentAudioTimer] = useState(0);

  const [recordingMode, setRecordingMode] = useState<'mic' | 'upload'>('mic');
  const [selectedDialect, setSelectedDialect] = useState('سعودي نجدي');
  const [isRecordingSample, setIsRecordingSample] = useState(false);
  const [sampleDuration, setSampleDuration] = useState(78); // default realistic seconds
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);

  // Quality check states
  const [qualityChecked, setQualityChecked] = useState(true);
  const [qualityDurationPass, setQualityDurationPass] = useState(true);
  const [qualityNoClipping, setQualityNoClipping] = useState(true);
  const [qualityNoisePass, setQualityNoisePass] = useState(true);

  // Processing state
  const [isProcessingModel, setIsProcessingModel] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);

  // STEP 5 State: Previews & Publish
  const [playingPreviewIdx, setPlayingPreviewIdx] = useState<number | null>(null);
  const [isPublishingVoice, setIsPublishingVoice] = useState(false);

  const PREVIEW_CASES = [
    {
      title: 'إعلان تسويقي سريع',
      category: 'Commercial Ad',
      text: 'اكتشف الجيل الجديد من الحلول اللوجستية الذكية في المملكة. سرعة في التوصيل، وكفاءة تفوق التوقعات.',
      duration: '0:07'
    },
    {
      title: 'مادة تعليمية وتدريبية',
      category: 'E-Learning',
      text: 'في هذه الوحدة التدريبية، سنتعرف على أساسيات الحوكمة وإدارة المخاطر التشغيلية في المنشآت الحديثة.',
      duration: '0:09'
    },
    {
      title: 'رد آلي مصرفي (IVR)',
      category: 'Customer Care',
      text: 'مرحبًا بك في مصرف المستقبل. لخدمات الحسابات الجارية اضغط الرقم واحد، للتمويل الشخصي اضغط الرقم اثنين.',
      duration: '0:08'
    },
    {
      title: 'محتوى شبكات اجتماعية',
      category: 'Social Media',
      text: 'عالم الذكاء الاصطناعي يتغير كل يوم. لا تفوت فرصتك لمواكبة المستقبل الرقمي وكن في الصدارة!',
      duration: '0:06'
    },
    {
      title: 'سرد وثائقي فخم',
      category: 'Documentary',
      text: 'هنا، حيث تلتقي أصالة الصحراء مع أفق المستقبل، تبدأ حكاية مدينة لا تعرف المستحيل.',
      duration: '0:10'
    }
  ];

  // Load Narrator & AI Voice State
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      try {
        const n = await narratorService.getNarratorById(narratorId);
        if (n) {
          setNarrator(n);
          setKycStatus(n.kycStatus);
          setSignatureName(n.displayName);
        }
        const v = await narratorService.getAIVoice(narratorId);
        if (v) {
          setAiVoice(v);
          // Resume saved progress if in progress
          if (v.status === 'kyc_pending') setCurrentStep(2);
          else if (v.status === 'contract_signed') setCurrentStep(4);
          else if (v.status === 'preview_ready') setCurrentStep(5);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [narratorId]);

  // Contract scroll listener
  const handleContractScroll = () => {
    if (!contractScrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = contractScrollRef.current;
    if (scrollTop + clientHeight >= scrollHeight - 30) {
      setHasScrolledToContractBottom(true);
    }
  };

  // Step 2: KYC Submit
  const handleApproveKyc = async () => {
    if (!narrator) return;
    setIsSubmittingKyc(true);
    try {
      const updated = await narratorService.submitKyc(narrator.id, idPhotoName, selfiePhotoName);
      setNarrator(updated);
      setKycStatus('approved');
      setCurrentStep(3);
    } finally {
      setIsSubmittingKyc(false);
    }
  };

  // Step 3: Contract Sign
  const handleSignContract = async () => {
    if (!narrator || !signatureName || !consentAgreementChecked) return;
    setIsSigningContract(true);
    try {
      await narratorService.signVoiceContract({
        narratorId: narrator.id,
        allowedUseCases: allowedCases,
        noticePeriodDays: noticePeriod,
        revenueSharePercent: getRevShare(noticePeriod),
        signatureName
      });
      setCurrentStep(4);
    } finally {
      setIsSigningContract(false);
    }
  };

  // Step 4: Spoken Consent Simulation
  const handleRecordConsent = () => {
    if (isRecordingConsent) {
      setIsRecordingConsent(false);
      setConsentAudioRecorded(true);
    } else {
      setIsRecordingConsent(true);
      setConsentAudioTimer(0);
      const interval = setInterval(() => {
        setConsentAudioTimer(prev => {
          if (prev >= 14) {
            clearInterval(interval);
            setIsRecordingConsent(false);
            setConsentAudioRecorded(true);
            return 15;
          }
          return prev + 1;
        });
      }, 1000);
    }
  };

  // Step 4: Submit to ElevenLabs Backend
  const handleSubmitCloning = async () => {
    if (!narrator) return;
    setIsProcessingModel(true);
    setProcessingProgress(15);

    const progressTimer = setInterval(() => {
      setProcessingProgress(p => {
        if (p >= 90) {
          clearInterval(progressTimer);
          return 90;
        }
        return p + 15;
      });
    }, 300);

    try {
      const cloned = await narratorService.processCloningWithElevenLabs(narrator.id, {
        dialect: selectedDialect,
        sampleUrls: ['/mock/sample_1.wav'],
        qualityMetrics: {
          durationSeconds: sampleDuration,
          clippingDetected: false,
          noiseScore: 'excellent',
          isClean: true
        }
      });
      clearInterval(progressTimer);
      setProcessingProgress(100);
      setAiVoice(cloned);
      setTimeout(() => {
        setIsProcessingModel(false);
        setCurrentStep(5);
      }, 500);
    } catch (err) {
      clearInterval(progressTimer);
      setIsProcessingModel(false);
      alert('حدث خطأ أثناء معالجة النموذج');
    }
  };

  // Step 5: Publish approval
  const handlePublishVoice = async () => {
    if (!narrator) return;
    setIsPublishingVoice(true);
    try {
      await narratorService.approveAndPublishVoice(narrator.id);
      onFinished?.();
      onNavigate('talent-dashboard');
    } finally {
      setIsPublishingVoice(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b12] text-slate-100 flex flex-col font-['Cairo',sans-serif]" dir="rtl">
      {/* Top Header */}
      <header className="h-16 border-b border-slate-800 bg-[#0b101b]/95 backdrop-blur-xl px-4 sm:px-8 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('talent-dashboard')}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
            title="العودة للوحة المعلق"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#FF5500] to-amber-500 flex items-center justify-center text-white shadow-md">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <span className="text-sm font-black text-white">معالج استنساخ «صوتي الذكي»</span>
              <span className="text-[10px] text-slate-400 block -mt-0.5">ElevenLabs Instant Voice Engine</span>
            </div>
          </div>
        </div>

        {/* Progress Bar & Step Tracker */}
        <div className="hidden md:flex items-center gap-2 text-xs">
          {[
            { step: 1, label: 'التعريف' },
            { step: 2, label: 'التحقق من الهوية' },
            { step: 3, label: 'العقد والموافقة' },
            { step: 4, label: 'التسجيل والعينات' },
            { step: 5, label: 'المعاينة والنشر' }
          ].map((s) => (
            <div key={s.step} className="flex items-center gap-1.5">
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  currentStep === s.step
                    ? 'bg-[#FF5500] text-white shadow-md shadow-orange-600/30 ring-2 ring-orange-500/30'
                    : currentStep > s.step
                    ? 'bg-emerald-500 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {currentStep > s.step ? <Check className="w-3.5 h-3.5" /> : s.step}
              </div>
              <span className={`text-[11px] font-bold ${currentStep === s.step ? 'text-white' : 'text-slate-400'}`}>
                {s.label}
              </span>
              {s.step < 5 && <span className="text-slate-700 mr-1">←</span>}
            </div>
          ))}
        </div>

        <button
          onClick={() => onNavigate('talent-dashboard')}
          className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-slate-800 hover:bg-slate-800 transition-colors"
        >
          حفظ وخروج
        </button>
      </header>

      {/* Main Stepper Container */}
      <main className="flex-1 p-4 sm:p-6 lg:p-10 max-w-4xl mx-auto w-full">

        {/* STEP 1: Definition & FAQ */}
        {currentStep === 1 && (
          <div className="bg-[#0e1424] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-xs font-bold mb-3">
                <Sparkles className="w-3.5 h-3.5" />
                <span>الذكاء الاصطناعي الصوتي المرخص</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                ما هو «صوتي الذكي»؟ وكيف يحقق لك دخلاً مستمراً؟
              </h1>
              <p className="text-slate-400 text-sm mt-2 max-w-xl mx-auto">
                تقنية حصرية تمكنك من استنساخ بصمتك الصوتية بجودة سينمائية فائقة، لتوليد التعليق الصوتي لعملائك آلياً دون الحاجة لدخول الاستوديو في كل مشروع.
              </p>
            </div>

            {/* 3 Value Pillars */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 text-right">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-black text-white">تحكّم كامل ومطلق 100%</h4>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  أنت فقط من يقرر متى يُتاح صوتك، ويمكنك إيقافه مؤقتاً بضغطة زر أو سحب الموافقة وفق فترة إشعار تعاقدية.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 text-right">
                <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 flex items-center justify-center mb-3">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-black text-white">أرباح ومحفظة متنامية</h4>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  اربح عائداً يصل حتى 50% من إجمالي مبيعات كل حرف أو كلمة يتم توليدها بصوتك الذكي لحسابات الشركات المشتركة.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 text-right">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-3">
                  <Lock className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-black text-white">حماية تعاقدية وسجل مشفر</h4>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  يُحظر استنساخ صوتك في أي محتوى سياسي أو ديني أو مضلل. وكل عملية توليد تُسجل في سجل تدقيق غير قابل للتعديل.
                </p>
              </div>
            </div>

            {/* FAQ Accordion */}
            <div className="mb-8">
              <h3 className="text-sm font-black text-white mb-3">الأسئلة الشائعة حول صوتك الذكي</h3>
              <div className="space-y-2">
                {[
                  {
                    q: 'هل يمكن استخدام صوتي في أي شيء دون موافقتي؟',
                    a: 'قطعاً لا. يلتزم العقد بحصر الاستخدام في المجالات التسويقية والتعليمية والشركات، وتُحظر السياسة والدين والمحتوى الحساس تماماً بحجب تقني حاسم.'
                  },
                  {
                    q: 'كيف يمكنني سحب موافقتي في المستقبل؟',
                    a: 'يمكنك طلب سحب الموافقة في أي وقت من لوحة التحكم، وتبدأ بعدها فترة إشعار تعاقدية لحماية طلبات العملاء السارية، ثم يُحذف النموذج نهائياً.'
                  },
                  {
                    q: 'من يملك حقوق ملكية صوتي؟',
                    a: 'أنت تملك صوتك وهويتك 100%. ما تمنحه للمنصة هو ترخيص تشغيلي غير حصري ومحدد بالشروط والأغراض المعتمدة فقط.'
                  }
                ].map((item, idx) => (
                  <div key={idx} className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/50">
                    <button
                      type="button"
                      onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                      className="w-full p-4 flex items-center justify-between text-right text-xs font-bold text-white hover:bg-slate-800/50 transition-colors"
                    >
                      <span>{item.q}</span>
                      {openFaq === idx ? <ChevronUp className="w-4 h-4 text-orange-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                    </button>
                    {openFaq === idx && (
                      <div className="p-4 pt-0 text-xs text-slate-300 leading-relaxed border-t border-slate-800/60 bg-slate-900/80">
                        {item.a}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Navigation */}
            <div className="flex justify-end">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-[#FF5500] to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black text-sm shadow-lg shadow-orange-600/30 transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>ابدأ الآن</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: KYC & Identity Verification */}
        {currentStep === 2 && (
          <div className="bg-[#0e1424] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
            <div className="text-center mb-8">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/10 border border-orange-500/30 text-orange-400 flex items-center justify-center mx-auto mb-3">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">التحقق من الهوية والأهلية القانونية</h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-1.5 max-w-lg mx-auto">
                لحماية بصمتك الصوتية وضمان عدم انتحال الشخصيات، تتطلب أنظمة قيمة فويس مطابقة الهوية الوطنية الرسمية مع صورة سيلفي حية.
              </p>
            </div>

            {/* Status Chip */}
            <div className="flex justify-center mb-6">
              <div className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold border ${
                kycStatus === 'approved' 
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : kycStatus === 'pending'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                  : 'bg-slate-800 border-slate-700 text-slate-300'
              }`}>
                <span className={`w-2 h-2 rounded-full ${kycStatus === 'approved' ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                <span>
                  {kycStatus === 'approved' && 'الهوية معتمدة ومقبولة ✓'}
                  {kycStatus === 'pending' && 'قيد المراجعة الفورية ⏳'}
                  {kycStatus === 'none' && 'مطلوب إرفاق المستندات'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {/* National ID Front */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 text-center">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-orange-400 flex items-center justify-center mx-auto mb-3">
                  <FileText className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-black text-white">صورة الهوية الوطنية / الإقامة (الوجه الأمامي)</h4>
                <p className="text-[11px] text-slate-400 mt-1 mb-3">
                  صورة واضحة تظهر الاسم والرقم وتاريخ الانتهاء
                </p>
                <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center justify-between text-xs">
                  <span className="font-mono text-slate-300 truncate">{idPhotoName}</span>
                  <span className="text-emerald-400 font-bold text-[10px]">مرفق ✓</span>
                </div>
              </div>

              {/* Live Selfie */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 text-center">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-orange-400 flex items-center justify-center mx-auto mb-3">
                  <Camera className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-black text-white">صورة سيلفي حية للتحقق</h4>
                <p className="text-[11px] text-slate-400 mt-1 mb-3">
                  التقط صورة واضحة لملامح الوجه بدون نظارات شمسية
                </p>
                <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center justify-between text-xs">
                  <span className="font-mono text-slate-300 truncate">{selfiePhotoName}</span>
                  <span className="text-emerald-400 font-bold text-[10px]">مرفق ✓</span>
                </div>
              </div>
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={() => setCurrentStep(1)}
                className="px-5 py-2.5 rounded-xl border border-slate-700 text-xs font-bold text-slate-300 hover:bg-slate-800 transition-colors"
              >
                السابق
              </button>
              <button
                onClick={handleApproveKyc}
                disabled={isSubmittingKyc}
                className="px-8 py-3.5 rounded-2xl bg-[#FF5500] hover:bg-orange-600 text-white font-bold text-xs shadow-lg shadow-orange-600/30 transition-all cursor-pointer flex items-center gap-2"
              >
                {isSubmittingKyc ? 'جاري التحقق...' : 'تأكيد الهوية والمتابعة'}
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Contract & Consent */}
        {currentStep === 3 && (
          <div className="bg-[#0e1424] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
            <div className="text-center mb-6">
              <h2 className="text-xl sm:text-2xl font-black text-white">العقد الرقمي والموافقة المسبقة</h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-1">
                حدد مجالات الاستخدام المصرح بها وفترة الإشعار، ووقّع رقمياً على شروط الاستنساخ
              </p>
            </div>

            {/* Allowed Use Cases */}
            <div className="mb-6">
              <label className="block text-xs font-black text-slate-200 mb-2">
                1. مجالات الاستخدام المصرح بها (اختر ما يناسبك):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {ALL_ALLOWED_USE_CASES.map(item => {
                  const isChecked = allowedCases.includes(item.id);
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        if (isChecked) {
                          setAllowedCases(allowedCases.filter(c => c !== item.id));
                        } else {
                          setAllowedCases([...allowedCases, item.id]);
                        }
                      }}
                      className={`p-3 rounded-xl border text-xs font-bold transition-all text-right flex items-center justify-between cursor-pointer ${
                        isChecked
                          ? 'bg-orange-500/10 border-[#FF5500] text-white'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-850'
                      }`}
                    >
                      <span>{item.label}</span>
                      <span className={`w-4 h-4 rounded-md flex items-center justify-center text-[10px] ${
                        isChecked ? 'bg-[#FF5500] text-white' : 'border border-slate-700'
                      }`}>
                        {isChecked && '✓'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Blocked Use Cases (Always Locked) */}
            <div className="mb-6 p-4 rounded-2xl bg-rose-500/5 border border-rose-500/20">
              <div className="flex items-center gap-2 text-rose-400 text-xs font-black mb-2">
                <Lock className="w-4 h-4" />
                <span>مجالات محظورة تماماً بنص العقد وتقنيات المنصة (مقفلة):</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {BLOCKED_USE_CASES.map((b, i) => (
                  <span key={i} className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/20 flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    <span>{b}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Notice Period Selector (4 Cards) */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-black text-slate-200">
                  2. حدد فترة الإشعار التعاقدية (Notice Period):
                </label>
                <span className="text-[11px] text-slate-400">تحدد نسبة أرباحك التلقائية</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { days: 30 as const, label: '30 يوم', pct: '25%', badge: undefined },
                  { days: 180 as const, label: '6 أشهر', pct: '35%', badge: undefined },
                  { days: 365 as const, label: 'سنة كاملة', pct: '45%', badge: undefined },
                  { days: 730 as const, label: 'سنتان', pct: '50%', badge: 'الأعلى عائدًا 🌟' }
                ].map(item => {
                  const isSelected = noticePeriod === item.days;
                  return (
                    <div
                      key={item.days}
                      onClick={() => setNoticePeriod(item.days)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative text-center ${
                        isSelected
                          ? 'bg-gradient-to-b from-orange-500/20 to-orange-500/5 border-[#FF5500] ring-1 ring-[#FF5500]'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {item.badge && (
                        <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-2 py-0.2 rounded-full text-[9px] font-black bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 shadow-sm whitespace-nowrap">
                          {item.badge}
                        </span>
                      )}
                      <div className="text-sm font-black text-white">{item.label}</div>
                      <div className="text-lg font-mono font-black text-orange-400 mt-0.5">{item.pct}</div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">نسبتك من الإيرادات</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Scrollable Contract Box */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-black text-slate-200">
                  3. بنود اتفاقية ترخيص البصمة الصوتية (مرر للأسفل للموافقة):
                </label>
                <span className={`text-[11px] font-bold ${hasScrolledToContractBottom ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {hasScrolledToContractBottom ? 'تم الاطلاع على كامل العقد ✓' : 'يرجى التمرير لأسفل الصندوق ↓'}
                </span>
              </div>

              <div
                ref={contractScrollRef}
                onScroll={handleContractScroll}
                className="h-44 overflow-y-auto p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300 leading-relaxed space-y-3 font-sans"
              >
                <div className="font-bold text-white border-b border-slate-800 pb-2">
                  عقد ترخيص تشغيل البصمة الصوتية الذكية عبر منصة قيمة فويس (Qeema Voice Engine v1.2.0)
                </div>
                <p>
                  <strong>الطرف الأول:</strong> منصة قيمة فويس (شركة قيمة لحلول الذكاء الاصطناعي الصوتي).<br />
                  <strong>الطرف الثاني:</strong> المعلق الصوتي الموقّع أدناه بصفتها/بصفته المالك الحصري للنبرة والأداء.
                </p>
                <p>
                  <strong>المادة الأولى — نطاق الترخيص:</strong> يمنح الطرف الثاني الطرف الأول ترخيصاً محدوداً لتوليد مخرجات صوتية اصطناعية مستنسخة استناداً إلى النماذج العصبية المعتمدة (ElevenLabs API) بغرض تسويقها للشركات والجهات المتعاقدة في المجالات المصرح بها حصراً.
                </p>
                <p>
                  <strong>المادة الثانية — الحظر المطلق:</strong> يحظر استخدام الصوت في أي مواد سياسية، أو طائفية دينية، أو خادشة للحياء، أو مضللة للمستهلك، وتتحمل المنصة والعميل المسؤولية القانونية الكاملة عن أي خرق.
                </p>
                <p>
                  <strong>المادة الثالثة — توزيع الإيرادات وسحب الموافقة:</strong> يستحق الطرف الثاني نسبة ({getRevShare(noticePeriod)}%) من إجمالي المبيعات، ويحق له سحب الموافقة مع الالتزام بفترة إشعار مدتها ({noticePeriod} يوماً) لتمكين إتمام التزامات العملاء المشتركين.
                </p>
                <p className="text-[11px] text-slate-400 italic">
                  [CONTRACT_TEXT_TBD — توثيق رسمي مشفر يخضع للأنظمة التجارية والملكية الفكرية في المملكة العربية السعودية]
                </p>
                <div className="pt-2 text-center text-emerald-400 font-bold text-[11px]">
                  --- نهاية نصوص العقد الرسمي ---
                </div>
              </div>
            </div>

            {/* Signature & Agreement */}
            <div className="space-y-3 mb-6 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  الاسم الكامل للتوقيع الإلكتروني (مطابق للهوية):
                </label>
                <input
                  type="text"
                  value={signatureName}
                  onChange={(e) => setSignatureName(e.target.value)}
                  placeholder="اكتب اسمك الثلاثي للتوقيع"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none focus:border-orange-500"
                />
              </div>

              <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={consentAgreementChecked}
                  onChange={(e) => setConsentAgreementChecked(e.target.checked)}
                  className="mt-0.5 rounded border-slate-700 text-orange-500 focus:ring-0"
                />
                <span className="text-xs text-slate-300">
                  أقر بأنني صاحب هذا الصوت وأوافق على استنساخه وفق هذه الشروط ونسبة العائد المختارة ({getRevShare(noticePeriod)}%).
                </span>
              </label>
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-5 py-2.5 rounded-xl border border-slate-700 text-xs font-bold text-slate-300 hover:bg-slate-800"
              >
                السابق
              </button>
              <button
                onClick={handleSignContract}
                disabled={!hasScrolledToContractBottom || !signatureName || !consentAgreementChecked || isSigningContract}
                className="px-8 py-3.5 rounded-2xl bg-[#FF5500] hover:bg-orange-600 disabled:opacity-40 text-white font-bold text-xs shadow-lg shadow-orange-600/30 transition-all cursor-pointer flex items-center gap-2"
              >
                {isSigningContract ? 'جاري توثيق العقد...' : 'أوافق وأوقّع العقد'}
                <Check className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Recording & Quality Analysis */}
        {currentStep === 4 && (
          <div className="bg-[#0e1424] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
            <div className="text-center mb-6">
              <h2 className="text-xl sm:text-2xl font-black text-white">تسجيل الموافقة الصوتية والعينات التدريبية</h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-1">
                جملة الإقرار الشفهية + تسجيل النص القياسي للهجة المطلوبة
              </p>
            </div>

            {/* Part 1: Consent Spoken Sentence */}
            <div className="mb-6 p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-orange-400 flex items-center gap-1.5">
                  <Mic className="w-4 h-4" />
                  <span>الجزء 1 — تسجيل جملة الموافقة الشفهية الإلزامية</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">الحد الأقصى: 15 ثانية</span>
              </div>

              {/* Dynamic Spoken Sentence Card */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-sm font-medium leading-relaxed my-3 text-center">
                «أنا <span className="text-orange-400 font-black">{narrator?.displayName || 'المعلق الصوتي'}</span>، أوافق على استنساخ صوتي لدى قيمة فويس، اليوم <span className="font-mono text-amber-400">{new Date().toISOString().split('T')[0]}</span>، والرمز <span className="font-mono text-emerald-400 font-black tracking-widest">{consentRandomCode}</span>.»
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleRecordConsent}
                    className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 cursor-pointer transition-all ${
                      isRecordingConsent 
                        ? 'bg-rose-600 text-white animate-pulse'
                        : consentAudioRecorded
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#FF5500] hover:bg-orange-600 text-white'
                    }`}
                  >
                    {isRecordingConsent ? (
                      <>
                        <Square className="w-4 h-4" />
                        <span>إيقاف التسجيل ({consentAudioTimer} ثانية)</span>
                      </>
                    ) : consentAudioRecorded ? (
                      <>
                        <RotateCcw className="w-4 h-4" />
                        <span>إعادة التسجيل (تم الحفظ ✓)</span>
                      </>
                    ) : (
                      <>
                        <Mic className="w-4 h-4" />
                        <span>بدء تسجيل جملة الموافقة</span>
                      </>
                    )}
                  </button>

                  {consentAudioRecorded && (
                    <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>تم تسجيل جملة الموافقة ومطابقتها قانونياً</span>
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Part 2: Voice Samples Script */}
            <div className="mb-6 p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-black text-white flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-[#FF5500]" />
                  <span>الجزء 2 — تسجيل عينة البصمة الصوتية (1 - 3 دقائق)</span>
                </span>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedDialect}
                    onChange={(e) => setSelectedDialect(e.target.value)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs outline-none"
                  >
                    <option value="سعودي نجدي">سعودي نجدي</option>
                    <option value="فصحى معاصرة">فصحى معاصرة</option>
                    <option value="سعودي حجازي">سعودي حجازي</option>
                    <option value="مصري تسويقي">مصري تسويقي</option>
                  </select>

                  {/* Mode toggle */}
                  <div className="flex rounded-lg bg-slate-800 p-0.5 border border-slate-700 text-[11px] font-bold">
                    <button
                      onClick={() => setRecordingMode('mic')}
                      className={`px-2.5 py-1 rounded-md transition-all ${recordingMode === 'mic' ? 'bg-[#FF5500] text-white' : 'text-slate-400'}`}
                    >
                      تسجيل بالمتصفح
                    </button>
                    <button
                      onClick={() => setRecordingMode('upload')}
                      className={`px-2.5 py-1 rounded-md transition-all ${recordingMode === 'upload' ? 'bg-[#FF5500] text-white' : 'text-slate-400'}`}
                    >
                      رفع ملف صوتي
                    </button>
                  </div>
                </div>
              </div>

              {/* Standard Dialect Script */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-loose max-h-36 overflow-y-auto mb-4">
                <div className="font-bold text-orange-400 mb-1">
                  نص التدريب القياسي (SCRIPT_{selectedDialect.replace(' ', '_')}_TBD):
                </div>
                «تعتبر المملكة العربية السعودية اليوم وجهة عالمية للاستثمار والابتكار التقني. من مشاريع نيوم والبحر الأحمر إلى التحول الرقمي الشامل، نرى رؤية 2030 تتحقق في كل قطاع. تلتزم منصة Qeema Voice بأعلى معايير الدقة الصوتية والنبرة الرخيمة المتوازنة. في عالم الأعمال الحديث، الصوت هو الهوية الأولى للمنشأة، وهو الجسر الذي يبني الثقة بين العلامة التجارية وجمهورها. الأرقام تتحدث: 120 مليون مستخدم، وأكثر من 45 مليار ريال من الاستثمارات في البنية التحتية السحابية.»
              </div>

              {recordingMode === 'mic' ? (
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                  <div className="h-10 flex items-center justify-center gap-1 mb-2">
                    {Array.from({ length: 24 }).map((_, i) => (
                      <span
                        key={i}
                        className={`w-1 rounded-full transition-all duration-150 ${
                          isRecordingSample 
                            ? 'bg-[#FF5500] animate-pulse'
                            : 'bg-slate-700 h-3'
                        }`}
                        style={{
                          height: isRecordingSample ? `${Math.max(6, Math.sin(i * 0.5) * 28 + 12)}px` : undefined
                        }}
                      />
                    ))}
                  </div>

                  <div className="flex items-center justify-center gap-4">
                    <button
                      onClick={() => setIsRecordingSample(!isRecordingSample)}
                      className={`px-6 py-2.5 rounded-xl font-black text-xs flex items-center gap-2 cursor-pointer shadow-md ${
                        isRecordingSample ? 'bg-rose-600 text-white' : 'bg-[#FF5500] text-white'
                      }`}
                    >
                      {isRecordingSample ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                      <span>{isRecordingSample ? `إيقاف وحفظ العينة (${sampleDuration} ثانية)` : 'تسجيل النص القياسي'}</span>
                    </button>
                    <span className="text-xs text-slate-400 font-mono">المدة: {sampleDuration} ثانية</span>
                  </div>
                </div>
              ) : (
                <div className="p-6 bg-slate-950 rounded-xl border border-dashed border-slate-700 text-center">
                  <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-xs text-slate-300 font-bold mb-1">
                    اسحب وأفلت ملف التسجيل (WAV أو MP3) هنا، أو تصفح جهازك
                  </p>
                  <p className="text-[10px] text-slate-500 mb-3">
                    الحد الأقصى للملف: 50MB — يجب أن لا تقل مدة التسجيل عن 60 ثانية
                  </p>
                  <label className="inline-flex px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold cursor-pointer transition-colors">
                    <span>اختيار ملف من الجهاز</span>
                    <input 
                      type="file" 
                      accept="audio/*" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) setUploadedFileName(file.name);
                      }} 
                    />
                  </label>
                  {uploadedFileName && (
                    <div className="mt-2 text-xs text-emerald-400 font-mono">
                      تم اختيار الملف: {uploadedFileName} (78 ثانية / HQ WAV)
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Automatic Quality Check Section */}
            <div className="mb-6 p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-white flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                  <span>الفحص الآلي لجودة العينة الصوتية:</span>
                </span>
                <span className="text-[10px] font-bold text-emerald-400">جاهز للمعالجة</span>
              </div>

              <div className="flex flex-wrap gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-bold">
                  <Check className="w-3.5 h-3.5" />
                  <span>المدة كافية ({sampleDuration} ثانية)</span>
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-bold">
                  <Check className="w-3.5 h-3.5" />
                  <span>الصوت نقي تماماً بدون أي تشويش</span>
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-bold">
                  <Check className="w-3.5 h-3.5" />
                  <span>عزل الضجيج ممتاز بجودة استوديو</span>
                </span>
              </div>
            </div>

            {/* Recording Tips Panel */}
            <div className="mb-6 p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/20 text-xs text-amber-200/90 leading-relaxed">
              <strong>نصائح التسجيل الاحترافي:</strong> اختر غرفة معزولة هادئة، حافظ على مسافة 15 سم ثابتة من الميكروفون، وتحدث بالنبرة الطبيعية المعتادة التي ترغب في بيعها للعملاء، بدون إضافة موسيقى خلفية.
            </div>

            {/* Processing modal/banner if active */}
            {isProcessingModel && (
              <div className="mb-6 p-6 rounded-2xl bg-slate-900 border border-orange-500/40 text-center animate-pulse">
                <div className="w-12 h-12 rounded-2xl bg-[#FF5500]/20 text-[#FF5500] flex items-center justify-center mx-auto mb-3">
                  <Sparkles className="w-6 h-6 animate-spin" />
                </div>
                <h4 className="text-base font-black text-white">نجهّز صوتك الذكي عبر المحرك العصبي المتطور…</h4>
                <p className="text-xs text-slate-400 mt-1 mb-4">
                  جاري تحليل الرنين وتدريب النموذج العصبي عالي الدقة (قد يستغرق حتى دقيقتين)
                </p>
                <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-[#FF5500] to-amber-500 h-2.5 transition-all duration-300"
                    style={{ width: `${processingProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={() => setCurrentStep(3)}
                className="px-5 py-2.5 rounded-xl border border-slate-700 text-xs font-bold text-slate-300 hover:bg-slate-800"
              >
                السابق
              </button>
              <button
                onClick={handleSubmitCloning}
                disabled={!consentAudioRecorded || isProcessingModel}
                className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-[#FF5500] to-orange-600 hover:from-orange-600 hover:to-orange-700 disabled:opacity-40 text-white font-black text-xs shadow-lg shadow-orange-600/30 transition-all cursor-pointer flex items-center gap-2"
              >
                <span>إرسال للمعالجة وتوليد المعاينة</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Previews & Approval to Publish */}
        {currentStep === 5 && (
          <div className="bg-[#0e1424] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
            <div className="text-center mb-8">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">معاينة الصوت المستنسخ واعتماد النشر</h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-1.5 max-w-xl mx-auto">
                قام النظام بتوليد 5 عينات تجريبية لصوتك في مجالات مختلفة. استمع إليها للتأكد من جودة النبرة قبل النشر الرسمي في مكتبة الأصوات.
              </p>
            </div>

            {/* 5 Preview Cards */}
            <div className="space-y-3 mb-8">
              {PREVIEW_CASES.map((item, idx) => {
                const isPlaying = playingPreviewIdx === idx;
                return (
                  <div
                    key={idx}
                    className={`p-4 rounded-2xl border transition-all ${
                      isPlaying 
                        ? 'bg-slate-900 border-[#FF5500] shadow-md shadow-orange-600/10'
                        : 'bg-slate-900/70 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setPlayingPreviewIdx(isPlaying ? null : idx)}
                          className="w-10 h-10 rounded-xl bg-[#FF5500] hover:bg-orange-600 text-white flex items-center justify-center shadow-md cursor-pointer transition-transform active:scale-95 shrink-0"
                        >
                          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white mr-0.5" />}
                        </button>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black text-white">{item.title}</span>
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-orange-400 border border-slate-700">
                              {item.category}
                            </span>
                          </div>
                          <span className="text-[11px] font-mono text-slate-400">{item.duration} / AI Synthesized</span>
                        </div>
                      </div>

                      {/* Mini Waveform visualization */}
                      <div className="hidden sm:flex items-center gap-0.5 h-6">
                        {Array.from({ length: 16 }).map((_, i) => (
                          <span
                            key={i}
                            className={`w-0.5 rounded-full transition-all ${
                              isPlaying ? 'bg-orange-400 animate-pulse' : 'bg-slate-700 h-2'
                            }`}
                            style={{
                              height: isPlaying ? `${Math.sin((i + idx) * 0.8) * 14 + 6}px` : undefined
                            }}
                          />
                        ))}
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 mt-3 pt-3 border-t border-slate-800 leading-relaxed font-sans">
                      «{item.text}»
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStep(4)}
                className="px-5 py-2.5 rounded-xl border border-slate-700 text-xs font-bold text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                أعد المحاولة (تسجيل عينة أخرى)
              </button>

              <button
                type="button"
                onClick={handlePublishVoice}
                disabled={isPublishingVoice}
                className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-sm shadow-lg shadow-emerald-600/30 transition-all cursor-pointer flex items-center gap-2"
              >
                {isPublishingVoice ? 'جاري الاعتماد والنشر...' : 'أوافق على النشر في المنصة ✓'}
              </button>
            </div>
          </div>
        )}

      </main>
    </div>
  );
};
