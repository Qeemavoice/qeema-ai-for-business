import React from 'react';
import { 
  Home, 
  Mic2, 
  Sliders, 
  GitFork, 
  LayoutTemplate, 
  FileAudio, 
  Volume2, 
  Users2, 
  Sparkles, 
  ShieldCheck, 
  Globe2, 
  Code2, 
  CreditCard, 
  UserPlus, 
  ChevronDown, 
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Layers,
  Bot
} from 'lucide-react';
import { Company, User } from '../../types';

export type DashboardNavKey = 
  | 'home' 
  | 'voices' 
  | 'studio' 
  | 'flows' 
  | 'projects' 
  | 'assets' 
  | 'human-bookings' 
  | 'voice-twins' 
  | 'compliance' 
  | 'developers' 
  | 'team' 
  | 'billing';

interface DashboardSidebarProps {
  activeNav: DashboardNavKey;
  onSelectNav: (key: DashboardNavKey) => void;
  currentCompany: Company | null;
  currentUser: User | null;
  availableCompanies: Company[];
  onSwitchCompany: (id: string) => void;
  balanceCredits: number;
  onOpenTopUp: () => void;
  onOpenInvite: () => void;
  onOpenAssistant?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const DashboardSidebar: React.FC<DashboardSidebarProps> = ({
  activeNav,
  onSelectNav,
  currentCompany,
  currentUser,
  availableCompanies,
  onSwitchCompany,
  balanceCredits,
  onOpenTopUp,
  onOpenInvite,
  onOpenAssistant,
  isCollapsed = false,
  onToggleCollapse
}) => {
  const [isCompanyMenuOpen, setIsCompanyMenuOpen] = React.useState(false);

  const mainNavItems = [
    { key: 'home' as DashboardNavKey, label: 'الرئيسية', icon: Home, badge: undefined },
    { key: 'voices' as DashboardNavKey, label: 'مكتبة الأصوات', icon: Mic2, badge: 'جديد' },
    { key: 'studio' as DashboardNavKey, label: 'استوديو التوليد', icon: Sliders, badge: 'v3' },
    { key: 'flows' as DashboardNavKey, label: 'التدفقات وسير العمل', icon: GitFork, badge: undefined },
    { key: 'projects' as DashboardNavKey, label: 'المشاريع والقوالب', icon: LayoutTemplate, badge: undefined },
    { key: 'assets' as DashboardNavKey, label: 'أصولي والتراخيص', icon: FileAudio, badge: undefined },
  ];

  const pinnedTools = [
    { key: 'studio' as DashboardNavKey, label: 'تحويل النص لصوت (TTS)', icon: Volume2 },
    { key: 'human-bookings' as DashboardNavKey, label: 'حجز المعلقين البشريين', icon: Users2 },
    { key: 'voice-twins' as DashboardNavKey, label: 'استنساخ الصوت والتوأم', icon: Sparkles },
    { key: 'compliance' as DashboardNavKey, label: 'التراخيص والامتثال', icon: ShieldCheck },
    { key: 'developers' as DashboardNavKey, label: 'المطورين و API', icon: Code2 },
  ];

  return (
    <aside 
      className={`relative h-full flex flex-col bg-white border-l border-slate-200/80 select-none transition-all duration-300 z-30 shrink-0 ${
        isCollapsed ? 'w-18' : 'w-64'
      }`}
      style={{ direction: 'rtl' }}
    >
      {/* 1. Workspace Header / Switcher */}
      <div className="p-3.5 border-b border-slate-100 relative">
        <button
          onClick={() => setIsCompanyMenuOpen(!isCompanyMenuOpen)}
          className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200/80 group text-right"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-xs group-hover:scale-105 transition-transform">
              <span className="text-[#FF5500]">Q</span>
            </div>
            {!isCollapsed && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs font-bold text-slate-900 truncate">
                    {currentCompany?.name || 'وكالة الأفق الإبداعية'}
                  </h3>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-orange-50 text-[#FF5500] border border-orange-200/60 shrink-0">
                    {currentCompany?.plan || 'Growth'}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 truncate">مساحة عمل B2B معتمدة</p>
              </div>
            )}
          </div>
          {!isCollapsed && <ChevronDown className="w-4 h-4 text-slate-400 shrink-0 group-hover:text-slate-600 transition-colors" />}
        </button>

        {/* Company Dropdown Menu */}
        {isCompanyMenuOpen && !isCollapsed && (
          <div className="absolute top-full right-3.5 left-3.5 mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl p-1.5 z-50 animate-fade-in space-y-1">
            <div className="px-2.5 py-1.5 text-[10px] font-bold text-slate-400">تبديل مساحة العمل</div>
            {availableCompanies.map((comp) => (
              <button
                key={comp.id}
                onClick={() => {
                  onSwitchCompany(comp.id);
                  setIsCompanyMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-semibold transition-colors text-right ${
                  currentCompany?.id === comp.id
                    ? 'bg-orange-50 text-[#FF5500] font-bold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="truncate">{comp.name}</div>
                <span className="text-[10px] text-slate-400">{comp.plan}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 2. Scrollable Navigation List */}
      <div className="flex-1 overflow-y-auto px-2.5 py-3 space-y-5 custom-scrollbar">
        {/* Main Section */}
        <div className="space-y-0.5">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.key;
            return (
              <button
                key={item.key}
                onClick={() => onSelectNav(item.key)}
                title={item.label}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all group text-right ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Icon className={`w-4 h-4 shrink-0 transition-transform ${isActive ? 'text-[#FF5500]' : 'text-slate-400 group-hover:text-slate-700'}`} />
                  {!isCollapsed && <span className="truncate">{item.label}</span>}
                </div>
                {!isCollapsed && item.badge && (
                  <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                    isActive ? 'bg-[#FF5500] text-white' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Pinned Tools Section */}
        <div>
          {!isCollapsed && (
            <div className="px-3 mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              الأدوات المثبتة
            </div>
          )}
          <div className="space-y-0.5">
            {pinnedTools.map((tool) => {
              const Icon = tool.icon;
              const isActive = activeNav === tool.key;
              return (
                <button
                  key={tool.key}
                  onClick={() => onSelectNav(tool.key)}
                  title={tool.label}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.8 rounded-xl text-xs font-medium transition-all group text-right ${
                    isActive
                      ? 'bg-orange-50 text-[#FF5500] font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-[#FF5500]' : 'text-slate-400 group-hover:text-slate-600'}`} />
                  {!isCollapsed && <span className="truncate">{tool.label}</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Bottom Workspace Controls */}
      <div className="p-3 border-t border-slate-100 space-y-2.5 bg-slate-50/50">
        {/* Invite Team Card */}
        {!isCollapsed && (
          <div className="p-2.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                <UserPlus className="w-3.5 h-3.5 text-[#FF5500]" />
                <span>فريق العمل</span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium">4 أعضاء</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-tight">
              شارك الأصوات والإنتاج الصوتي مع زملائك بالوكالة
            </p>
            <button
              onClick={onOpenInvite}
              className="w-full py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-[11px] font-bold transition-colors text-center"
            >
              + دعوة عضو جديد
            </button>
          </div>
        )}

        {/* Upgrade / Credits Bar */}
        <div className="p-2.5 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 text-white shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <div className="text-[11px] font-bold flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-[#FF5500]" />
              {!isCollapsed && <span>رصيد المنشأة</span>}
            </div>
            <span className="text-xs font-black text-white">{balanceCredits.toLocaleString()}</span>
          </div>
          {!isCollapsed && (
            <div className="space-y-2">
              <div className="w-full bg-slate-700/60 h-1.5 rounded-full overflow-hidden">
                <div className="bg-gradient-to-r from-[#FF5500] to-amber-400 h-full w-3/4 rounded-full" />
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={onOpenTopUp}
                  className="flex-1 py-1.5 bg-[#FF5500] hover:bg-[#e04b00] text-white text-[10px] font-bold rounded-lg transition-all text-center"
                >
                  شحن رصيد
                </button>
                <button
                  onClick={() => onSelectNav('billing')}
                  className="px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold rounded-lg transition-all"
                >
                  الباقات
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Mini Bar */}
        <div className="flex items-center justify-between p-1.5 rounded-xl hover:bg-white transition-colors">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-7 h-7 rounded-full bg-orange-100 text-[#FF5500] font-bold text-xs flex items-center justify-center shrink-0 border border-orange-200">
              {currentUser?.name?.charAt(0) || 'أ'}
            </div>
            {!isCollapsed && (
              <div className="min-w-0 text-right">
                <div className="text-xs font-bold text-slate-900 truncate">
                  {currentUser?.name || 'أحمد العتيبي'}
                </div>
                <div className="text-[10px] text-slate-400 truncate">
                  {currentUser?.email || 'a.otaibi@horizon.sa'}
                </div>
              </div>
            )}
          </div>

          {!isCollapsed && (
            <button
              onClick={() => onSelectNav('team')}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-all"
              title="إعدادات الحساب"
            >
              <Users2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </aside>
  );
};
