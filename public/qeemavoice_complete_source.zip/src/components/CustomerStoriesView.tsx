import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  ArrowLeft, 
  ArrowRight, 
  Building2, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  Share2, 
  ChevronLeft, 
  ChevronRight,
  Headphones,
  ExternalLink,
  MessageSquareQuote,
  Filter,
  Layers,
  Radio,
  BookOpen,
  Phone,
  Film
} from 'lucide-react';
import { ActiveView } from '../types';

export interface Story {
  id: string;
  brand: string;
  brandEn: string;
  brandColor: string;
  voiceCategory: string; // تصنيف التعليق الصوتي
  industry: string;      // مجال الشركة (العميل)
  title: string;
  titleEn: string;
  date: string;
  audioDuration: string;
  audioDurationSecs: number;
  heroSubtitle: string;
  stats: {
    label: string;
    value: string;
  }[];
  paragraphs: string[];
  quote: {
    text: string;
    author: string;
    role: string;
  };
  highlights: string[];
  similarTag: string;
  imageAccent: string;
}

const VOICE_CATEGORIES = [
  'الكل',
  'رد آلي ومراكز اتصال IVR',
  'إعلانات تجارية وسوشيال ميديا',
  'وثائقي ورسمي',
  'كتب صوتية وبودكاست',
  'دوبلاج وتمثيل صوتي'
];

const INDUSTRIES = [
  'الكل',
  'التجارة الإلكترونية واللوجستيات',
  'الإعلام والبث والترفيه',
  'القطاع المالي والمصرفي (FinTech)',
  'الطيران والنقل والسياحة',
  'الاتصالات والتقنية',
  'النشر والتعليم الرقمي',
  'العقارات والضيافة'
];

const STORIES: Story[] = [
  {
    id: 'jahez',
    brand: 'جاهز',
    brandEn: 'Jahez',
    brandColor: '#FF5500',
    voiceCategory: 'رد آلي ومراكز اتصال IVR',
    industry: 'التجارة الإلكترونية واللوجستيات',
    title: 'جاهز يقدّم لأكثر من 15 مليون مستخدم ردوداً صوتية فورية طبيعية عبر مراكز الاتصال وخطوط التوصيل السريع',
    titleEn: 'Jahez gives over 15 million shoppers instant answers on delivery hotlines',
    date: '7 سبتمبر 2026',
    audioDuration: '2:01',
    audioDurationSecs: 121,
    heroSubtitle: 'كيف ساهمت البنية التحتية للصوت العربي في تقليل زمن انتظار العملاء بنسبة 85% وزيادة دقة فهم اللهجة السعودية إلى 99.4%',
    stats: [
      { label: 'مستخدم نشط يستفيد من الخدمة', value: '+15M' },
      { label: 'انخفاض في زمن معالجة المكالمة', value: '85%' },
      { label: 'دقة النطق وفهم اللهجات', value: '99.4%' },
      { label: 'زمن الاستجابة اللحظي', value: '<250ms' }
    ],
    paragraphs: [
      'تعتمد منصة "جاهز"، الرائدة في قطاع توصيل الطلبات والتجارة السريعة في المملكة العربية السعودية والخليج العربي، على الجيل الجديد من الوكلاء الصوتيين الذكيين المدعومين بالبنية التحتية لـ Qeema Voice عبر خطوط دعم العملاء وخدمة ما بعد الطلب.',
      'يتعامل الوكيل الصوتي مع استفسارات التوصيل المتكررة وحالات الطلب فورياً وبنبرة سعودية وخليجية طبيعية دافئة على مدار 24 ساعة، مع تحويل سلس لموظفي خدمة العملاء عند الحاجة.'
    ],
    quote: {
      text: 'القدرة على توفير رد صوتي سعودي طبيعي يفهم عملاءنا لحظياً دون أي رتابة آلية نقلت تجربة مستخدمي جاهز إلى مستوى غير مسبوق في قطاع الخدمات اللوجستية.',
      author: 'م. راشد القحطاني',
      role: 'رئيس قطاع تجربة العملاء والتقنية في جاهز'
    },
    highlights: [
      'استجابة صوتية فورية بأقل من 250 ميلي ثانية',
      'فهم كامل للهجات السعودية والخليجية والمصطلحات المحلية',
      'تكامل لحظي مع أنظمة التتبع اللوجستي وأنظمة CRM'
    ],
    similarTag: 'منظومة جاهز الدولية',
    imageAccent: 'from-orange-500/20 via-amber-500/10 to-transparent'
  },
  {
    id: 'mbc-shahid',
    brand: 'مجموعة MBC وشاهد',
    brandEn: 'MBC Group & Shahid',
    brandColor: '#7C3AED',
    voiceCategory: 'دوبلاج وتمثيل صوتي',
    industry: 'الإعلام والبث والترفيه',
    title: 'مجموعة MBC تنتج أكثر من 1,000 ساعة من الوثائقيات والبودكاست بـ 15 لهجة عربية موثقة',
    titleEn: 'MBC Group produces 1,000+ hours of documentaries with authenticated Arabic voices',
    date: '3 سبتمبر 2026',
    audioDuration: '2:45',
    audioDurationSecs: 165,
    heroSubtitle: 'الجمع بين نخبة المعلقين الصوتيين البشريين وتقنية التوأمة الصوتية Voice Twin لإنتاج وتوطين المحتوى الدرامي والإخباري',
    stats: [
      { label: 'ساعة محتوى صوتي منتجة', value: '+1,000h' },
      { label: 'لهجة عربية معتمدة', value: '15 لهجة' },
      { label: 'توفير في وقت الإنتاج والمونتاج', value: '70%' },
      { label: 'معلقين بشريين موثقين', value: '+300' }
    ],
    paragraphs: [
      'تستخدم شبكة MBC ومنصة "شاهد" الرائدة منصة Qeema Voice لربط فرق الإنتاج التلفزيوني والوثائقيات بأكبر شبكة من المعلقين الصوتيين العرب المعتمدين، مع الاستفادة من أدوات الذكاء الاصطناعي في إعداد المسودات ومطابقة طبقات الصوت بدقة متناهية.',
      'مكّنت المنصة فريق البودكاست والبرامج الوثائقية من استكشاف الخامات الصوتية حسب نبرة المحتوى (وثائقي فخم، حواري سريع، إعلاني مؤثر) وحجز الأصوات المرخصة بحقوق تجارية كاملة وتسليم فوري خلال أقل من 24 ساعة.'
    ],
    quote: {
      text: 'وجدت فرق الإنتاج لدينا في Qeema Voice المعيار الذهبي للصوت العربي؛ دقة مخارج الحروف وفخامة النبرة وتكامل الأدوات الذكية مع المواهب الحقيقية.',
      author: 'طارق الإبراهيم',
      role: 'مدير المحتوى الرقمي والإنتاج الصوتي'
    },
    highlights: [
      'تراخيص بث وتوزيع رقمي وتجاري شاملة لكافة المشاريع',
      'دقة استوديو احترافية 48kHz بمعايير البث التلفزيوني',
      'إشراف إخراجي متكامل لمزامنة الشفاه في الدوبلاج'
    ],
    similarTag: 'MBC Media Solutions',
    imageAccent: 'from-purple-500/20 via-indigo-500/10 to-transparent'
  },
  {
    id: 'alrajhi',
    brand: 'مصرف الراجحي',
    brandEn: 'Al Rajhi Bank',
    brandColor: '#2563EB',
    voiceCategory: 'رد آلي ومراكز اتصال IVR',
    industry: 'القطاع المالي والمصرفي (FinTech)',
    title: 'مصرف الراجحي يطلق مساعده المالي الصوتي التفاعلي لتنفيذ العمليات المصرفية بالصوت',
    titleEn: 'Al Rajhi Bank launches interactive voice AI for banking operations',
    date: '28 أغسطس 2026',
    audioDuration: '1:50',
    audioDurationSecs: 110,
    heroSubtitle: 'أمان مصرفي فائق، سرية تامة، ومعالجة صوتية فورية لاستعلامات الحسابات والتحويلات المالية',
    stats: [
      { label: 'عملية صوتية يومية بنجاح', value: '+500K' },
      { label: 'نسبة رضا عملاء المصرف', value: '98.6%' },
      { label: 'توافق كامل مع الأمن المالي', value: '100%' },
      { label: 'انخفاض زمن إنهاء الخدمة', value: '4x أسرع' }
    ],
    paragraphs: [
      'في إطار استراتيجية التحول الرقمي المصرفي، أطلق مصرف الراجحي خدمة المساعد الصوتي التفاعلي عبر الهاتف المصرفي وتطبيق الهاتف الذكي، معتمداً على محرك الصوت العربي فائق الأمان من Qeema Voice.',
      'يتميز المساعد الصوتي بقدرته على التعرف الصوتي على رغبة العميل بدقة: مثل "حوّل 500 ريال لمحمد"، والرد بصوت مصرفي رصين وموثوق يمنح العميل الطمأنينة الكاملة.'
    ],
    quote: {
      text: 'الصوت هو الواجهة المستقبلية للخدمات المصرفية. مع Qeema Voice، استطعنا تقديم تجربة مصرفية سلسة وموثوقة تتحدث لغة عملائنا بطلاقة واحترافية.',
      author: 'سعود بن سليمان',
      role: 'نائب الرئيس للخدمات الرقمية والابتكار'
    },
    highlights: [
      'استضافة آمنة متوافقة مع متطلبات البنك المركزي والبيانات المحلية',
      'نبرة مصرفية وقورة معتمدة للهوية الصوتية للمصرف',
      'معالجة متقدمة للأرقام والحسابات والتواريخ باللغة العربية'
    ],
    similarTag: 'الراجحي المالية',
    imageAccent: 'from-blue-500/20 via-sky-500/10 to-transparent'
  },
  {
    id: 'saudia-flyadeal',
    brand: 'طيران أديل والخطوط السعودية',
    brandEn: 'Saudia & Flyadeal',
    brandColor: '#059669',
    voiceCategory: 'إعلانات تجارية وسوشيال ميديا',
    industry: 'الطيران والنقل والسياحة',
    title: 'أديل تدشن نظام الإعلانات ونداءات بوابات السفر الصوتية الذكية بـ 6 لغات ولهجات',
    titleEn: 'Flyadeal automates airport gate voice announcements dynamically',
    date: '15 أغسطس 2026',
    audioDuration: '2:15',
    audioDurationSecs: 135,
    heroSubtitle: 'توليد ديناميكي لنداءات المغادرة والصعود إلى الطائرة وتنبيهات الرحلات بنبرة واضحة ومخارج حروف متقنة',
    stats: [
      { label: 'رحلة يومية مخدومة صوتياً', value: '+250' },
      { label: 'مطار محلي ودولي مشمول', value: '28 مطار' },
      { label: 'وضوح الصوت في بيئات الضجيج', value: '99.8%' },
      { label: 'سرعة توليد النداء الآني', value: '<100ms' }
    ],
    paragraphs: [
      'تعتمد شركة طيران أديل على محرك التوليد الصوتي الفوري من Qeema Voice لإرسال نداءات بوابات السفر في المطارات ديناميكياً وتحديث مواعيد الصعود للطائرة باللغتين العربية والإنجليزية بلهجات واضحة تناسب مختلف جنسيات المسافرين.'
    ],
    quote: {
      text: 'النداءات الصوتية في صالات السفر تتطلب وضوحاً هندسياً فائقاً ونطقاً دقيقاً لأسماء الوجهات. لقد حققت Qeema Voice أعلى درجات الموثوقية التشغيلية في مطاراتنا.',
      author: 'كابتن عصام الحارثي',
      role: 'مدير العمليات الجوية والمطارات'
    },
    highlights: [
      'معالجة صوتية مخصصة للبيئات الصوتية المفتوحة وصالات السفر',
      'توليد تلقائي بأسماء المدن والرحلات دون أي خطأ في التشكيل'
    ],
    similarTag: 'طيران أديل للطيران الاقتصادي',
    imageAccent: 'from-emerald-500/20 via-teal-500/10 to-transparent'
  },
  {
    id: 'stc',
    brand: 'شركة STC للاتصالات',
    brandEn: 'stc',
    brandColor: '#4F46E5',
    voiceCategory: 'وثائقي ورسمي',
    industry: 'الاتصالات والتقنية',
    title: 'STC تعتمد الهوية الصوتية الموحدة لأفلام الابتكار الرقمي والفعاليات العالمية',
    titleEn: 'stc unifies audio branding across national and tech innovation films',
    date: '10 أغسطس 2026',
    audioDuration: '2:30',
    audioDurationSecs: 150,
    heroSubtitle: 'صوت سعودي فخم يعبر عن التمكين الرقمي والمستقبل التكنولوجي للمملكة في مؤتمرات LEAP وMWC',
    stats: [
      { label: 'فيديو توثيقي وإعلاني منتج', value: '+120' },
      { label: 'مشاهدات الحملات الترويجية', value: '+45M' },
      { label: 'نقاء الصوت الاستوديو', value: '48kHz' },
      { label: 'سرعة التسليم والتنفيذ', value: '24 ساعة' }
    ],
    paragraphs: [
      'اعتمدت STC على شبكة معلقي قيمة فويس لإنتاج التعليق الصوتي لتقارير الاستدامة السنوية، وأفلام الإطلاق التقنية في مؤتمر LEAP، وحملات اليوم الوطني بنبرة سعودية وقورة تليق بمكانة المشغل الرقمي الأول في المنطقة.'
    ],
    quote: {
      text: 'نبرة الصوت هي البصمة التي تمنح العلامة التجارية حضورها الذهني. في قيمة فويس وجدنا الصوت السعودي المتقن والالتزام الاحترافي العالي.',
      author: 'أحمد التميمي',
      role: 'مدير الاتصال المؤسسي والهوية'
    },
    highlights: [
      'هندسة صوتية متقدمة تناسب قاعات المؤتمرات الكبرى',
      'معلقون صوتيون سعوديون معتمدون بجودة 48kHz'
    ],
    similarTag: 'الاتصالات السعودية',
    imageAccent: 'from-indigo-500/20 via-purple-500/10 to-transparent'
  },
  {
    id: 'jarir-storytel',
    brand: 'مكتبة جرير وستوريتل',
    brandEn: 'Jarir & Storytel',
    brandColor: '#D97706',
    voiceCategory: 'كتب صوتية وبودكاست',
    industry: 'النشر والتعليم الرقمي',
    title: 'إنتاج أكثر من 200 كتاب صوتي عربي بأعلى معايير النطق الفصيح وشهادات ACX',
    titleEn: 'Production of 200+ Arabic audiobooks with ACX studio standards',
    date: '1 أغسطس 2026',
    audioDuration: '3:10',
    audioDurationSecs: 190,
    heroSubtitle: 'تسجيل وتحرير وهندسة الكتب الصوتية الفكرية والأدبية باللغة العربية الفصحى المعاصرة المشكولة',
    stats: [
      { label: 'كتاب صوتي مكتمل الإنتاج', value: '+200' },
      { label: 'ساعة استماع مسجلة', value: '+1,800h' },
      { label: 'تطابق معايير ACX العالمية', value: '100%' },
      { label: 'تقييم المستمعين', value: '4.9/5' }
    ],
    paragraphs: [
      'أثمر التعاون بين دور النشر وقيمة فويس عن تحويل أمهات الكتب والروايات العربية الأكثر مبيعاً إلى أعمال صوتية ملهمة بصوت نخبة من الرواة والمعلقين الفصحاء، مع مطابقة صارمة لقواعد الإخراج الصوتي والنقاء الصوتي.'
    ],
    quote: {
      text: 'قراءة الكتاب الصوتي فن مستقل يتطلب نفساً طويلاً ونطقاً سليماً بلا أي نشاز. هذا ما تقدمه قيمة فويس بجدارة.',
      author: 'د. ليلى المنصور',
      role: 'المشرفة العامة على سلاسل المحتوى الصوتي'
    },
    highlights: [
      'إشراف لغوي ونحوي متكامل لكل فصول الكتاب',
      'هندسة صوتية مطابقة لمواصفات Storytel وAudible'
    ],
    similarTag: 'النشر الصوتي الرقمي',
    imageAccent: 'from-amber-500/20 via-yellow-500/10 to-transparent'
  },
  {
    id: 'emaar',
    brand: 'إعمار العقارية',
    brandEn: 'Emaar Properties',
    brandColor: '#0F172A',
    voiceCategory: 'إعلانات تجارية وسوشيال ميديا',
    industry: 'العقارات والضيافة',
    title: 'إطلاق مشاريع عقارات دبي الفاخرة بأصوات إماراتية وخليجية راقية تخاطب المستثمرين',
    titleEn: 'Luxury Dubai real estate project launches with elite Emirati voice talent',
    date: '20 يوليو 2026',
    audioDuration: '1:45',
    audioDurationSecs: 105,
    heroSubtitle: 'إنتاج الحملات التسويقية المرئية والمسموعة لعقارات وسط مدينة دبي والواجهات المائية',
    stats: [
      { label: 'حملة إعلانية مسجلة', value: '35+' },
      { label: 'لغات ولهجات البث', value: 'عربي وإنجليزي' },
      { label: 'نسبة وصول الإعلان', value: '+22M' },
      { label: 'جودة التسجيل', value: 'Master Studio' }
    ],
    paragraphs: [
      'تطلبت حملات إعمار لترويج أبراجها وفنادقها الفاخرة خامة صوتية استثنائية تعكس الفخامة والأناقة العالمية، وتم اختيار معلقين صوتيين إماراتيين وخليجيين معتمدين من مكتبة قيمة فويس لتسجيل الإعلانات السينمائية.'
    ],
    quote: {
      text: 'الفخامة تبدأ من الصوت. عينات قيمة فويس منحت مشاريعنا صدى يليق بتطلعات عملائنا حول العالم.',
      author: 'مبارك بن سيف',
      role: 'مدير التسويق الإقليمي'
    },
    highlights: [
      'حقوق استخدام تجاري وبث تلفزيوني ورقمي كامل',
      'نبرة راقية تعبر عن معايير الضيافة والفخامة العقارية'
    ],
    similarTag: 'مشاريع دبي العقارية',
    imageAccent: 'from-slate-500/20 via-zinc-500/10 to-transparent'
  }
];

interface CustomerStoriesViewProps {
  onNavigate?: (view: ActiveView, extra?: any) => void;
  onOpenDemo?: () => void;
  initialStoryId?: string;
}

export const CustomerStoriesView: React.FC<CustomerStoriesViewProps> = ({
  onNavigate,
  onOpenDemo,
  initialStoryId = 'jahez'
}) => {
  // Classification Filter State
  const [filterMode, setFilterMode] = useState<'voiceCategory' | 'industry'>('voiceCategory');
  const [selectedVoiceCategory, setSelectedVoiceCategory] = useState<string>('الكل');
  const [selectedIndustry, setSelectedIndustry] = useState<string>('الكل');

  const [activeStoryId, setActiveStoryId] = useState<string>(initialStoryId);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);

  // Filter stories based on selected mode
  const filteredStories = STORIES.filter(story => {
    if (filterMode === 'voiceCategory') {
      if (selectedVoiceCategory === 'الكل') return true;
      return story.voiceCategory === selectedVoiceCategory;
    } else {
      if (selectedIndustry === 'الكل') return true;
      return story.industry === selectedIndustry;
    }
  });

  const activeStory = filteredStories.find(s => s.id === activeStoryId) || filteredStories[0] || STORIES[0];

  useEffect(() => {
    let timer: any;
    if (isPlayingAudio) {
      timer = setInterval(() => {
        setAudioProgress(prev => {
          if (prev >= 100) {
            setIsPlayingAudio(false);
            return 0;
          }
          return prev + 1;
        });
      }, (activeStory.audioDurationSecs || 120) * 10);
    }
    return () => clearInterval(timer);
  }, [isPlayingAudio, activeStory]);

  const handleToggleAudio = () => {
    setIsPlayingAudio(!isPlayingAudio);
  };

  const handleSelectStory = (id: string) => {
    setActiveStoryId(id);
    setIsPlayingAudio(false);
    setAudioProgress(0);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10" dir="rtl">
      
      {/* Dual Classification Filter Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        
        {/* Top Filter Mode Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              تصفح قصص العملاء والتجارب الناجحة
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              اختر عرض القصص حسب تصنيف التعليق الصوتي أو حسب مجال الشركة والقطاع.
            </p>
          </div>

          <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 self-start sm:self-auto">
            <button
              onClick={() => { setFilterMode('voiceCategory'); setSelectedIndustry('الكل'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                filterMode === 'voiceCategory'
                  ? 'bg-[#FF5500] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>حسب تصنيف التعليق الصوتي</span>
            </button>
            <button
              onClick={() => { setFilterMode('industry'); setSelectedVoiceCategory('الكل'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                filterMode === 'industry'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>حسب مجال الشركة (العميل)</span>
            </button>
          </div>
        </div>

        {/* Filter Pills based on active mode */}
        <div>
          <div className="text-xs font-bold text-slate-500 mb-2.5 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-[#FF5500]" />
            <span>
              {filterMode === 'voiceCategory' 
                ? 'تصنيفات التعليق الصوتي المتاحة:' 
                : 'قطاعات ومجالات الشركات:'}
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
            {filterMode === 'voiceCategory' ? (
              VOICE_CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedVoiceCategory(cat)}
                  className={`px-4 py-2 rounded-xl font-bold transition whitespace-nowrap cursor-pointer ${
                    selectedVoiceCategory === cat
                      ? 'bg-[#FF5500] text-white shadow-sm shadow-[#FF5500]/25'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))
            ) : (
              INDUSTRIES.map(ind => (
                <button
                  key={ind}
                  onClick={() => setSelectedIndustry(ind)}
                  className={`px-4 py-2 rounded-xl font-bold transition whitespace-nowrap cursor-pointer ${
                    selectedIndustry === ind
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  {ind}
                </button>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Brand Tabs Strip */}
      <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
        {filteredStories.map(story => {
          const isSelected = story.id === activeStory.id;
          return (
            <button
              key={story.id}
              onClick={() => handleSelectStory(story.id)}
              className={`px-5 py-3 rounded-2xl border transition-all flex items-center gap-3 shrink-0 cursor-pointer ${
                isSelected
                  ? 'bg-white border-[#FF5500] shadow-md ring-2 ring-[#FF5500]/20'
                  : 'bg-white/80 hover:bg-white border-slate-200 text-slate-600'
              }`}
            >
              <div 
                className="w-3 h-3 rounded-full shrink-0" 
                style={{ backgroundColor: story.brandColor }}
              />
              <div className="text-right">
                <div className="text-xs font-bold text-slate-900">{story.brand}</div>
                <div className="text-[10px] text-slate-500">{story.voiceCategory}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Selected Story Showcase */}
      {activeStory && (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden animate-in fade-in">
          
          {/* Story Hero Header */}
          <div className={`p-6 sm:p-10 bg-gradient-to-br ${activeStory.imageAccent} border-b border-slate-100`}>
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#FF5500]/10 text-[#FF5500] border border-[#FF5500]/20">
                  {activeStory.voiceCategory}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-900/10 text-slate-800">
                  {activeStory.industry}
                </span>
              </div>
              <span className="text-xs text-slate-500 font-medium">{activeStory.date}</span>
            </div>

            <h3 className="text-2xl sm:text-4xl font-black text-slate-950 tracking-tight leading-snug max-w-4xl mb-4">
              {activeStory.title}
            </h3>

            <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed mb-6 font-normal">
              {activeStory.heroSubtitle}
            </p>

            {/* Audio Narration Bar */}
            <div className="p-4 rounded-2xl bg-slate-900 text-white flex items-center justify-between gap-4 max-w-2xl">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleToggleAudio}
                  className="w-10 h-10 rounded-xl bg-[#FF5500] hover:bg-[#E04800] text-white flex items-center justify-center transition shadow-md cursor-pointer"
                >
                  {isPlayingAudio ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                </button>
                <div>
                  <div className="text-xs font-bold flex items-center gap-2">
                    <span>استمع لملخص القصة بصوت استوديو 48kHz</span>
                    {isPlayingAudio && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    مدة الاستماع: {activeStory.audioDuration} دقيقة
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-32 h-1.5 bg-slate-800 rounded-full overflow-hidden hidden sm:block">
                <div 
                  className="h-full bg-[#FF5500] transition-all duration-300" 
                  style={{ width: `${audioProgress}%` }}
                />
              </div>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 border-b border-slate-100 bg-slate-50/50">
            {activeStory.stats.map((stat, idx) => (
              <div key={idx} className="p-6 text-center border-l last:border-l-0 border-slate-100">
                <div className="text-2xl sm:text-4xl font-black text-slate-900 font-mono">
                  {stat.value}
                </div>
                <div className="text-xs text-slate-600 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Story Body & Quote */}
          <div className="p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Paragraphs (7 cols) */}
            <div className="lg:col-span-7 space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
              {activeStory.paragraphs.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}

              <div className="pt-4 space-y-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase">أبرز نتائج المشروع:</h4>
                <ul className="space-y-1.5 text-xs text-slate-600">
                  {activeStory.highlights.map((h, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Executive Quote Card (5 cols) */}
            <div className="lg:col-span-5 bg-orange-50/60 rounded-3xl p-6 border border-orange-200/80 space-y-4">
              <MessageSquareQuote className="w-8 h-8 text-[#FF5500]" />
              <blockquote className="text-xs sm:text-sm text-slate-800 font-medium leading-relaxed italic">
                "{activeStory.quote.text}"
              </blockquote>
              <div className="border-t border-orange-200/60 pt-3">
                <div className="text-xs font-bold text-slate-900">{activeStory.quote.author}</div>
                <div className="text-[11px] text-slate-500">{activeStory.quote.role}</div>
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
