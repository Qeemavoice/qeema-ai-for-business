import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface TrustedEnterpriseBrandsProps {
  onReadStories?: (storyId?: string) => void;
}

export const TrustedEnterpriseBrands: React.FC<TrustedEnterpriseBrandsProps> = ({ onReadStories }) => {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-16" dir="rtl">
      
      {/* Top Header Row with Clean Title and Action Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mb-1">
            قصص النجاح
          </h2>
          <h3 className="text-xs sm:text-sm text-slate-600 font-medium">
            موثوق من قِبل كبرى الشركات والمؤسسات العربية الرائدة
          </h3>
        </div>

        <button
          onClick={() => onReadStories && onReadStories('jahez')}
          className="self-start sm:self-auto px-5 py-2.5 rounded-full border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 hover:text-slate-950 text-xs font-bold transition-all shadow-xs hover:border-slate-300 flex items-center gap-2 cursor-pointer group"
        >
          <span>اقرأ قصص النجاح</span>
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform text-[#FF5500]" />
        </button>
      </div>

      {/* Main Logo Showcase Container matching Screenshot */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-8 sm:p-12 relative overflow-hidden">
        
        {/* Arab & Regional Enterprise Logos Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-y-10 gap-x-8 items-center justify-items-center opacity-85 hover:opacity-100 transition-opacity">
          
          {/* 1. جاهز (Jahez) */}
          <div 
            onClick={() => onReadStories && onReadStories('jahez')}
            className="flex items-center gap-1.5 cursor-pointer text-slate-700 hover:text-[#FF5500] transition-colors group" 
            title="قصة نجاح جاهز"
          >
            <div className="w-7 h-7 rounded-lg bg-[#FF5500] text-white flex items-center justify-center font-black text-sm group-hover:scale-105 transition-transform">
              ج
            </div>
            <span className="font-black text-2xl tracking-tight text-slate-800 group-hover:text-[#FF5500] font-sans">
              جاهـز
            </span>
          </div>

          {/* 2. الاتصالات السعودية stc */}
          <div className="flex items-center text-slate-800 hover:text-purple-700 transition-colors group">
            <span className="font-black text-3xl tracking-tighter text-[#4f008c] font-sans">stc</span>
          </div>

          {/* 3. أرامكو السعودية (Saudi Aramco) */}
          <div className="flex items-center gap-2 text-slate-800 hover:text-emerald-600 transition-colors">
            <div className="flex flex-col">
              <span className="font-extrabold text-lg text-slate-900 tracking-tight leading-none">أرامكو السعودية</span>
              <span className="text-[10px] font-sans font-bold tracking-widest text-[#00a3e0] leading-tight">aramco</span>
            </div>
          </div>

          {/* 4. مجموعة MBC وشاهد */}
          <div 
            onClick={() => onReadStories && onReadStories('mbc-shahid')}
            className="flex items-center gap-1.5 cursor-pointer text-slate-800 hover:text-purple-600 transition-colors group"
            title="قصة نجاح مجموعة MBC وشاهد"
          >
            <span className="font-black text-2xl tracking-wider text-slate-900 font-sans group-hover:text-purple-700">mbc</span>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-800">GROUP</span>
          </div>

          {/* 5. مصرف الراجحي */}
          <div 
            onClick={() => onReadStories && onReadStories('alrajhi')}
            className="flex items-center gap-2 cursor-pointer text-slate-800 hover:text-blue-600 transition-colors group"
            title="قصة نجاح مصرف الراجحي"
          >
            <div className="w-6 h-6 rounded-md bg-[#003B70] text-white flex items-center justify-center text-xs font-bold">
              🔷
            </div>
            <div className="flex flex-col text-right">
              <span className="font-black text-sm text-[#003B70] leading-none group-hover:text-blue-600">مصرف الراجحي</span>
              <span className="text-[9px] font-sans font-bold text-slate-400">alrajhi bank</span>
            </div>
          </div>

          {/* 6. منصة شاهد (Shahid VIP) */}
          <div 
            onClick={() => onReadStories && onReadStories('mbc-shahid')}
            className="flex items-center gap-1.5 cursor-pointer text-slate-800 hover:text-emerald-500 transition-colors group"
          >
            <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-white text-[10px] font-bold">
              ▶
            </div>
            <span className="font-black text-2xl tracking-tight text-slate-900 font-sans group-hover:text-emerald-600">
              شاهد
            </span>
          </div>

          {/* 7. هنقرستيشن (Hungerstation) */}
          <div className="flex items-center gap-1 text-slate-800 hover:text-amber-600 transition-colors">
            <div className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center font-black text-xs">
              H
            </div>
            <span className="font-extrabold text-base tracking-tight text-slate-900">
              هنقرستيشن
            </span>
          </div>

          {/* 8. شركة علم (Elm) */}
          <div className="flex items-center gap-1.5 text-slate-800 hover:text-blue-700 transition-colors">
            <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
              ع
            </div>
            <span className="font-black text-xl tracking-tight text-slate-900 font-sans">عِــلـم</span>
          </div>

          {/* 9. شركة المراعي (Almarai) */}
          <div className="flex flex-col items-center text-slate-800 hover:text-blue-600 transition-colors">
            <span className="font-black text-xl tracking-tight text-[#005A9C]">المراعي</span>
            <span className="text-[9px] font-sans font-bold tracking-widest text-slate-400 -mt-0.5">Almarai</span>
          </div>

          {/* 10. طيران أديل والخطوط السعودية */}
          <div 
            onClick={() => onReadStories && onReadStories('saudia-flyadeal')}
            className="flex items-center gap-1.5 cursor-pointer text-slate-800 hover:text-emerald-600 transition-colors group"
            title="قصة نجاح طيران أديل"
          >
            <span className="font-black text-xl tracking-tighter text-[#78BE20] font-sans">flyadeal</span>
            <span className="text-xs font-bold text-slate-600 group-hover:text-emerald-700">أديل</span>
          </div>

          {/* 11. مجموعة تداول السعودية (Saudi Tadawul Group) */}
          <div className="flex flex-col text-right text-slate-800 hover:text-slate-950 transition-colors">
            <span className="font-black text-sm text-slate-900 leading-tight">تداول السعودية</span>
            <span className="text-[9px] font-sans font-semibold text-slate-400">Saudi Tadawul Group</span>
          </div>

          {/* 12. زين السعودية والخليج (Zain) */}
          <div className="flex items-center text-slate-800 hover:text-teal-600 transition-colors">
            <span className="font-black text-2xl tracking-tighter text-[#009688] font-sans">ZaiN</span>
          </div>

          {/* 13. شركة سابك (SABIC) */}
          <div className="flex items-center gap-1.5 text-slate-800 hover:text-blue-600 transition-colors">
            <span className="font-black text-2xl tracking-widest text-[#003A70] font-sans">SABIC</span>
          </div>

          {/* 14. شركة نون (noon) */}
          <div className="flex items-center gap-1 text-slate-800 hover:text-amber-500 transition-colors">
            <div className="w-5 h-5 rounded-full bg-yellow-400 flex items-center justify-center font-bold text-[10px] text-slate-950">
              ●
            </div>
            <span className="font-black text-2xl tracking-tight text-slate-900 font-sans">noon</span>
          </div>

          {/* 15. مكتبة جرير (Jarir Bookstore) */}
          <div className="flex items-center gap-1.5 text-slate-800 hover:text-red-600 transition-colors">
            <div className="w-5 h-5 rounded bg-red-600 text-white flex items-center justify-center text-[10px] font-bold">
              ج
            </div>
            <span className="font-bold text-base text-slate-900">مكتبة جرير</span>
          </div>

          {/* 16. موانئ دبي العالمية (DP World) */}
          <div className="flex items-center text-slate-800 hover:text-indigo-600 transition-colors">
            <span className="font-black text-xl tracking-tight text-[#002B49] font-sans">DP WORLD</span>
          </div>

          {/* 17. سلام للاتصالات (Salam) */}
          <div className="flex items-center text-slate-800 hover:text-sky-600 transition-colors">
            <span className="font-black text-2xl tracking-tight text-[#00A3E0]">salam</span>
          </div>

          {/* 18. بنك الرياض (Riyad Bank) */}
          <div className="flex flex-col text-right text-slate-800 hover:text-emerald-700 transition-colors">
            <span className="font-bold text-sm text-[#007A3D]">بنك الرياض</span>
            <span className="text-[9px] font-sans font-medium text-slate-400">riyad bank</span>
          </div>

          {/* 19. الخطوط السعودية (SAUDIA) */}
          <div className="flex flex-col text-right text-slate-800 hover:text-[#004B23] transition-colors">
            <span className="font-black text-sm text-[#004B23]">الخطوط السعودية</span>
            <span className="text-[9px] font-sans font-bold tracking-widest text-slate-400">SAUDIA</span>
          </div>

          {/* 20. مجموعة دله البركة (Dallah) */}
          <div className="flex items-center text-slate-800 hover:text-amber-700 transition-colors">
            <span className="font-bold text-base text-slate-900">دله البركة</span>
          </div>

        </div>

      </div>

    </section>
  );
};
