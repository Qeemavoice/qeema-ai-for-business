import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Check, 
  Sparkles, 
  ShieldCheck, 
  ArrowLeft, 
  Calculator, 
  HelpCircle, 
  Clock, 
  Layers, 
  Zap, 
  CreditCard,
  Building2,
  ChevronDown
} from 'lucide-react';
import { useSeo } from '../seo/useSeo';
import { STATIC_SEO_ROUTES } from '../seo/seoConfig';
import { Breadcrumbs } from '../components/Breadcrumbs';

export const PricingPage: React.FC = () => {
  // 1. Centralized SEO matching requirements exactly
  useSeo(STATIC_SEO_ROUTES['/ar/pricing']);

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  // Interactive Project Price Calculator State
  const [calcService, setCalcService] = useState<'commercial' | 'audiobook' | 'ivr' | 'dubbing'>('commercial');
  const [calcWords, setCalcWords] = useState<number>(100);
  const [calcDialect, setCalcDialect] = useState<'saudi' | 'fusha' | 'egyptian' | 'emirati'>('saudi');

  // Estimate price dynamically in USD ($)
  const calculatePrice = () => {
    let baseRatePerWord = 0.25; // USD
    if (calcService === 'commercial') baseRatePerWord = 0.35;
    if (calcService === 'audiobook') baseRatePerWord = 0.15;
    if (calcService === 'ivr') baseRatePerWord = 0.30;
    if (calcService === 'dubbing') baseRatePerWord = 0.40;

    if (calcDialect === 'saudi' || calcDialect === 'emirati') baseRatePerWord *= 1.15;

    const estimatedUsd = Math.max(35, Math.round(calcWords * baseRatePerWord));
    const estimatedMinutes = Math.max(1, Math.round(calcWords / 130));

    return { estimatedUsd, estimatedMinutes };
  };

  const { estimatedUsd, estimatedMinutes } = calculatePrice();

  // FAQ Accordion State
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const pricingFaqs = [
    {
      q: 'هل تشمل الأسعار التراخيص التجارية وحقوق البث؟',
      a: 'نعم، جميع أسعار التعليق الصوتي في قيمة فويس تتضمن ترخيصاً تجارياً موثقاً يتيح لك استخدام الصوت في الحملات الرقمية، السوشيال ميديا، والمنصات الترويجية بدون أي رسوم ملكية إضافية.'
    },
    {
      q: 'ما هي سياسة التعديلات وإعادة التسجيل؟',
      a: 'أي خطأ في نطق النص أو التشكيل المتفق عليه يُعاد تسجيله مجاناً بنسبة 100%. أما التعديلات الناتجة عن تغيير النص الأصلي بعد التسجيل فيتم احتسابها بخصم 50% من تكلفة المقطع المعدل.'
    },
    {
      q: 'كيف يتم احتساب الأسعار للمشاريع الكبيرة والكتب الصوتية؟',
      a: 'نقدم تسعيراً مخفضاً بالدقيقة أو بآلاف الكلمات للكتب الصوتية والدورات التدريبية وسلاسل البودكاست مع مهندس صوت مخصص يشرف على معايير ACX العالمية.'
    },
    {
      q: 'هل توفرون فواتير ضريبية معتمدة للشركات؟',
      a: 'نعم، نصدر فواتير ضريبية نظامية متوافقة مع متطلبات هيئة الزكاة والضريبة والجمارك (ZATCA) في السعودية، بالإضافة إلى خيارات الدفع عبر أوامر الشراء والتحويل البنكي المؤسسي.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs for SEO */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { name: 'الأسعار', item: '/ar/pricing' }
        ]} />
      </div>

      {/* SEO Header Section with Single Strict H1 */}
      <header className="py-12 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-50 border border-orange-200 text-[#FF5500] text-xs font-bold">
            <CreditCard className="w-4 h-4" />
            <span>تسعير شفاف ومرن بدون رسوم خفية</span>
          </div>

          {/* Strict Single H1 matching SEO spec */}
          <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight">
            أسعار التعليق الصوتي
          </h1>

          <p className="text-sm sm:text-base text-slate-600 max-w-3xl mx-auto leading-relaxed">
            تعرّف على أسعار التعليق الصوتي في قيمة فويس حسب نوع المشروع ومدته واللهجة وحقوق الاستخدام، واطلب عرض سعر لمشروعك.
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold mt-2 shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>ملاحظة: كل مستخدم جديد يحصل على رصيد مجاني بالبداية لتجربة الأصوات واستوديو توليد النصوص!</span>
          </div>

          {/* Billing Cycle Switcher */}
          <div className="pt-4 flex items-center justify-center gap-3">
            <span className={`text-xs font-bold ${billingCycle === 'monthly' ? 'text-slate-900' : 'text-slate-500'}`}>
              دفع شهري
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
              className="relative w-14 h-7 rounded-full bg-slate-900 p-1 transition cursor-pointer"
            >
              <div 
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  billingCycle === 'annual' ? '-translate-x-7 bg-[#FF5500]' : 'translate-x-0'
                }`}
              />
            </button>
            <span className={`text-xs font-bold flex items-center gap-1.5 ${billingCycle === 'annual' ? 'text-slate-900' : 'text-slate-500'}`}>
              <span>اشتراك سنوي</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                وفر 20%
              </span>
            </span>
          </div>
        </div>
      </header>

      {/* 1. Subscription & Production Plans Cards */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Plan 1: Starter */}
            <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <span className="text-xs font-bold text-slate-500 uppercase">لصناع المحتوى والمشاريع الناشئة</span>
                <h2 className="text-2xl font-bold text-slate-900">الباقة الأساسية</h2>
                <div className="flex items-baseline gap-1.5 font-mono">
                  <span className="text-4xl font-black text-slate-950">
                    ${billingCycle === 'annual' ? '39' : '49'}
                  </span>
                  <span className="text-xs text-slate-500 font-sans">/ شهرياً</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  مثالية لتسجيل المقاطع السريعة وتوليد أصوات الـ AI المرخصة وتجربة المعلقين.
                </p>

                <div className="space-y-3 pt-4 border-t border-slate-100 text-xs text-slate-700">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>30,000 حرف توليد استوديو TTS ذكي</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>خصم 10% على كافة حجوزات المعلقين البشريين</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>ترخيص تجاري كامل لجميع المنصات الرقمية</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>تسليم بصيغة WAV نقاء 48kHz</span>
                  </div>
                </div>
              </div>

              <Link
                to="/ar/contact-us"
                className="w-full py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold text-xs text-center transition"
              >
                اختيار الباقة الأساسية
              </Link>
            </div>

            {/* Plan 2: Business Pro (Featured) */}
            <div className="bg-slate-950 text-white rounded-3xl p-8 border-2 border-[#FF5500] shadow-2xl flex flex-col justify-between space-y-6 relative">
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-[#FF5500] text-white text-[11px] font-bold shadow-md">
                الأكثر طلباً للشركات والوكالات
              </div>

              <div className="space-y-4">
                <span className="text-xs font-bold text-[#FF7733] uppercase">للوكالات الإعلانية والشركات المتنامية</span>
                <h2 className="text-2xl font-bold text-white">باقة الأعمال (Business)</h2>
                <div className="flex items-baseline gap-1.5 font-mono">
                  <span className="text-4xl font-black text-white">
                    ${billingCycle === 'annual' ? '119' : '149'}
                  </span>
                  <span className="text-xs text-slate-400 font-sans">/ شهرياً</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  تغطية شاملة لحملات السوشيال ميديا، إعلانات السناب والتيك توك، ومقدمات البودكاست.
                </p>

                <div className="space-y-3 pt-4 border-t border-slate-800 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#FF5500] shrink-0" />
                    <span>120,000 حرف توليد صوتي فائق النقاء</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#FF5500] shrink-0" />
                    <span>خصم 20% على حجوزات المعلقين الصوتيين</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#FF5500] shrink-0" />
                    <span>أولوية تنفيذ وتسجيل استوديو فوري</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#FF5500] shrink-0" />
                    <span>إعادة تسجيل مجانية للضبط الإخراجي</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#FF5500] shrink-0" />
                    <span>فواتير نظامية معتمدة للشركات</span>
                  </div>
                </div>
              </div>

              <Link
                to="/ar/contact-us"
                className="w-full py-3.5 rounded-2xl bg-[#FF5500] hover:bg-[#E04800] text-white font-bold text-xs text-center transition shadow-lg shadow-[#FF5500]/25"
              >
                شحن باقة الأعمال فوراً
              </Link>
            </div>

            {/* Plan 3: Enterprise */}
            <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <span className="text-xs font-bold text-slate-500 uppercase">للمؤسسات والجهات الحكومية والإنتاج الضخم</span>
                <h2 className="text-2xl font-bold text-slate-900">المؤسسات (Enterprise)</h2>
                <div className="flex items-baseline gap-1.5 font-mono">
                  <span className="text-3xl font-black text-slate-950">تسعير مخصص</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  عقود إنتاج سنوية، استنساخ صوتي حصري، وربط API لأنظمة مراكز الاتصال والرد الآلي.
                </p>

                <div className="space-y-3 pt-4 border-t border-slate-100 text-xs text-slate-700">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>رصيد كلمات غير محدود للمنشأة</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>مدير حساب وإنتاج صوتي مخصص</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>اتفاقية مستوى الخدمة SLA تضمن تسليم فوري</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>دفع عبر أوامر الشراء والتحويل البنكي الآجل</span>
                  </div>
                </div>
              </div>

              <Link
                to="/ar/contact-us"
                className="w-full py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs text-center transition"
              >
                طلب استشارة مؤسسية مخصصة
              </Link>
            </div>

          </div>
        </div>
      </section>

      {/* 2. Interactive Project Cost Calculator */}
      <section className="py-12 bg-white border-y border-slate-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FF5500]">
              <Calculator className="w-4 h-4" />
              <span>حاسبة تكلفة المشروع التقديرية</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900">
              احسب تكلفة تسجيل مشروعك الصوتي في ثوانٍ
            </h2>
            <p className="text-xs text-slate-500">
              اختر نوع المشروع واللهجة وعدد الكلمات لتقدير القيمة التقريبية قبل بدء الحجز.
            </p>
          </div>

          <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 border border-slate-200 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Inputs (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">نوع المشروع الصوتي</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'commercial', label: 'إعلان تجاري' },
                    { id: 'audiobook', label: 'كتاب صوتي' },
                    { id: 'ivr', label: 'رد آلي سنترال' },
                    { id: 'dubbing', label: 'دوبلاج كرتون' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setCalcService(item.id as any)}
                      className={`p-2.5 rounded-xl text-xs font-bold transition border cursor-pointer ${
                        calcService === item.id
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">اللهجة المطلوبة</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'saudi', label: 'سعودية' },
                    { id: 'fusha', label: 'فصحى' },
                    { id: 'emirati', label: 'إماراتية' },
                    { id: 'egyptian', label: 'مصرية' }
                  ].map(d => (
                    <button
                      key={d.id}
                      onClick={() => setCalcDialect(d.id as any)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition border cursor-pointer ${
                        calcDialect === d.id
                          ? 'bg-[#FF5500] text-white border-[#FF5500]'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-1">
                  <span>عدد الكلمات التقريبي:</span>
                  <span className="font-mono text-[#FF5500] text-sm">{calcWords} كلمة</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="1500"
                  step="10"
                  value={calcWords}
                  onChange={e => setCalcWords(Number(e.target.value))}
                  className="w-full accent-[#FF5500] cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>إعلان قصير (20 كلمة)</span>
                  <span>فيديو تعريفي (300 كلمة)</span>
                  <span>بودكاست / وثائقي (1500 كلمة)</span>
                </div>
              </div>
            </div>

            {/* Calculation Result Output Card (5 cols) */}
            <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-md text-center space-y-4">
              <span className="text-xs text-slate-500 font-medium">التكلفة التقديرية للمشروع</span>
              <div className="font-mono">
                <span className="text-4xl font-black text-slate-900">${estimatedUsd}</span>
                <span className="text-xs text-slate-500 font-sans mr-1">دولار أمريكي (USD)</span>
              </div>
              
              <div className="p-3 rounded-xl bg-orange-50/70 text-slate-700 text-xs space-y-1">
                <div>المدة الزمنية المتوقعة: <strong>~{estimatedMinutes} دقيقة</strong></div>
                <div className="text-[11px] text-slate-500">تشمل الهندسة الصوتية والترخيص التجاري</div>
              </div>

              <Link
                to="/ar/voices"
                className="w-full py-3 rounded-xl bg-[#FF5500] hover:bg-[#E04800] text-white text-xs font-bold shadow-md block transition"
              >
                اختيار معلق صوتي وبدء المشروع
              </Link>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Pricing FAQ Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-bold text-slate-900">
              الأسئلة الشائعة حول أسعار التعليق الصوتي
            </h2>
            <p className="text-xs text-slate-500">
              إجابات واضحة عن كل ما يخص تكلفة الحجز وطرق الدفع والضمانات.
            </p>
          </div>

          <div className="space-y-3">
            {pricingFaqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div key={idx} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="w-full p-5 text-right flex items-center justify-between gap-4 font-bold text-xs sm:text-sm text-slate-900 hover:text-[#FF5500] transition cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="text-center pt-6">
            <p className="text-xs text-slate-500 mb-3">هل لديك نص مخصص وتريد عرض سعر رسمي مختوم لشركتك؟</p>
            <Link
              to="/ar/contact-us"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition shadow-sm"
            >
              <span>طلب عرض سعر رسمي فوري</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
};
