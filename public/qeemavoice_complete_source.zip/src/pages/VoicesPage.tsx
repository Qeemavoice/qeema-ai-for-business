import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Voice } from '../types';
import { useSeo } from '../seo/useSeo';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { VoiceLibraryView } from '../components/VoiceLibraryView';

interface VoicesPageProps {
  voices: Voice[];
  onSelectForBooking?: (voice: Voice) => void;
  onOpenDemo?: () => void;
  isLoggedIn?: boolean;
}

const CATEGORIES_MAP: Record<string, string> = {
  '1-إعلانات': 'إعلانات تجارية',
  '2-وثائقي': 'وثائقي ورسمي',
  '3-دوبلاج': 'دوبلاج وكرتون',
  '4-كتب-صوتية': 'كتب صوتية',
  '5-بودكاست': 'بودكاست',
  '6-رد-آلي': 'رد آلي IVR'
};

export const VoicesPage: React.FC<VoicesPageProps> = ({ 
  voices, 
  onSelectForBooking,
  onOpenDemo,
  isLoggedIn = true 
}) => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const categoryParam = searchParams.get('category') || '';
  const categoryName = CATEGORIES_MAP[categoryParam] || '';

  // Dynamic Title & H1 based on category parameter as required by SEO Spec
  const pageTitle = categoryName 
    ? `أصوات ${categoryName}: عينات تعليق صوتي | قيمة فويس`
    : 'مكتبة الأصوات: عينات تعليق صوتي رجالي ونسائي | قيمة فويس';
  const pageH1 = categoryName 
    ? `أصوات ${categoryName}`
    : 'مكتبة أصوات المعلقين العرب';
  const pageDesc = 'استمع لعينات أكثر من 1000 معلق صوتي عربي، رجالي ونسائي، بالفصحى والسعودية والإماراتية والمصرية وكل اللهجات، واختر الصوت المناسب لمشروعك.';

  // 1. Centralized SEO with Category Preserved in Canonical
  useSeo({
    path: '/ar/voices',
    title: pageTitle,
    h1: pageH1,
    description: pageDesc,
    ogType: 'website',
    breadcrumbs: [
      { name: 'الرئيسية', item: '/ar' },
      { 
        name: categoryName ? `أصوات ${categoryName}` : 'مكتبة الأصوات', 
        item: `/ar/voices${categoryParam ? `?category=${categoryParam}` : ''}` 
      }
    ]
  });

  const handleBooking = (voice: any) => {
    if (onSelectForBooking) {
      onSelectForBooking(voice);
    }
    const slug = `${voice.id}-${encodeURIComponent((voice.name || 'voice').replace(/\s+/g, '-'))}`;
    navigate(`/ar/booking/${slug}`);
  };

  const handleGeneration = (voice: any) => {
    navigate('/ar/text-to-speech');
  };

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs for SEO and navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { 
            name: categoryName ? `أصوات ${categoryName}` : 'مكتبة الأصوات', 
            item: `/ar/voices${categoryParam ? `?category=${categoryParam}` : ''}` 
          }
        ]} />
      </div>

      {/* SEO Headline Area with Strict Single H1 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-2">
        <div className="border-b border-slate-200/80 pb-4">
          <div className="flex flex-wrap items-baseline gap-2 mb-1">
            <span className="text-xs font-bold text-[#FF5500] uppercase tracking-wider">
              أكثر من 1000 معلق معتمد
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500">نقاء استوديو موحد 48kHz</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-950 tracking-tight">
            {pageH1}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-3xl leading-relaxed">
            {pageDesc}
          </p>
        </div>
      </div>

      {/* The Restored High-Density Interactive Voice Library */}
      <VoiceLibraryView
        voices={voices}
        initialTab="human"
        onSelectForBooking={handleBooking}
        onSelectForGeneration={handleGeneration}
        onOpenDemo={onOpenDemo}
        isLoggedIn={isLoggedIn}
      />
    </div>
  );
};
