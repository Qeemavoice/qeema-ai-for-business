import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ArrowLeft, Volume2, Sparkles, Send, ShieldCheck, FileCheck } from 'lucide-react';
import { useSeo } from '../seo/useSeo';
import { STATIC_SEO_ROUTES } from '../seo/seoConfig';
import { Breadcrumbs } from '../components/Breadcrumbs';

export const BookingStepsPage: React.FC = () => {
  useSeo(STATIC_SEO_ROUTES['/ar/booking-steps']);

  const steps = [
    {
      number: '01',
      title: 'استمع واختر الصوت المناسب',
      desc: 'تصفح مكتبة الأصوات وفلتر حسب اللهجة (سعودية، إماراتية، مصرية، فصحى...) ونوع المشروع والجنس واستمع للعينات.'
    },
    {
      number: '02',
      title: 'أرسل النص والتعليمات الإخراجية',
      desc: 'الصق نص الإعلان أو السيناريو، وحدد النبرة المطلوبة وسرعة الإلقاء وأي كلمات تحتاج تأكيداً للنطق الصحيح.'
    },
    {
      number: '03',
      title: 'اعتماد عرض السعر والدفع الآمن',
      desc: 'تحصل على تسعير فوري وشفاف بعدد الكلمات مع خيارات دفع متعددة وفواتير ضريبية إلكترونية معتمدة.'
    },
    {
      number: '04',
      title: 'استلم التسجيل النهائي بجودة 48kHz',
      desc: 'يصلك الملف الصوتي مسجلاً في استوديو معزول مع إمكانية طلب أي تعديل نطق مجاناً حتى الرضا الكامل.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { name: 'خطوات الحجز', item: '/ar/booking-steps' }
        ]} />
      </div>

      <section className="py-12 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF5500]/10 text-[#FF5500] text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>دليل الحجز الميسر</span>
          </div>

          {/* Strict Single H1 */}
          <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight">
            كيف تحجز معلقك الصوتي
          </h1>

          <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
            خطوات حجز معلق صوتي في قيمة فويس: اختر الصوت، وأرسل النص، واستلم التسجيل النهائي بجودة احترافية خلال 24 إلى 48 ساعة مع كامل التراخيص التجارية.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {steps.map((s, idx) => (
              <div key={idx} className="p-8 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4 relative">
                <div className="text-4xl font-black text-[#FF5500]/25 font-mono">{s.number}</div>
                <h2 className="text-lg font-bold text-slate-900">{s.title}</h2>
                <p className="text-xs text-slate-600 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>

          <div className="text-center pt-6">
            <Link
              to="/ar/voices"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-[#FF5500] hover:bg-[#E04800] text-white font-bold text-xs shadow-lg shadow-[#FF5500]/25 transition"
            >
              <span>ابدأ الآن واستكشف الأصوات</span>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>

        </div>
      </section>

    </div>
  );
};
