import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, ArrowLeft, CheckCircle2, Mic2, Sparkles, FileText } from 'lucide-react';
import { useSeo } from '../seo/useSeo';
import { STATIC_SEO_ROUTES } from '../seo/seoConfig';
import { Breadcrumbs } from '../components/Breadcrumbs';

export const GuidesPage: React.FC = () => {
  useSeo(STATIC_SEO_ROUTES['/ar/guides']);

  const guides = [
    {
      title: 'دليل: كيف أنضم إلى منصة قيمة فويس وأحقق دخلاً مستمراً؟',
      desc: 'خطوات إعداد ملفك الشخصي، تسجيل العينات الصوتية المعتمدة، معايير القبول، وكيفية تسعير خدماتك للشركات.',
      link: '/ar/jobs'
    },
    {
      title: 'دليل مواصفات استوديو التسجيل المنزلي للمعلق الصوتي',
      desc: 'أفضل المايكروفونات الاحترافية، بطاقات الصوت (Audio Interfaces)، وكيفية عزل الغرفة المنزلية من الصدى والضجيج.',
      link: '/ar/blogs/details/48-طبقات-الصوت-البشري-وكيفية-تدريب-الحبال-الصوتية'
    },
    {
      title: 'دليل الشركات والوكالات: كاستينغ واختيار المعلق الصوتي',
      desc: 'كيف تحدد الخامة الصوتية المناسبة لمنتجك، معايير التلوين الصوتي، وأهمية اختيار اللهجة المحلية المستهدفة.',
      link: '/ar/blogs/details/57-كيف-تختار-المعلق-الصوتي-المناسب-لمشروعك'
    },
    {
      title: 'دليل إنتاج الكتب الصوتية وفق معايير ACX العالمية',
      desc: 'شروط مستويات الصوت (RMS & Peak Levels)، معالجة الأنفاس، وضبط التشكيل النحوي للروايات والكتب الفكرية.',
      link: '/ar/services/audiobooks'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { name: 'الأدلة', item: '/ar/guides' }
        ]} />
      </div>

      <section className="py-12 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF5500]/10 text-[#FF5500] text-xs font-bold">
            <BookOpen className="w-3.5 h-3.5" />
            <span>المكتبة الإرشادية والتدريبية</span>
          </div>

          {/* Strict Single H1 */}
          <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight">
            أدلة التعليق الصوتي والإنتاج
          </h1>

          <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
            أدلة إرشادية وتدريبية متخصصة لشركات الإنتاج والمعلقين الصوتيين حول مواصفات الاستوديو وضبط الصوت وكيفية الانضمام للمنصة.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {guides.map((g, idx) => (
              <div key={idx} className="p-8 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <span className="text-[10px] font-bold text-[#FF5500] bg-orange-50 px-2.5 py-1 rounded-full border border-orange-100">
                    دليل إرشادي معتمد
                  </span>
                  <h2 className="text-lg font-bold text-slate-900 leading-snug">
                    {g.title}
                  </h2>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {g.desc}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <Link
                    to={g.link}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FF5500] hover:underline"
                  >
                    <span>قراءة الدليل بالكامل</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

    </div>
  );
};
