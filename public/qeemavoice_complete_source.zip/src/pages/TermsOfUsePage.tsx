import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, FileText, CheckCircle2 } from 'lucide-react';
import { useSeo } from '../seo/useSeo';
import { STATIC_SEO_ROUTES } from '../seo/seoConfig';
import { Breadcrumbs } from '../components/Breadcrumbs';

export const TermsOfUsePage: React.FC = () => {
  useSeo(STATIC_SEO_ROUTES['/ar/p/terms-of-use']);

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { name: 'الشروط والأحكام', item: '/ar/p/terms-of-use' }
        ]} />
      </div>

      <section className="py-12 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF5500]/10 text-[#FF5500] text-xs font-bold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>الحماية القانونية والتراخيص</span>
          </div>

          {/* Strict Single H1 */}
          <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight">
            الشروط والأحكام والتراخيص التجارية
          </h1>

          <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
            الشروط والأحكام المنظمة لاستخدام منصة قيمة فويس، وتراخيص حقوق الملكية الفكرية وعقود الأصوات البشرية والذكاء الاصطناعي وسياسة الخصوصية.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 bg-white p-8 sm:p-12 rounded-3xl border border-slate-200">
          
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-slate-900">1. شروط استخدام خدمات التعليق الصوتي</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              تضمن منصة قيمة فويس تقديم تسجيلات صوتية بشرية أصلية مسجلة في استوديوهات معتمدة وفق المعايير الفنية 48kHz. يلتزم العميل بتقديم نصوص قانونية لا تخالف الأنظمة والآداب العامة، وتلتزم المنصة بتسليم العمل في المواعيد المحددة.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-lg font-bold text-slate-900">2. حقوق الملكية الفكرية والتراخيص التجارية</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              يحصل العميل عند اكتمال سداد قيمة المشروع على ترخيص استخدام تجاري غير حصري أو حصري (بحسب نوع الباقة) لاستخدام التسجيل في المنصات المحددة في أمر الشراء. تحتفظ المواهب الصوتية بحق النسبة المعنوية للعمل.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-lg font-bold text-slate-900">3. نماذج الذكاء الاصطناعي الصوتي المرخص</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              جميع نماذج الذكاء الاصطناعي الصوتي المتوفرة في استوديو تحويل النص إلى صوت (TTS) مبنية على عقود رسمية مرخصة مع المعلقين الصوتيين الأصليين مع تقاسم أرباح دائم، ولا يجوز استخراج أو إعادة تدريب هذه النماذج خارج بيئة المنصة.
            </p>
          </div>

          <div className="space-y-3">
            <h2 className="text-lg font-bold text-slate-900">4. سياسة التعديلات واسترداد الرصيد</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              يحق للعميل طلب تعديلات مجانية في حال وجود أي خطأ نحوي أو نطقي صادر عن المعلق. في حال طلب العميل تعديلاً على النص الأصلي المعتمد بعد التسجيل، يتم احتساب تكلفة إعادة التسجيل الجزئي بسعر مخفض.
            </p>
          </div>

        </div>
      </section>

    </div>
  );
};
