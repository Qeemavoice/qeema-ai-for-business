import React from 'react';
import { Award, ArrowLeft, Building2, Sparkles, Star } from 'lucide-react';
import { useSeo } from '../seo/useSeo';
import { STATIC_SEO_ROUTES } from '../seo/seoConfig';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { CustomerStoriesView } from '../components/CustomerStoriesView';

export const OurWorksPage: React.FC = () => {
  // 1. Centralized SEO matching requirements
  useSeo({
    path: '/ar/our-works',
    title: 'قصص النجاح والعملاء | قيمة فويس',
    h1: 'قصص النجاح',
    description: 'تجارب وقصص نجاح كبرى الشركات والجهات الحكومية العربية في التعليق الصوتي والرد الآلي والدوبلاج مع قيمة فويس.',
    ogType: 'website',
    breadcrumbs: [
      { name: 'الرئيسية', item: '/ar' },
      { name: 'قصص النجاح', item: '/ar/our-works' }
    ]
  });

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs for SEO */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { name: 'قصص النجاح', item: '/ar/our-works' }
        ]} />
      </div>

      {/* SEO Header Section with Single Strict H1 */}
      <header className="py-10 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF5500]/10 text-[#FF5500] text-xs font-bold">
              <Building2 className="w-3.5 h-3.5" />
              <span>شراكات كبرى وقصص نجاح ملهمة</span>
            </div>

            {/* Strict Single H1 */}
            <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight">
              قصص النجاح
            </h1>

            <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
              تعرّف على كيفية استفادة الشركات الرائدة من جاهز، مصرف الراجحي، مجموعة MBC، طيران أديل، وSTC من أصوات وتقنيات قيمة فويس لرفع جودة التفاعل والوصول إلى ملايين المستمعين.
            </p>
          </div>
        </div>
      </header>

      {/* Pure Customer Stories Showcase */}
      <section className="py-10">
        <CustomerStoriesView
          onNavigate={() => {}}
          onOpenDemo={() => {}}
        />
      </section>

    </div>
  );
};
