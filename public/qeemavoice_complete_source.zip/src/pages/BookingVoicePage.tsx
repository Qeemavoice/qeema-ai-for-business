import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Mic2, 
  CheckCircle2, 
  ArrowLeft, 
  Volume2, 
  Calendar, 
  Clock, 
  Sparkles, 
  ShieldCheck, 
  Share2, 
  Send 
} from 'lucide-react';
import { Voice } from '../types';
import { useSeo } from '../seo/useSeo';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { BASE_SITE_URL } from '../seo/seoConfig';

interface BookingVoicePageProps {
  voices: Voice[];
}

export const BookingVoicePage: React.FC<BookingVoicePageProps> = ({ voices }) => {
  const { slug } = useParams<{ slug: string }>();
  
  // Find voice by id or slug
  const decoded = decodeURIComponent(slug || '');
  const idPrefix = decoded.split('-')[0];
  const voice = voices.find(v => v.id === idPrefix || v.name === decoded || v.id === slug) || voices[0];

  const pageTitle = voice
    ? `${voice.name} - تعليق صوتي ${voice.dialectLabel || voice.dialect} | قيمة فويس`
    : 'عينة صوتية | قيمة فويس';
  const pageH1 = voice ? `عينة صوت: ${voice.name}` : 'عينة صوت';
  const pageDesc = voice
    ? `استمع إلى عينة التعليق الصوتي للمؤدي ${voice.name}، لهجة ${voice.dialectLabel || voice.dialect}، تخصص ${voice.styleLabel || (voice as any).category || 'تعليق احترافي'}. احجز معلقك مباشرة بجودة 48kHz.`
    : 'استمع إلى عينات التعليق الصوتي المعتمدة واحجز معلقك اليوم عبر قيمة فويس.';

  // 1. Centralized SEO
  useSeo({
    path: `/ar/booking/${slug || ''}`,
    title: pageTitle,
    h1: pageH1,
    description: pageDesc,
    ogType: 'website',
    ogImage: voice?.avatar || (voice as any)?.avatarUrl,
    breadcrumbs: [
      { name: 'الرئيسية', item: '/ar' },
      { name: 'مكتبة الأصوات', item: '/ar/voices' },
      { name: voice?.name || 'عينة صوتية', item: `/ar/booking/${slug}` }
    ]
  });

  // Inject AudioObject schema
  useEffect(() => {
    if (!voice) return;
    const audioSchema = {
      '@context': 'https://schema.org',
      '@type': 'AudioObject',
      'name': `${voice.name} - عينة تعليق صوتي`,
      'description': pageDesc,
      'contentUrl': voice.previewUrl || (voice as any).sampleAudioUrl || 'https://assets.mixkit.co/active_storage/sfx/2872/2872-preview.mp3',
      'encodingFormat': 'audio/mpeg',
      'duration': 'PT0M30S',
      'inLanguage': 'ar',
      'author': {
        '@type': 'Person',
        'name': voice.name
      }
    };

    let script = document.getElementById('qeema-audio-jsonld') as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = 'qeema-audio-jsonld';
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(audioSchema, null, 2);

    return () => {
      const el = document.getElementById('qeema-audio-jsonld');
      if (el) el.remove();
    };
  }, [voice, pageDesc]);

  const [bookingSent, setBookingSent] = useState(false);
  const [projectText, setProjectText] = useState('');
  const [projectType, setProjectType] = useState('إعلان تجاري');

  if (!voice) {
    return (
      <div className="min-h-screen bg-[#FDFBF9] py-20 text-center space-y-4" dir="rtl">
        <h1 className="text-2xl font-bold text-slate-900">عينة الصوت غير موجودة</h1>
        <Link to="/ar/voices" className="inline-block px-6 py-2.5 rounded-xl bg-[#FF5500] text-white text-xs font-bold">
          العودة لمكتبة الأصوات
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { name: 'مكتبة الأصوات', item: '/ar/voices' },
          { name: voice.name, item: `/ar/booking/${slug}` }
        ]} />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Voice Card (7 cols) */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-4">
                <img
                  src={voice.avatar || (voice as any).avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'}
                  alt={voice.name}
                  width="72"
                  height="72"
                  className="w-18 h-18 rounded-2xl object-cover border border-slate-200"
                />
                <div>
                  <div className="flex items-center gap-2">
                    {/* Strict Single H1 */}
                    <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                      {voice.name}
                    </h1>
                    {voice.type === 'human' && (
                      <span className="p-1 rounded-full bg-emerald-50 text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    لهجة: <strong className="text-slate-800">{voice.dialectLabel || voice.dialect}</strong> • الجنس: <strong className="text-slate-800">{voice.gender === 'male' ? 'رجالي' : 'نسائي'}</strong>
                  </p>
                </div>
              </div>

              <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-orange-50 text-[#FF5500] border border-orange-200">
                {voice.styleLabel || (voice as any).category || 'تعليق احترافي'}
              </span>
            </div>

            {/* Audio Player Block */}
            <div className="p-5 rounded-2xl bg-slate-900 text-white space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
                  <Volume2 className="w-4 h-4" />
                  <span>عينة الاستوديو المعتمدة</span>
                </span>
                <span className="text-slate-400 font-mono">48kHz Ultra Studio</span>
              </div>

              {/* Real HTML Audio Player with preload="none" */}
              <audio
                controls
                preload="none"
                src={voice.previewUrl || (voice as any).sampleAudioUrl || 'https://assets.mixkit.co/active_storage/sfx/2872/2872-preview.mp3'}
                className="w-full"
              />

              <div className="text-[11px] text-slate-400">
                اسم المعلق: {voice.name} • اللهجة: {voice.dialectLabel || voice.dialect} • الاستخدام: {voice.styleLabel || (voice as any).category || 'تعليق احترافي'}
              </div>
            </div>

            {/* Voice Details */}
            <div className="space-y-4 pt-2">
              <h2 className="text-sm font-bold text-slate-900">نبذة عن خامة الصوت ومجالات الاستخدام</h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                معلق صوتي معتمد في منصة قيمة فويس، يتميز بنطق عربي سليم ووضوح مخارجي رفيع يلائم إعلانات التلفزيون والراديو، مقاطع السوشيال ميديا، والإنتاج الوثائقي.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px]">سرعة التسليم</span>
                  <strong className="text-slate-800">24-48 ساعة</strong>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px]">تعديل النطق</span>
                  <strong className="text-slate-800">مجاني ومضمون</strong>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px]">حقوق الاستخدام</span>
                  <strong className="text-slate-800">ترخيص تجاري كامل</strong>
                </div>
              </div>
            </div>

            {/* Back link */}
            <div className="pt-4 border-t border-slate-100">
              <Link
                to="/ar/voices"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FF5500] hover:underline"
              >
                <span>← العودة إلى كافة الأصوات في المكتبة</span>
              </Link>
            </div>

          </div>

          {/* Booking Inquiry Card (5 cols) */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
            {bookingSent ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">تم إرسال طلب الحجز بنجاح!</h3>
                <p className="text-xs text-slate-600">
                  سيتواصل معك مدير الإنتاج الصوتي لتأكيد النص والمدة والتسعير والبدء فوراً.
                </p>
                <button
                  onClick={() => setBookingSent(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-xs font-bold text-slate-700"
                >
                  إرسال طلب آخر
                </button>
              </div>
            ) : (
              <form onSubmit={e => { e.preventDefault(); setBookingSent(true); }} className="space-y-4">
                <div className="border-b border-slate-100 pb-3">
                  <h3 className="text-base font-bold text-slate-900">طلب حجز مباشر للمعلق</h3>
                  <p className="text-[11px] text-slate-500">أرسل تفاصيل مشروعك وسنزودك بعرض سعر رسمي فوري.</p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">نوع المشروع</label>
                  <select
                    value={projectType}
                    onChange={e => setProjectType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-[#FF5500]"
                  >
                    <option value="إعلان تجاري">إعلان تجاري (سوشيال ميديا / يوتيوب)</option>
                    <option value="بث تلفزيوني أو إذاعي">بث تلفزيوني أو إذاعي</option>
                    <option value="فيلم وثائقي أو تعريفي">فيلم وثائقي أو تعريفي للشركة</option>
                    <option value="رد آلي IVR">تسجيل رد آلي لمراكز الاتصال</option>
                    <option value="كتاب صوتي أو بودكاست">كتاب صوتي أو بودكاست</option>
                    <option value="دوبلاج كرتون">دوبلاج كرتون وتمثيل صوتي</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">النص أو تفاصيل السيناريو *</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="الصق نص الإعلان هنا أو اكتب عدد الكلمات التقريبي وأي تعليمات إخراجية..."
                    value={projectText}
                    onChange={e => setProjectText(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-[#FF5500] resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">اسمك أو اسم شركتك *</label>
                    <input
                      type="text"
                      required
                      placeholder="اسم الجهة"
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-[#FF5500]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">البريد الإلكتروني *</label>
                    <input
                      type="email"
                      required
                      placeholder="name@company.com"
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-[#FF5500]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-[#FF5500] hover:bg-[#E04800] text-white font-bold text-xs shadow-md shadow-[#FF5500]/25 transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال طلب الحجز وعرض السعر</span>
                </button>
              </form>
            )}
          </div>

        </div>
      </div>

    </div>
  );
};
