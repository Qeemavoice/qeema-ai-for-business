import { Router, Request, Response } from 'express';
import { DEFAULT_PLAN_ID, SIGNUP_BONUS_CREDITS } from '../../shared/plans';
import { db } from '../db/store';
import crypto from 'crypto';

export const authRouter = Router();

// Middleware helper to get active user and company
export function getAuthenticatedContext(req: Request) {
  // Check header 'x-company-id' or 'x-user-id', or default to first company
  const companyId = (req.headers['x-company-id'] as string) || 'comp-horizon';
  const userId = (req.headers['x-user-id'] as string) || 'usr-ahmad';

  const company = db.companies.get(companyId) || Array.from(db.companies.values())[0];
  const user = db.users.get(userId) || Array.from(db.users.values())[0];
  const balance = db.getCompanyBalance(company.id);

  return { company, user, balance };
}

// Current authenticated user & company
authRouter.get('/me', (req: Request, res: Response) => {
  const { company, user, balance } = getAuthenticatedContext(req);
  res.json({
    user,
    company,
    balanceCredits: balance,
    availableCompanies: Array.from(db.companies.values()),
  });
});

// Switch company for testing/demonstration
authRouter.post('/switch-company', (req: Request, res: Response) => {
  const { companyId } = req.body;
  if (!companyId || !db.companies.has(companyId)) {
    return res.status(404).json({ error: 'الشركة غير موجودة' });
  }

  const company = db.companies.get(companyId)!;
  // find first user belonging to this company
  const user = Array.from(db.users.values()).find(u => u.companyId === companyId) || {
    id: `usr-${companyId}`,
    email: `contact@${companyId}.com`,
    name: 'مسؤول الشركة',
    companyId: company.id,
    role: 'admin' as const,
    createdAt: new Date().toISOString()
  };

  const balance = db.getCompanyBalance(company.id);
  res.json({
    user,
    company,
    balanceCredits: balance,
  });
});

// Register new B2B Company
authRouter.post('/register', (req: Request, res: Response) => {
  const { companyName, industry, country, contactName, email } = req.body;

  if (!companyName || !email) {
    return res.status(400).json({ error: 'اسم الشركة والبريد الإلكتروني مطلوبان' });
  }

  const companyId = `comp-${crypto.randomBytes(4).toString('hex')}`;
  const userId = `usr-${crypto.randomBytes(4).toString('hex')}`;

  const newCompany = {
    id: companyId,
    name: companyName,
    industry: industry || 'Corporate Business',
    country: country || 'المملكة العربية السعودية',
    createdAt: new Date().toISOString(),
    planId: DEFAULT_PLAN_ID
  };

  const newUser = {
    id: userId,
    email,
    name: contactName || 'مدير الحساب',
    companyId,
    role: 'admin' as const,
    createdAt: new Date().toISOString(),
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80'
  };

  db.companies.set(companyId, newCompany);
  db.users.set(userId, newUser);

  // Grant 5,000 welcome credits
  const initialBalance = db.addCredits(
    companyId,
    userId,
    SIGNUP_BONUS_CREDITS,
    'signup_bonus',
    `رصيد ترحيبي مجاني (${SIGNUP_BONUS_CREDITS.toLocaleString('en-US')} حرف)`
  );

  res.json({
    success: true,
    user: newUser,
    company: newCompany,
    balanceCredits: initialBalance,
    message: 'تم تسجيل الشركة بنجاح ومنح رصيد ترحيبي 5,000 نقطة'
  });
});
