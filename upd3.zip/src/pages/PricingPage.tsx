import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Check, 
  Sparkles, 
  ShieldCheck, 
  ArrowLeft, 
  Calculator, 
  HelpCircle, 
  Clock, 
  Layers, 
  Zap, 
  CreditCard,
  Building2,
  ChevronDown,
  CornerLeftDown,
  Gift,
  AudioLines,
  Mic2,
  Headphones,
  CalendarCheck,
  FileAudio,
  History,
  Percent,
  Fingerprint,
  Code2
} from 'lucide-react';
import { useSeo } from '../seo/useSeo';
import { STATIC_SEO_ROUTES } from '../seo/seoConfig';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { PLANS, PlanFeatureIcon } from '../../shared/plans';

export const PricingPage: React.FC = () => {
  // 1. Centralized SEO matching requirements exactly
  useSeo(STATIC_SEO_ROUTES['/ar/pricing']);

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  // Interactive Project Price Calculator State
  const [calcService, setCalcService] = useState<'commercial' | 'audiobook' | 'ivr' | 'dubbing'>('commercial');
  const [calcWords, setCalcWords] = useState<number>(100);
  const [calcDialect, setCalcDialect] = useState<'saudi' | 'fusha' | 'egyptian' | 'emirati'>('saudi');

  // Estimate price dynamically in USD ($)
  const calculatePrice = () => {
    let baseRatePerWord = 0.25; // USD
    if (calcService === 'commercial') baseRatePerWord = 0.35;
    if (calcService === 'audiobook') baseRatePerWord = 0.15;
    if (calcService === 'ivr') baseRatePerWord = 0.30;
    if (calcService === 'dubbing') baseRatePerWord = 0.40;

    if (calcDialect === 'saudi' || calcDialect === 'emirati') baseRatePerWord *= 1.15;

    const estimatedUsd = Math.max(35, Math.round(calcWords * baseRatePerWord));
    const estimatedMinutes = Math.max(1, Math.round(calcWords / 130));

    return { estimatedUsd, estimatedMinutes };
  };

  const { estimatedUsd, estimatedMinutes } = calculatePrice();

  // Subscription plans come from shared/plans.ts (same data as the dashboard billing)
  const PLAN_ICONS: Record<PlanFeatureIcon, React.ElementType> = {
    gift: Gift, audio: AudioLines, headphones: Headphones, calendar: CalendarCheck, file: FileAudio,
    mic: Mic2, shield: ShieldCheck, history: History, percent: Percent, fingerprint: Fingerprint,
    zap: Zap, sparkles: Sparkles, code: Code2, building: Building2, clock: Clock
  };
  const plans = PLANS.map(p => ({
    id: p.id,
    name: p.nameAr,
    tagline: p.tagline,
    monthlyPrice: p.priceUsd,
    annualPrice: p.annualPriceUsd,
    badge: p.badge,
    featured: p.featured,
    inheritsFrom: p.inheritsFrom,
    cta: p.isCustom ? 'تواصل مع المبيعات' : p.priceUsd === 0 ? 'ابدأ مجاناً' : `اختر ${p.nameAr}`,
    ctaTo: p.isCustom ? '/ar/contact-us' : p.priceUsd === 0 ? '/ar/generate' : '/ar/dashboard',
    features: p.features.map(f => ({ icon: PLAN_ICONS[f.icon], text: f.text }))
  }));

  // FAQ Accordion State
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const pricingFaqs = [
    {
      q: 'هل تشمل الأسعار التراخيص التجارية وحقوق البث؟',
      a: 'نعم، جميع أسعار التعليق الصوتي في قيمة فويس تتضمن ترخيصاً تجارياً موثقاً يتيح لك استخدام الصوت في الحملات الرقمية، السوشيال ميديا، والمنصات الترويجية بدون أي رسوم ملكية إضافية.'
    },
    {
      q: 'ما هي سياسة التعديلات وإعادة التسجيل؟',
      a: 'أي خطأ في نطق النص أو التشكيل المتفق عليه يُعاد تسجيله مجاناً بنسبة 100%. أما التعديلات الناتجة عن تغيير النص الأصلي بعد التسجيل فيتم احتسابها بخصم 50% من تكلفة المقطع المعدل.'
    },
    {
      q: 'كيف يتم احتساب الأسعار للمشاريع الكبيرة والكتب الصوتية؟',
      a: 'نقدم تسعيراً مخفضاً بالدقيقة أو بآلاف الكلمات للكتب الصوتية والدورات التدريبية وسلاسل البودكاست مع مهندس صوت مخصص يشرف على معايير ACX العالمية.'
    },
    {
      q: 'هل توفرون فواتير ضريبية معتمدة للشركات؟',
      a: 'نعم، نصدر فواتير ضريبية نظامية متوافقة مع متطلبات هيئة الزكاة والضريبة والجمارك (ZATCA) في السعودية، بالإضافة إلى خيارات الدفع عبر أوامر الشراء والتحويل البنكي المؤسسي.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-slate-900 pb-20" dir="rtl">
      
      {/* Breadcrumbs for SEO */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumbs items={[
          { name: 'الرئيسية', item: '/ar' },
          { name: 'الأسعار', item: '/ar/pricing' }
        ]} />
      </div>

      {/* SEO Header Section with Single Strict H1 */}
      <header className="py-12 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-50 border border-orange-200 text-[#FF5500] text-xs font-bold">
            <CreditCard className="w-4 h-4" />
            <span>تسعير شفاف ومرن بدون رسوم خفية</span>
          </div>

          {/* Strict Single H1 matching SEO spec */}
          <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight">
            أسعار التعليق الصوتي
          </h1>

          <p className="text-sm sm:text-base text-slate-600 max-w-3xl mx-auto leading-relaxed">
            تعرّف على أسعار التعليق الصوتي في قيمة فويس حسب نوع المشروع ومدته واللهجة وحقوق الاستخدام، واطلب عرض سعر لمشروعك.
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold mt-2 shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>ملاحظة: كل مستخدم جديد يحصل على رصيد مجاني بالبداية لتجربة الأصوات واستوديو توليد النصوص!</span>
          </div>

          {/* Billing Cycle Switcher */}
          <div className="pt-4 flex items-center justify-center gap-3">
            <span className={`text-xs font-bold ${billingCycle === 'monthly' ? 'text-slate-900' : 'text-slate-500'}`}>
              دفع شهري
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
              className="relative w-14 h-7 rounded-full bg-slate-900 p-1 transition cursor-pointer"
            >
              <div 
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  billingCycle === 'annual' ? '-translate-x-7 bg-[#FF5500]' : 'translate-x-0'
                }`}
              />
            </button>
            <span className={`text-xs font-bold flex items-center gap-1.5 ${billingCycle === 'annual' ? 'text-slate-900' : 'text-slate-500'}`}>
              <span>اشتراك سنوي</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                وفر 20%
              </span>
            </span>
          </div>
        </div>
      </header>

      {/* 1. Subscription Plans (Column layout with feature lists) */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-y-12">
            {plans.map((plan, idx) => {
              const price = billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice;
              return (
                <div
                  key={plan.id}
                  className={`flex flex-col px-0 md:px-4 ${idx > 0 ? 'xl:border-r xl:border-slate-200' : ''} ${idx % 2 === 1 ? 'md:border-r md:border-slate-200 xl:border-r' : ''}`}
                >
                  {/* Plan card */}
                  <div
                    className={`rounded-3xl border p-6 min-h-[260px] flex flex-col justify-between ${
                      plan.featured
                        ? 'bg-slate-950 border-slate-950 text-white'
                        : 'bg-[#F2EFEA] border-[#E7E2DA] text-slate-950'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <h2 className="text-3xl font-black tracking-tight">{plan.name}</h2>
                      <p className={`text-xs leading-relaxed ${plan.featured ? 'text-slate-300' : 'text-slate-600'}`}>
                        {plan.tagline}
                      </p>
                    </div>

                    <div className="space-y-2">
                      {plan.badge && (
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-[11px] font-bold ${
                            plan.featured ? 'bg-[#FF5500] text-white' : 'bg-slate-950 text-white'
                          }`}
                        >
                          {plan.badge}
                        </span>
                      )}
                      {billingCycle === 'annual' && plan.monthlyPrice !== null && plan.monthlyPrice > 0 && (
                        <div className={`text-xs ${plan.featured ? 'text-slate-400' : 'text-slate-500'}`}>
                          <span className="line-through font-mono">${plan.monthlyPrice}</span>
                          <span className="mr-1.5">وفّر 20% بالاشتراك السنوي</span>
                        </div>
                      )}
                      <div className="flex items-baseline gap-1.5">
                        {price === null ? (
                          <span className="text-3xl font-black">تسعير مخصص</span>
                        ) : (
                          <>
                            <span className="text-4xl font-black font-mono">${price}</span>
                            <span className={`text-sm ${plan.featured ? 'text-slate-400' : 'text-slate-500'}`}>/ شهرياً</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* CTA */}
                  <Link
                    to={plan.ctaTo}
                    className={`mt-5 w-full py-3.5 rounded-full text-center text-sm font-bold transition ${
                      plan.featured
                        ? 'bg-[#FF5500] hover:bg-[#E04800] text-white shadow-lg shadow-[#FF5500]/25'
                        : 'bg-slate-950 hover:bg-slate-800 text-white'
                    }`}
                  >
                    {plan.cta}
                  </Link>

                  {/* Features */}
                  <div className="mt-7">
                    {plan.inheritsFrom && (
                      <div className="flex items-center gap-1.5 pb-3 border-b border-dotted border-slate-300 text-sm text-slate-500">
                        <span>كل ما في {plan.inheritsFrom}، بالإضافة إلى</span>
                        <CornerLeftDown className="w-4 h-4 text-slate-400" />
                      </div>
                    )}
                    {plan.features.map(({ icon: Icon, text }) => (
                      <div
                        key={text}
                        className="flex items-center gap-3 py-3.5 border-b border-dotted border-slate-300 text-sm text-slate-800"
                      >
                        <Icon className="w-5 h-5 text-slate-700 shrink-0" strokeWidth={1.6} />
                        <span>{text}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 2. Interactive Project Cost Calculator */}
      <section className="py-12 bg-white border-y border-slate-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FF5500]">
              <Calculator className="w-4 h-4" />
              <span>حاسبة تكلفة المشروع التقديرية</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900">
              احسب تكلفة تسجيل مشروعك الصوتي في ثوانٍ
            </h2>
            <p className="text-xs text-slate-500">
              اختر نوع المشروع واللهجة وعدد الكلمات لتقدير القيمة التقريبية قبل بدء الحجز.
            </p>
          </div>

          <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 border border-slate-200 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Inputs (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">نوع المشروع الصوتي</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'commercial', label: 'إعلان تجاري' },
                    { id: 'audiobook', label: 'كتاب صوتي' },
                    { id: 'ivr', label: 'رد آلي سنترال' },
                    { id: 'dubbing', label: 'دوبلاج كرتون' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setCalcService(item.id as any)}
                      className={`p-2.5 rounded-xl text-xs font-bold transition border cursor-pointer ${
                        calcService === item.id
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">اللهجة المطلوبة</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'saudi', label: 'سعودية' },
                    { id: 'fusha', label: 'فصحى' },
                    { id: 'emirati', label: 'إماراتية' },
                    { id: 'egyptian', label: 'مصرية' }
                  ].map(d => (
                    <button
                      key={d.id}
                      onClick={() => setCalcDialect(d.id as any)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition border cursor-pointer ${
                        calcDialect === d.id
                          ? 'bg-[#FF5500] text-white border-[#FF5500]'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-1">
                  <span>عدد الكلمات التقريبي:</span>
                  <span className="font-mono text-[#FF5500] text-sm">{calcWords} كلمة</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="1500"
                  step="10"
                  value={calcWords}
                  onChange={e => setCalcWords(Number(e.target.value))}
                  className="w-full accent-[#FF5500] cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>إعلان قصير (20 كلمة)</span>
                  <span>فيديو تعريفي (300 كلمة)</span>
                  <span>بودكاست / وثائقي (1500 كلمة)</span>
                </div>
              </div>
            </div>

            {/* Calculation Result Output Card (5 cols) */}
            <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-md text-center space-y-4">
              <span className="text-xs text-slate-500 font-medium">التكلفة التقديرية للمشروع</span>
              <div className="font-mono">
                <span className="text-4xl font-black text-slate-900">${estimatedUsd}</span>
                <span className="text-xs text-slate-500 font-sans mr-1">دولار أمريكي (USD)</span>
              </div>
              
              <div className="p-3 rounded-xl bg-orange-50/70 text-slate-700 text-xs space-y-1">
                <div>المدة الزمنية المتوقعة: <strong>~{estimatedMinutes} دقيقة</strong></div>
                <div className="text-[11px] text-slate-500">تشمل الهندسة الصوتية والترخيص التجاري</div>
              </div>

              <Link
                to="/ar/voices"
                className="w-full py-3 rounded-xl bg-[#FF5500] hover:bg-[#E04800] text-white text-xs font-bold shadow-md block transition"
              >
                اختيار معلق صوتي وبدء المشروع
              </Link>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Pricing FAQ Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-bold text-slate-900">
              الأسئلة الشائعة حول أسعار التعليق الصوتي
            </h2>
            <p className="text-xs text-slate-500">
              إجابات واضحة عن كل ما يخص تكلفة الحجز وطرق الدفع والضمانات.
            </p>
          </div>

          <div className="space-y-3">
            {pricingFaqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div key={idx} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="w-full p-5 text-right flex items-center justify-between gap-4 font-bold text-xs sm:text-sm text-slate-900 hover:text-[#FF5500] transition cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="text-center pt-6">
            <p className="text-xs text-slate-500 mb-3">هل لديك نص مخصص وتريد عرض سعر رسمي مختوم لشركتك؟</p>
            <Link
              to="/ar/contact-us"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition shadow-sm"
            >
              <span>طلب عرض سعر رسمي فوري</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
};
